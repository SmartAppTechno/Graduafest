<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-13 00:03:42 --> Config Class Initialized
INFO - 2017-03-13 00:03:42 --> Hooks Class Initialized
DEBUG - 2017-03-13 00:03:42 --> UTF-8 Support Enabled
INFO - 2017-03-13 00:03:42 --> Utf8 Class Initialized
INFO - 2017-03-13 00:03:42 --> URI Class Initialized
INFO - 2017-03-13 00:03:42 --> Router Class Initialized
INFO - 2017-03-13 00:03:42 --> Output Class Initialized
INFO - 2017-03-13 00:03:42 --> Security Class Initialized
DEBUG - 2017-03-13 00:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 00:03:42 --> Input Class Initialized
INFO - 2017-03-13 00:03:42 --> Language Class Initialized
INFO - 2017-03-13 00:03:42 --> Loader Class Initialized
INFO - 2017-03-13 00:03:42 --> Database Driver Class Initialized
INFO - 2017-03-13 00:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 00:03:43 --> Controller Class Initialized
INFO - 2017-03-13 00:03:43 --> Helper loaded: url_helper
DEBUG - 2017-03-13 00:03:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 00:03:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 00:03:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 00:03:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 00:03:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 00:03:43 --> Final output sent to browser
DEBUG - 2017-03-13 00:03:43 --> Total execution time: 1.7070
INFO - 2017-03-13 00:03:43 --> Config Class Initialized
INFO - 2017-03-13 00:03:43 --> Hooks Class Initialized
DEBUG - 2017-03-13 00:03:43 --> UTF-8 Support Enabled
INFO - 2017-03-13 00:03:43 --> Utf8 Class Initialized
INFO - 2017-03-13 00:03:43 --> URI Class Initialized
INFO - 2017-03-13 00:03:43 --> Router Class Initialized
INFO - 2017-03-13 00:03:43 --> Output Class Initialized
INFO - 2017-03-13 00:03:43 --> Security Class Initialized
DEBUG - 2017-03-13 00:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 00:03:43 --> Input Class Initialized
INFO - 2017-03-13 00:03:43 --> Language Class Initialized
INFO - 2017-03-13 00:03:43 --> Loader Class Initialized
INFO - 2017-03-13 00:03:43 --> Database Driver Class Initialized
INFO - 2017-03-13 00:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 00:03:43 --> Controller Class Initialized
INFO - 2017-03-13 00:03:43 --> Helper loaded: url_helper
DEBUG - 2017-03-13 00:03:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 00:03:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 00:03:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 00:03:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 00:03:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 00:03:43 --> Final output sent to browser
DEBUG - 2017-03-13 00:03:43 --> Total execution time: 0.0138
INFO - 2017-03-13 00:19:06 --> Config Class Initialized
INFO - 2017-03-13 00:19:06 --> Hooks Class Initialized
DEBUG - 2017-03-13 00:19:07 --> UTF-8 Support Enabled
INFO - 2017-03-13 00:19:07 --> Utf8 Class Initialized
INFO - 2017-03-13 00:19:07 --> URI Class Initialized
INFO - 2017-03-13 00:19:07 --> Router Class Initialized
INFO - 2017-03-13 00:19:07 --> Output Class Initialized
INFO - 2017-03-13 00:19:07 --> Security Class Initialized
DEBUG - 2017-03-13 00:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 00:19:07 --> Input Class Initialized
INFO - 2017-03-13 00:19:07 --> Language Class Initialized
INFO - 2017-03-13 00:19:07 --> Loader Class Initialized
INFO - 2017-03-13 00:19:07 --> Database Driver Class Initialized
INFO - 2017-03-13 00:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 00:19:08 --> Controller Class Initialized
INFO - 2017-03-13 00:19:08 --> Helper loaded: url_helper
DEBUG - 2017-03-13 00:19:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 00:19:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 00:19:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 00:19:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 00:19:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 00:19:08 --> Final output sent to browser
DEBUG - 2017-03-13 00:19:08 --> Total execution time: 1.4517
INFO - 2017-03-13 00:19:14 --> Config Class Initialized
INFO - 2017-03-13 00:19:14 --> Hooks Class Initialized
DEBUG - 2017-03-13 00:19:14 --> UTF-8 Support Enabled
INFO - 2017-03-13 00:19:14 --> Utf8 Class Initialized
INFO - 2017-03-13 00:19:14 --> URI Class Initialized
INFO - 2017-03-13 00:19:14 --> Router Class Initialized
INFO - 2017-03-13 00:19:14 --> Output Class Initialized
INFO - 2017-03-13 00:19:14 --> Security Class Initialized
DEBUG - 2017-03-13 00:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 00:19:14 --> Input Class Initialized
INFO - 2017-03-13 00:19:14 --> Language Class Initialized
INFO - 2017-03-13 00:19:14 --> Loader Class Initialized
INFO - 2017-03-13 00:19:14 --> Database Driver Class Initialized
INFO - 2017-03-13 00:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 00:19:14 --> Controller Class Initialized
INFO - 2017-03-13 00:19:14 --> Helper loaded: url_helper
DEBUG - 2017-03-13 00:19:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 00:19:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 00:19:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 00:19:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 00:19:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 00:19:14 --> Final output sent to browser
DEBUG - 2017-03-13 00:19:14 --> Total execution time: 0.0137
INFO - 2017-03-13 00:19:40 --> Config Class Initialized
INFO - 2017-03-13 00:19:40 --> Hooks Class Initialized
DEBUG - 2017-03-13 00:19:40 --> UTF-8 Support Enabled
INFO - 2017-03-13 00:19:40 --> Utf8 Class Initialized
INFO - 2017-03-13 00:19:40 --> URI Class Initialized
INFO - 2017-03-13 00:19:40 --> Router Class Initialized
INFO - 2017-03-13 00:19:40 --> Output Class Initialized
INFO - 2017-03-13 00:19:40 --> Security Class Initialized
DEBUG - 2017-03-13 00:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 00:19:40 --> Input Class Initialized
INFO - 2017-03-13 00:19:40 --> Language Class Initialized
INFO - 2017-03-13 00:19:40 --> Loader Class Initialized
INFO - 2017-03-13 00:19:40 --> Database Driver Class Initialized
INFO - 2017-03-13 00:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 00:19:40 --> Controller Class Initialized
INFO - 2017-03-13 00:19:40 --> Helper loaded: url_helper
DEBUG - 2017-03-13 00:19:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 00:19:42 --> Config Class Initialized
INFO - 2017-03-13 00:19:42 --> Hooks Class Initialized
DEBUG - 2017-03-13 00:19:42 --> UTF-8 Support Enabled
INFO - 2017-03-13 00:19:42 --> Utf8 Class Initialized
INFO - 2017-03-13 00:19:42 --> URI Class Initialized
INFO - 2017-03-13 00:19:42 --> Router Class Initialized
INFO - 2017-03-13 00:19:42 --> Output Class Initialized
INFO - 2017-03-13 00:19:42 --> Security Class Initialized
DEBUG - 2017-03-13 00:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 00:19:42 --> Input Class Initialized
INFO - 2017-03-13 00:19:42 --> Language Class Initialized
INFO - 2017-03-13 00:19:42 --> Loader Class Initialized
INFO - 2017-03-13 00:19:42 --> Database Driver Class Initialized
INFO - 2017-03-13 00:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 00:19:42 --> Controller Class Initialized
INFO - 2017-03-13 00:19:42 --> Helper loaded: date_helper
DEBUG - 2017-03-13 00:19:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 00:19:42 --> Helper loaded: url_helper
INFO - 2017-03-13 00:19:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 00:19:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 00:19:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 00:19:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 00:19:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 00:19:42 --> Final output sent to browser
DEBUG - 2017-03-13 00:19:42 --> Total execution time: 0.0919
INFO - 2017-03-13 00:19:44 --> Config Class Initialized
INFO - 2017-03-13 00:19:44 --> Hooks Class Initialized
DEBUG - 2017-03-13 00:19:44 --> UTF-8 Support Enabled
INFO - 2017-03-13 00:19:44 --> Utf8 Class Initialized
INFO - 2017-03-13 00:19:44 --> URI Class Initialized
INFO - 2017-03-13 00:19:44 --> Router Class Initialized
INFO - 2017-03-13 00:19:44 --> Output Class Initialized
INFO - 2017-03-13 00:19:44 --> Security Class Initialized
DEBUG - 2017-03-13 00:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 00:19:44 --> Input Class Initialized
INFO - 2017-03-13 00:19:44 --> Language Class Initialized
INFO - 2017-03-13 00:19:44 --> Loader Class Initialized
INFO - 2017-03-13 00:19:44 --> Database Driver Class Initialized
INFO - 2017-03-13 00:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 00:19:44 --> Controller Class Initialized
INFO - 2017-03-13 00:19:44 --> Helper loaded: url_helper
DEBUG - 2017-03-13 00:19:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 00:19:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 00:19:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 00:19:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 00:19:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 00:19:44 --> Final output sent to browser
DEBUG - 2017-03-13 00:19:44 --> Total execution time: 0.0140
INFO - 2017-03-13 00:19:48 --> Config Class Initialized
INFO - 2017-03-13 00:19:48 --> Hooks Class Initialized
DEBUG - 2017-03-13 00:19:48 --> UTF-8 Support Enabled
INFO - 2017-03-13 00:19:48 --> Utf8 Class Initialized
INFO - 2017-03-13 00:19:48 --> URI Class Initialized
DEBUG - 2017-03-13 00:19:48 --> No URI present. Default controller set.
INFO - 2017-03-13 00:19:48 --> Router Class Initialized
INFO - 2017-03-13 00:19:48 --> Output Class Initialized
INFO - 2017-03-13 00:19:48 --> Security Class Initialized
DEBUG - 2017-03-13 00:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 00:19:48 --> Input Class Initialized
INFO - 2017-03-13 00:19:48 --> Language Class Initialized
INFO - 2017-03-13 00:19:48 --> Loader Class Initialized
INFO - 2017-03-13 00:19:48 --> Database Driver Class Initialized
INFO - 2017-03-13 00:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 00:19:48 --> Controller Class Initialized
INFO - 2017-03-13 00:19:48 --> Helper loaded: url_helper
DEBUG - 2017-03-13 00:19:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 00:19:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 00:19:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 00:19:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 00:19:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 00:19:48 --> Final output sent to browser
DEBUG - 2017-03-13 00:19:48 --> Total execution time: 0.0266
INFO - 2017-03-13 00:19:50 --> Config Class Initialized
INFO - 2017-03-13 00:19:50 --> Hooks Class Initialized
DEBUG - 2017-03-13 00:19:50 --> UTF-8 Support Enabled
INFO - 2017-03-13 00:19:50 --> Utf8 Class Initialized
INFO - 2017-03-13 00:19:50 --> URI Class Initialized
INFO - 2017-03-13 00:19:50 --> Router Class Initialized
INFO - 2017-03-13 00:19:50 --> Output Class Initialized
INFO - 2017-03-13 00:19:50 --> Security Class Initialized
DEBUG - 2017-03-13 00:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 00:19:50 --> Input Class Initialized
INFO - 2017-03-13 00:19:50 --> Language Class Initialized
INFO - 2017-03-13 00:19:50 --> Loader Class Initialized
INFO - 2017-03-13 00:19:50 --> Database Driver Class Initialized
INFO - 2017-03-13 00:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 00:19:50 --> Controller Class Initialized
INFO - 2017-03-13 00:19:50 --> Helper loaded: url_helper
DEBUG - 2017-03-13 00:19:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 00:19:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 00:19:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 00:19:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 00:19:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 00:19:51 --> Final output sent to browser
DEBUG - 2017-03-13 00:19:51 --> Total execution time: 0.0145
INFO - 2017-03-13 00:19:52 --> Config Class Initialized
INFO - 2017-03-13 00:19:52 --> Hooks Class Initialized
DEBUG - 2017-03-13 00:19:52 --> UTF-8 Support Enabled
INFO - 2017-03-13 00:19:52 --> Utf8 Class Initialized
INFO - 2017-03-13 00:19:52 --> URI Class Initialized
INFO - 2017-03-13 00:19:52 --> Router Class Initialized
INFO - 2017-03-13 00:19:52 --> Output Class Initialized
INFO - 2017-03-13 00:19:52 --> Security Class Initialized
DEBUG - 2017-03-13 00:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 00:19:52 --> Input Class Initialized
INFO - 2017-03-13 00:19:52 --> Language Class Initialized
INFO - 2017-03-13 00:19:52 --> Loader Class Initialized
INFO - 2017-03-13 00:19:52 --> Database Driver Class Initialized
INFO - 2017-03-13 00:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 00:19:52 --> Controller Class Initialized
INFO - 2017-03-13 00:19:52 --> Helper loaded: date_helper
DEBUG - 2017-03-13 00:19:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 00:19:52 --> Helper loaded: url_helper
INFO - 2017-03-13 00:19:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 00:19:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 00:19:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 00:19:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 00:19:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 00:19:52 --> Final output sent to browser
DEBUG - 2017-03-13 00:19:52 --> Total execution time: 0.0662
INFO - 2017-03-13 00:19:52 --> Config Class Initialized
INFO - 2017-03-13 00:19:52 --> Hooks Class Initialized
DEBUG - 2017-03-13 00:19:52 --> UTF-8 Support Enabled
INFO - 2017-03-13 00:19:52 --> Utf8 Class Initialized
INFO - 2017-03-13 00:19:52 --> URI Class Initialized
INFO - 2017-03-13 00:19:52 --> Router Class Initialized
INFO - 2017-03-13 00:19:52 --> Output Class Initialized
INFO - 2017-03-13 00:19:52 --> Security Class Initialized
DEBUG - 2017-03-13 00:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 00:19:52 --> Input Class Initialized
INFO - 2017-03-13 00:19:52 --> Language Class Initialized
INFO - 2017-03-13 00:19:52 --> Loader Class Initialized
INFO - 2017-03-13 00:19:52 --> Database Driver Class Initialized
INFO - 2017-03-13 00:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 00:19:52 --> Controller Class Initialized
INFO - 2017-03-13 00:19:52 --> Helper loaded: url_helper
DEBUG - 2017-03-13 00:19:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 00:19:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 00:19:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 00:19:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 00:19:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 00:19:52 --> Final output sent to browser
DEBUG - 2017-03-13 00:19:52 --> Total execution time: 0.0140
INFO - 2017-03-13 00:45:52 --> Config Class Initialized
INFO - 2017-03-13 00:45:52 --> Hooks Class Initialized
DEBUG - 2017-03-13 00:45:52 --> UTF-8 Support Enabled
INFO - 2017-03-13 00:45:52 --> Utf8 Class Initialized
INFO - 2017-03-13 00:45:52 --> URI Class Initialized
DEBUG - 2017-03-13 00:45:52 --> No URI present. Default controller set.
INFO - 2017-03-13 00:45:52 --> Router Class Initialized
INFO - 2017-03-13 00:45:52 --> Output Class Initialized
INFO - 2017-03-13 00:45:52 --> Security Class Initialized
DEBUG - 2017-03-13 00:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 00:45:52 --> Input Class Initialized
INFO - 2017-03-13 00:45:52 --> Language Class Initialized
INFO - 2017-03-13 00:45:52 --> Loader Class Initialized
INFO - 2017-03-13 00:45:52 --> Database Driver Class Initialized
INFO - 2017-03-13 00:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 00:45:53 --> Controller Class Initialized
INFO - 2017-03-13 00:45:53 --> Helper loaded: url_helper
DEBUG - 2017-03-13 00:45:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 00:45:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 00:45:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 00:45:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 00:45:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 00:45:53 --> Final output sent to browser
DEBUG - 2017-03-13 00:45:53 --> Total execution time: 1.5010
INFO - 2017-03-13 00:45:59 --> Config Class Initialized
INFO - 2017-03-13 00:45:59 --> Hooks Class Initialized
DEBUG - 2017-03-13 00:45:59 --> UTF-8 Support Enabled
INFO - 2017-03-13 00:45:59 --> Utf8 Class Initialized
INFO - 2017-03-13 00:45:59 --> URI Class Initialized
INFO - 2017-03-13 00:45:59 --> Router Class Initialized
INFO - 2017-03-13 00:45:59 --> Output Class Initialized
INFO - 2017-03-13 00:45:59 --> Security Class Initialized
DEBUG - 2017-03-13 00:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 00:45:59 --> Input Class Initialized
INFO - 2017-03-13 00:45:59 --> Language Class Initialized
INFO - 2017-03-13 00:45:59 --> Loader Class Initialized
INFO - 2017-03-13 00:45:59 --> Database Driver Class Initialized
INFO - 2017-03-13 00:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 00:45:59 --> Controller Class Initialized
INFO - 2017-03-13 00:45:59 --> Helper loaded: url_helper
DEBUG - 2017-03-13 00:45:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 00:45:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 00:45:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 00:45:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 00:45:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 00:45:59 --> Final output sent to browser
DEBUG - 2017-03-13 00:45:59 --> Total execution time: 0.0135
INFO - 2017-03-13 00:46:32 --> Config Class Initialized
INFO - 2017-03-13 00:46:32 --> Hooks Class Initialized
DEBUG - 2017-03-13 00:46:32 --> UTF-8 Support Enabled
INFO - 2017-03-13 00:46:32 --> Utf8 Class Initialized
INFO - 2017-03-13 00:46:32 --> URI Class Initialized
INFO - 2017-03-13 00:46:32 --> Router Class Initialized
INFO - 2017-03-13 00:46:32 --> Output Class Initialized
INFO - 2017-03-13 00:46:32 --> Security Class Initialized
DEBUG - 2017-03-13 00:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 00:46:32 --> Input Class Initialized
INFO - 2017-03-13 00:46:32 --> Language Class Initialized
INFO - 2017-03-13 00:46:32 --> Loader Class Initialized
INFO - 2017-03-13 00:46:32 --> Database Driver Class Initialized
INFO - 2017-03-13 00:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 00:46:32 --> Controller Class Initialized
INFO - 2017-03-13 00:46:32 --> Helper loaded: url_helper
DEBUG - 2017-03-13 00:46:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 00:46:33 --> Config Class Initialized
INFO - 2017-03-13 00:46:33 --> Hooks Class Initialized
DEBUG - 2017-03-13 00:46:33 --> UTF-8 Support Enabled
INFO - 2017-03-13 00:46:33 --> Utf8 Class Initialized
INFO - 2017-03-13 00:46:33 --> URI Class Initialized
INFO - 2017-03-13 00:46:33 --> Router Class Initialized
INFO - 2017-03-13 00:46:33 --> Output Class Initialized
INFO - 2017-03-13 00:46:33 --> Security Class Initialized
DEBUG - 2017-03-13 00:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 00:46:33 --> Input Class Initialized
INFO - 2017-03-13 00:46:33 --> Language Class Initialized
INFO - 2017-03-13 00:46:33 --> Loader Class Initialized
INFO - 2017-03-13 00:46:33 --> Database Driver Class Initialized
INFO - 2017-03-13 00:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 00:46:33 --> Controller Class Initialized
INFO - 2017-03-13 00:46:33 --> Helper loaded: date_helper
DEBUG - 2017-03-13 00:46:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 00:46:33 --> Helper loaded: url_helper
INFO - 2017-03-13 00:46:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 00:46:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 00:46:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 00:46:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 00:46:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 00:46:33 --> Final output sent to browser
DEBUG - 2017-03-13 00:46:33 --> Total execution time: 0.1087
INFO - 2017-03-13 00:46:34 --> Config Class Initialized
INFO - 2017-03-13 00:46:34 --> Hooks Class Initialized
DEBUG - 2017-03-13 00:46:34 --> UTF-8 Support Enabled
INFO - 2017-03-13 00:46:34 --> Utf8 Class Initialized
INFO - 2017-03-13 00:46:34 --> URI Class Initialized
INFO - 2017-03-13 00:46:34 --> Router Class Initialized
INFO - 2017-03-13 00:46:34 --> Output Class Initialized
INFO - 2017-03-13 00:46:34 --> Security Class Initialized
DEBUG - 2017-03-13 00:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 00:46:34 --> Input Class Initialized
INFO - 2017-03-13 00:46:34 --> Language Class Initialized
INFO - 2017-03-13 00:46:34 --> Loader Class Initialized
INFO - 2017-03-13 00:46:35 --> Database Driver Class Initialized
INFO - 2017-03-13 00:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 00:46:35 --> Controller Class Initialized
INFO - 2017-03-13 00:46:35 --> Helper loaded: url_helper
DEBUG - 2017-03-13 00:46:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 00:46:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 00:46:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 00:46:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 00:46:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 00:46:35 --> Final output sent to browser
DEBUG - 2017-03-13 00:46:35 --> Total execution time: 1.2073
INFO - 2017-03-13 00:46:43 --> Config Class Initialized
INFO - 2017-03-13 00:46:43 --> Hooks Class Initialized
DEBUG - 2017-03-13 00:46:43 --> UTF-8 Support Enabled
INFO - 2017-03-13 00:46:43 --> Utf8 Class Initialized
INFO - 2017-03-13 00:46:43 --> URI Class Initialized
DEBUG - 2017-03-13 00:46:43 --> No URI present. Default controller set.
INFO - 2017-03-13 00:46:43 --> Router Class Initialized
INFO - 2017-03-13 00:46:43 --> Output Class Initialized
INFO - 2017-03-13 00:46:43 --> Security Class Initialized
DEBUG - 2017-03-13 00:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 00:46:43 --> Input Class Initialized
INFO - 2017-03-13 00:46:43 --> Language Class Initialized
INFO - 2017-03-13 00:46:43 --> Loader Class Initialized
INFO - 2017-03-13 00:46:44 --> Database Driver Class Initialized
INFO - 2017-03-13 00:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 00:46:44 --> Controller Class Initialized
INFO - 2017-03-13 00:46:44 --> Helper loaded: url_helper
DEBUG - 2017-03-13 00:46:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 00:46:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 00:46:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 00:46:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 00:46:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 00:46:44 --> Final output sent to browser
DEBUG - 2017-03-13 00:46:44 --> Total execution time: 1.2188
INFO - 2017-03-13 00:46:45 --> Config Class Initialized
INFO - 2017-03-13 00:46:45 --> Hooks Class Initialized
DEBUG - 2017-03-13 00:46:45 --> UTF-8 Support Enabled
INFO - 2017-03-13 00:46:45 --> Utf8 Class Initialized
INFO - 2017-03-13 00:46:45 --> URI Class Initialized
INFO - 2017-03-13 00:46:45 --> Router Class Initialized
INFO - 2017-03-13 00:46:45 --> Output Class Initialized
INFO - 2017-03-13 00:46:45 --> Security Class Initialized
DEBUG - 2017-03-13 00:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 00:46:45 --> Input Class Initialized
INFO - 2017-03-13 00:46:45 --> Language Class Initialized
INFO - 2017-03-13 00:46:45 --> Loader Class Initialized
INFO - 2017-03-13 00:46:45 --> Database Driver Class Initialized
INFO - 2017-03-13 00:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 00:46:45 --> Controller Class Initialized
INFO - 2017-03-13 00:46:45 --> Helper loaded: url_helper
DEBUG - 2017-03-13 00:46:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 00:46:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 00:46:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 00:46:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 00:46:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 00:46:45 --> Final output sent to browser
DEBUG - 2017-03-13 00:46:45 --> Total execution time: 0.0136
INFO - 2017-03-13 00:47:01 --> Config Class Initialized
INFO - 2017-03-13 00:47:01 --> Hooks Class Initialized
DEBUG - 2017-03-13 00:47:01 --> UTF-8 Support Enabled
INFO - 2017-03-13 00:47:01 --> Utf8 Class Initialized
INFO - 2017-03-13 00:47:01 --> URI Class Initialized
INFO - 2017-03-13 00:47:01 --> Router Class Initialized
INFO - 2017-03-13 00:47:01 --> Output Class Initialized
INFO - 2017-03-13 00:47:01 --> Security Class Initialized
DEBUG - 2017-03-13 00:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 00:47:01 --> Input Class Initialized
INFO - 2017-03-13 00:47:01 --> Language Class Initialized
INFO - 2017-03-13 00:47:01 --> Loader Class Initialized
INFO - 2017-03-13 00:47:01 --> Database Driver Class Initialized
INFO - 2017-03-13 00:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 00:47:01 --> Controller Class Initialized
INFO - 2017-03-13 00:47:01 --> Helper loaded: url_helper
DEBUG - 2017-03-13 00:47:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 00:47:01 --> Config Class Initialized
INFO - 2017-03-13 00:47:01 --> Hooks Class Initialized
DEBUG - 2017-03-13 00:47:01 --> UTF-8 Support Enabled
INFO - 2017-03-13 00:47:01 --> Utf8 Class Initialized
INFO - 2017-03-13 00:47:01 --> URI Class Initialized
INFO - 2017-03-13 00:47:01 --> Router Class Initialized
INFO - 2017-03-13 00:47:01 --> Output Class Initialized
INFO - 2017-03-13 00:47:01 --> Security Class Initialized
DEBUG - 2017-03-13 00:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 00:47:01 --> Input Class Initialized
INFO - 2017-03-13 00:47:01 --> Language Class Initialized
INFO - 2017-03-13 00:47:01 --> Loader Class Initialized
INFO - 2017-03-13 00:47:01 --> Database Driver Class Initialized
INFO - 2017-03-13 00:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 00:47:01 --> Controller Class Initialized
INFO - 2017-03-13 00:47:01 --> Helper loaded: date_helper
DEBUG - 2017-03-13 00:47:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 00:47:01 --> Helper loaded: url_helper
INFO - 2017-03-13 00:47:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 00:47:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 00:47:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 00:47:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 00:47:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 00:47:02 --> Final output sent to browser
DEBUG - 2017-03-13 00:47:02 --> Total execution time: 0.3573
INFO - 2017-03-13 00:47:02 --> Config Class Initialized
INFO - 2017-03-13 00:47:02 --> Hooks Class Initialized
DEBUG - 2017-03-13 00:47:02 --> UTF-8 Support Enabled
INFO - 2017-03-13 00:47:02 --> Utf8 Class Initialized
INFO - 2017-03-13 00:47:02 --> URI Class Initialized
INFO - 2017-03-13 00:47:02 --> Router Class Initialized
INFO - 2017-03-13 00:47:02 --> Output Class Initialized
INFO - 2017-03-13 00:47:02 --> Security Class Initialized
DEBUG - 2017-03-13 00:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 00:47:02 --> Input Class Initialized
INFO - 2017-03-13 00:47:02 --> Language Class Initialized
INFO - 2017-03-13 00:47:02 --> Loader Class Initialized
INFO - 2017-03-13 00:47:02 --> Database Driver Class Initialized
INFO - 2017-03-13 00:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 00:47:02 --> Controller Class Initialized
INFO - 2017-03-13 00:47:02 --> Helper loaded: url_helper
DEBUG - 2017-03-13 00:47:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 00:47:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 00:47:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 00:47:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 00:47:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 00:47:02 --> Final output sent to browser
DEBUG - 2017-03-13 00:47:02 --> Total execution time: 0.0139
INFO - 2017-03-13 00:47:04 --> Config Class Initialized
INFO - 2017-03-13 00:47:04 --> Hooks Class Initialized
DEBUG - 2017-03-13 00:47:04 --> UTF-8 Support Enabled
INFO - 2017-03-13 00:47:04 --> Utf8 Class Initialized
INFO - 2017-03-13 00:47:04 --> URI Class Initialized
DEBUG - 2017-03-13 00:47:04 --> No URI present. Default controller set.
INFO - 2017-03-13 00:47:04 --> Router Class Initialized
INFO - 2017-03-13 00:47:04 --> Output Class Initialized
INFO - 2017-03-13 00:47:04 --> Security Class Initialized
DEBUG - 2017-03-13 00:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 00:47:04 --> Input Class Initialized
INFO - 2017-03-13 00:47:04 --> Language Class Initialized
INFO - 2017-03-13 00:47:04 --> Loader Class Initialized
INFO - 2017-03-13 00:47:04 --> Database Driver Class Initialized
INFO - 2017-03-13 00:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 00:47:04 --> Controller Class Initialized
INFO - 2017-03-13 00:47:04 --> Helper loaded: url_helper
DEBUG - 2017-03-13 00:47:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 00:47:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 00:47:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 00:47:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 00:47:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 00:47:04 --> Final output sent to browser
DEBUG - 2017-03-13 00:47:04 --> Total execution time: 0.0134
INFO - 2017-03-13 00:47:05 --> Config Class Initialized
INFO - 2017-03-13 00:47:05 --> Hooks Class Initialized
DEBUG - 2017-03-13 00:47:05 --> UTF-8 Support Enabled
INFO - 2017-03-13 00:47:05 --> Utf8 Class Initialized
INFO - 2017-03-13 00:47:05 --> URI Class Initialized
INFO - 2017-03-13 00:47:05 --> Router Class Initialized
INFO - 2017-03-13 00:47:05 --> Output Class Initialized
INFO - 2017-03-13 00:47:05 --> Security Class Initialized
DEBUG - 2017-03-13 00:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 00:47:05 --> Input Class Initialized
INFO - 2017-03-13 00:47:05 --> Language Class Initialized
INFO - 2017-03-13 00:47:05 --> Loader Class Initialized
INFO - 2017-03-13 00:47:05 --> Database Driver Class Initialized
INFO - 2017-03-13 00:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 00:47:05 --> Controller Class Initialized
INFO - 2017-03-13 00:47:05 --> Helper loaded: url_helper
DEBUG - 2017-03-13 00:47:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 00:47:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 00:47:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 00:47:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 00:47:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 00:47:05 --> Final output sent to browser
DEBUG - 2017-03-13 00:47:05 --> Total execution time: 0.0136
INFO - 2017-03-13 01:31:37 --> Config Class Initialized
INFO - 2017-03-13 01:31:37 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:31:37 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:31:37 --> Utf8 Class Initialized
INFO - 2017-03-13 01:31:37 --> URI Class Initialized
DEBUG - 2017-03-13 01:31:37 --> No URI present. Default controller set.
INFO - 2017-03-13 01:31:37 --> Router Class Initialized
INFO - 2017-03-13 01:31:37 --> Output Class Initialized
INFO - 2017-03-13 01:31:37 --> Security Class Initialized
DEBUG - 2017-03-13 01:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:31:37 --> Input Class Initialized
INFO - 2017-03-13 01:31:37 --> Language Class Initialized
INFO - 2017-03-13 01:31:37 --> Loader Class Initialized
INFO - 2017-03-13 01:31:37 --> Database Driver Class Initialized
INFO - 2017-03-13 01:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:31:38 --> Controller Class Initialized
INFO - 2017-03-13 01:31:38 --> Helper loaded: url_helper
DEBUG - 2017-03-13 01:31:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:31:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 01:31:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 01:31:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 01:31:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 01:31:38 --> Final output sent to browser
DEBUG - 2017-03-13 01:31:38 --> Total execution time: 1.4865
INFO - 2017-03-13 01:31:43 --> Config Class Initialized
INFO - 2017-03-13 01:31:43 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:31:43 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:31:43 --> Utf8 Class Initialized
INFO - 2017-03-13 01:31:43 --> URI Class Initialized
INFO - 2017-03-13 01:31:43 --> Router Class Initialized
INFO - 2017-03-13 01:31:43 --> Output Class Initialized
INFO - 2017-03-13 01:31:43 --> Security Class Initialized
DEBUG - 2017-03-13 01:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:31:43 --> Input Class Initialized
INFO - 2017-03-13 01:31:43 --> Language Class Initialized
INFO - 2017-03-13 01:31:43 --> Loader Class Initialized
INFO - 2017-03-13 01:31:43 --> Database Driver Class Initialized
INFO - 2017-03-13 01:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:31:43 --> Controller Class Initialized
INFO - 2017-03-13 01:31:43 --> Helper loaded: url_helper
DEBUG - 2017-03-13 01:31:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:31:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 01:31:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 01:31:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 01:31:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 01:31:43 --> Final output sent to browser
DEBUG - 2017-03-13 01:31:43 --> Total execution time: 0.0135
INFO - 2017-03-13 01:33:08 --> Config Class Initialized
INFO - 2017-03-13 01:33:08 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:33:08 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:33:08 --> Utf8 Class Initialized
INFO - 2017-03-13 01:33:08 --> URI Class Initialized
INFO - 2017-03-13 01:33:08 --> Router Class Initialized
INFO - 2017-03-13 01:33:08 --> Output Class Initialized
INFO - 2017-03-13 01:33:08 --> Security Class Initialized
DEBUG - 2017-03-13 01:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:33:08 --> Input Class Initialized
INFO - 2017-03-13 01:33:08 --> Language Class Initialized
INFO - 2017-03-13 01:33:08 --> Loader Class Initialized
INFO - 2017-03-13 01:33:08 --> Database Driver Class Initialized
INFO - 2017-03-13 01:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:33:08 --> Controller Class Initialized
INFO - 2017-03-13 01:33:08 --> Helper loaded: url_helper
DEBUG - 2017-03-13 01:33:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:33:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 01:33:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 01:33:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 01:33:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 01:33:08 --> Final output sent to browser
DEBUG - 2017-03-13 01:33:08 --> Total execution time: 0.0327
INFO - 2017-03-13 01:33:12 --> Config Class Initialized
INFO - 2017-03-13 01:33:12 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:33:12 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:33:12 --> Utf8 Class Initialized
INFO - 2017-03-13 01:33:12 --> URI Class Initialized
INFO - 2017-03-13 01:33:12 --> Router Class Initialized
INFO - 2017-03-13 01:33:12 --> Output Class Initialized
INFO - 2017-03-13 01:33:12 --> Security Class Initialized
DEBUG - 2017-03-13 01:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:33:12 --> Input Class Initialized
INFO - 2017-03-13 01:33:12 --> Language Class Initialized
INFO - 2017-03-13 01:33:12 --> Loader Class Initialized
INFO - 2017-03-13 01:33:12 --> Database Driver Class Initialized
INFO - 2017-03-13 01:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:33:12 --> Controller Class Initialized
INFO - 2017-03-13 01:33:12 --> Helper loaded: url_helper
DEBUG - 2017-03-13 01:33:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:33:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 01:33:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 01:33:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 01:33:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 01:33:12 --> Final output sent to browser
DEBUG - 2017-03-13 01:33:12 --> Total execution time: 0.0138
INFO - 2017-03-13 01:33:38 --> Config Class Initialized
INFO - 2017-03-13 01:33:38 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:33:38 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:33:38 --> Utf8 Class Initialized
INFO - 2017-03-13 01:33:38 --> URI Class Initialized
INFO - 2017-03-13 01:33:38 --> Router Class Initialized
INFO - 2017-03-13 01:33:38 --> Output Class Initialized
INFO - 2017-03-13 01:33:38 --> Security Class Initialized
DEBUG - 2017-03-13 01:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:33:38 --> Input Class Initialized
INFO - 2017-03-13 01:33:38 --> Language Class Initialized
INFO - 2017-03-13 01:33:38 --> Loader Class Initialized
INFO - 2017-03-13 01:33:38 --> Database Driver Class Initialized
INFO - 2017-03-13 01:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:33:38 --> Controller Class Initialized
INFO - 2017-03-13 01:33:38 --> Helper loaded: url_helper
DEBUG - 2017-03-13 01:33:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:33:40 --> Config Class Initialized
INFO - 2017-03-13 01:33:40 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:33:40 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:33:40 --> Utf8 Class Initialized
INFO - 2017-03-13 01:33:40 --> URI Class Initialized
INFO - 2017-03-13 01:33:40 --> Router Class Initialized
INFO - 2017-03-13 01:33:40 --> Output Class Initialized
INFO - 2017-03-13 01:33:40 --> Security Class Initialized
DEBUG - 2017-03-13 01:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:33:40 --> Input Class Initialized
INFO - 2017-03-13 01:33:40 --> Language Class Initialized
INFO - 2017-03-13 01:33:40 --> Loader Class Initialized
INFO - 2017-03-13 01:33:40 --> Database Driver Class Initialized
INFO - 2017-03-13 01:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:33:40 --> Controller Class Initialized
INFO - 2017-03-13 01:33:40 --> Helper loaded: date_helper
DEBUG - 2017-03-13 01:33:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:33:40 --> Helper loaded: url_helper
INFO - 2017-03-13 01:33:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 01:33:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 01:33:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 01:33:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 01:33:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 01:33:40 --> Final output sent to browser
DEBUG - 2017-03-13 01:33:40 --> Total execution time: 0.0858
INFO - 2017-03-13 01:33:41 --> Config Class Initialized
INFO - 2017-03-13 01:33:41 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:33:41 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:33:41 --> Utf8 Class Initialized
INFO - 2017-03-13 01:33:41 --> URI Class Initialized
INFO - 2017-03-13 01:33:41 --> Router Class Initialized
INFO - 2017-03-13 01:33:41 --> Output Class Initialized
INFO - 2017-03-13 01:33:41 --> Security Class Initialized
DEBUG - 2017-03-13 01:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:33:41 --> Input Class Initialized
INFO - 2017-03-13 01:33:41 --> Language Class Initialized
INFO - 2017-03-13 01:33:41 --> Loader Class Initialized
INFO - 2017-03-13 01:33:41 --> Database Driver Class Initialized
INFO - 2017-03-13 01:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:33:41 --> Controller Class Initialized
INFO - 2017-03-13 01:33:41 --> Helper loaded: url_helper
DEBUG - 2017-03-13 01:33:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:33:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 01:33:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 01:33:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 01:33:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 01:33:41 --> Final output sent to browser
DEBUG - 2017-03-13 01:33:41 --> Total execution time: 0.0135
INFO - 2017-03-13 01:33:54 --> Config Class Initialized
INFO - 2017-03-13 01:33:54 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:33:54 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:33:54 --> Utf8 Class Initialized
INFO - 2017-03-13 01:33:54 --> URI Class Initialized
INFO - 2017-03-13 01:33:54 --> Router Class Initialized
INFO - 2017-03-13 01:33:54 --> Output Class Initialized
INFO - 2017-03-13 01:33:54 --> Security Class Initialized
DEBUG - 2017-03-13 01:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:33:54 --> Input Class Initialized
INFO - 2017-03-13 01:33:54 --> Language Class Initialized
INFO - 2017-03-13 01:33:54 --> Loader Class Initialized
INFO - 2017-03-13 01:33:54 --> Database Driver Class Initialized
INFO - 2017-03-13 01:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:33:54 --> Controller Class Initialized
INFO - 2017-03-13 01:33:54 --> Helper loaded: url_helper
DEBUG - 2017-03-13 01:33:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:33:55 --> Config Class Initialized
INFO - 2017-03-13 01:33:55 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:33:55 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:33:55 --> Utf8 Class Initialized
INFO - 2017-03-13 01:33:55 --> URI Class Initialized
INFO - 2017-03-13 01:33:55 --> Router Class Initialized
INFO - 2017-03-13 01:33:55 --> Output Class Initialized
INFO - 2017-03-13 01:33:55 --> Security Class Initialized
DEBUG - 2017-03-13 01:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:33:55 --> Input Class Initialized
INFO - 2017-03-13 01:33:55 --> Language Class Initialized
INFO - 2017-03-13 01:33:55 --> Loader Class Initialized
INFO - 2017-03-13 01:33:55 --> Database Driver Class Initialized
INFO - 2017-03-13 01:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:33:55 --> Controller Class Initialized
INFO - 2017-03-13 01:33:55 --> Helper loaded: date_helper
DEBUG - 2017-03-13 01:33:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:33:55 --> Helper loaded: url_helper
INFO - 2017-03-13 01:33:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 01:33:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 01:33:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 01:33:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 01:33:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 01:33:55 --> Final output sent to browser
DEBUG - 2017-03-13 01:33:55 --> Total execution time: 0.0138
INFO - 2017-03-13 01:33:57 --> Config Class Initialized
INFO - 2017-03-13 01:33:57 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:33:57 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:33:57 --> Utf8 Class Initialized
INFO - 2017-03-13 01:33:57 --> URI Class Initialized
INFO - 2017-03-13 01:33:57 --> Router Class Initialized
INFO - 2017-03-13 01:33:57 --> Output Class Initialized
INFO - 2017-03-13 01:33:57 --> Security Class Initialized
DEBUG - 2017-03-13 01:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:33:57 --> Input Class Initialized
INFO - 2017-03-13 01:33:57 --> Language Class Initialized
INFO - 2017-03-13 01:33:57 --> Loader Class Initialized
INFO - 2017-03-13 01:33:57 --> Database Driver Class Initialized
INFO - 2017-03-13 01:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:33:57 --> Controller Class Initialized
INFO - 2017-03-13 01:33:57 --> Helper loaded: url_helper
DEBUG - 2017-03-13 01:33:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:33:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 01:33:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 01:33:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 01:33:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 01:33:57 --> Final output sent to browser
DEBUG - 2017-03-13 01:33:57 --> Total execution time: 0.0136
INFO - 2017-03-13 01:34:00 --> Config Class Initialized
INFO - 2017-03-13 01:34:00 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:34:00 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:34:00 --> Utf8 Class Initialized
INFO - 2017-03-13 01:34:00 --> URI Class Initialized
DEBUG - 2017-03-13 01:34:00 --> No URI present. Default controller set.
INFO - 2017-03-13 01:34:00 --> Router Class Initialized
INFO - 2017-03-13 01:34:00 --> Output Class Initialized
INFO - 2017-03-13 01:34:00 --> Security Class Initialized
DEBUG - 2017-03-13 01:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:34:00 --> Input Class Initialized
INFO - 2017-03-13 01:34:00 --> Language Class Initialized
INFO - 2017-03-13 01:34:00 --> Loader Class Initialized
INFO - 2017-03-13 01:34:00 --> Database Driver Class Initialized
INFO - 2017-03-13 01:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:34:00 --> Controller Class Initialized
INFO - 2017-03-13 01:34:00 --> Helper loaded: url_helper
DEBUG - 2017-03-13 01:34:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:34:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 01:34:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 01:34:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 01:34:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 01:34:00 --> Final output sent to browser
DEBUG - 2017-03-13 01:34:00 --> Total execution time: 0.0136
INFO - 2017-03-13 01:34:03 --> Config Class Initialized
INFO - 2017-03-13 01:34:03 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:34:03 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:34:03 --> Utf8 Class Initialized
INFO - 2017-03-13 01:34:03 --> URI Class Initialized
INFO - 2017-03-13 01:34:03 --> Router Class Initialized
INFO - 2017-03-13 01:34:03 --> Output Class Initialized
INFO - 2017-03-13 01:34:03 --> Security Class Initialized
DEBUG - 2017-03-13 01:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:34:03 --> Input Class Initialized
INFO - 2017-03-13 01:34:03 --> Language Class Initialized
INFO - 2017-03-13 01:34:03 --> Loader Class Initialized
INFO - 2017-03-13 01:34:03 --> Database Driver Class Initialized
INFO - 2017-03-13 01:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:34:03 --> Controller Class Initialized
INFO - 2017-03-13 01:34:03 --> Helper loaded: url_helper
DEBUG - 2017-03-13 01:34:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:34:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 01:34:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 01:34:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 01:34:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 01:34:03 --> Final output sent to browser
DEBUG - 2017-03-13 01:34:03 --> Total execution time: 0.0134
INFO - 2017-03-13 01:34:09 --> Config Class Initialized
INFO - 2017-03-13 01:34:09 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:34:09 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:34:09 --> Utf8 Class Initialized
INFO - 2017-03-13 01:34:09 --> URI Class Initialized
INFO - 2017-03-13 01:34:09 --> Router Class Initialized
INFO - 2017-03-13 01:34:09 --> Output Class Initialized
INFO - 2017-03-13 01:34:09 --> Security Class Initialized
DEBUG - 2017-03-13 01:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:34:09 --> Input Class Initialized
INFO - 2017-03-13 01:34:09 --> Language Class Initialized
INFO - 2017-03-13 01:34:09 --> Loader Class Initialized
INFO - 2017-03-13 01:34:09 --> Database Driver Class Initialized
INFO - 2017-03-13 01:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:34:09 --> Controller Class Initialized
INFO - 2017-03-13 01:34:09 --> Helper loaded: url_helper
DEBUG - 2017-03-13 01:34:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:34:10 --> Config Class Initialized
INFO - 2017-03-13 01:34:10 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:34:10 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:34:10 --> Utf8 Class Initialized
INFO - 2017-03-13 01:34:10 --> URI Class Initialized
INFO - 2017-03-13 01:34:10 --> Router Class Initialized
INFO - 2017-03-13 01:34:10 --> Output Class Initialized
INFO - 2017-03-13 01:34:10 --> Security Class Initialized
DEBUG - 2017-03-13 01:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:34:10 --> Input Class Initialized
INFO - 2017-03-13 01:34:10 --> Language Class Initialized
INFO - 2017-03-13 01:34:10 --> Loader Class Initialized
INFO - 2017-03-13 01:34:10 --> Database Driver Class Initialized
INFO - 2017-03-13 01:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:34:10 --> Controller Class Initialized
INFO - 2017-03-13 01:34:10 --> Helper loaded: date_helper
DEBUG - 2017-03-13 01:34:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:34:10 --> Helper loaded: url_helper
INFO - 2017-03-13 01:34:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 01:34:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 01:34:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 01:34:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 01:34:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 01:34:10 --> Final output sent to browser
DEBUG - 2017-03-13 01:34:10 --> Total execution time: 0.0142
INFO - 2017-03-13 01:34:11 --> Config Class Initialized
INFO - 2017-03-13 01:34:11 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:34:11 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:34:11 --> Utf8 Class Initialized
INFO - 2017-03-13 01:34:11 --> URI Class Initialized
INFO - 2017-03-13 01:34:11 --> Router Class Initialized
INFO - 2017-03-13 01:34:11 --> Output Class Initialized
INFO - 2017-03-13 01:34:11 --> Security Class Initialized
DEBUG - 2017-03-13 01:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:34:11 --> Input Class Initialized
INFO - 2017-03-13 01:34:11 --> Language Class Initialized
INFO - 2017-03-13 01:34:11 --> Loader Class Initialized
INFO - 2017-03-13 01:34:11 --> Database Driver Class Initialized
INFO - 2017-03-13 01:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:34:11 --> Controller Class Initialized
INFO - 2017-03-13 01:34:11 --> Helper loaded: url_helper
DEBUG - 2017-03-13 01:34:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:34:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 01:34:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 01:34:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 01:34:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 01:34:11 --> Final output sent to browser
DEBUG - 2017-03-13 01:34:11 --> Total execution time: 0.0133
INFO - 2017-03-13 01:34:20 --> Config Class Initialized
INFO - 2017-03-13 01:34:20 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:34:20 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:34:20 --> Utf8 Class Initialized
INFO - 2017-03-13 01:34:20 --> URI Class Initialized
DEBUG - 2017-03-13 01:34:20 --> No URI present. Default controller set.
INFO - 2017-03-13 01:34:20 --> Router Class Initialized
INFO - 2017-03-13 01:34:20 --> Output Class Initialized
INFO - 2017-03-13 01:34:20 --> Security Class Initialized
DEBUG - 2017-03-13 01:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:34:20 --> Input Class Initialized
INFO - 2017-03-13 01:34:20 --> Language Class Initialized
INFO - 2017-03-13 01:34:20 --> Loader Class Initialized
INFO - 2017-03-13 01:34:20 --> Database Driver Class Initialized
INFO - 2017-03-13 01:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:34:20 --> Controller Class Initialized
INFO - 2017-03-13 01:34:20 --> Helper loaded: url_helper
DEBUG - 2017-03-13 01:34:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:34:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 01:34:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 01:34:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 01:34:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 01:34:20 --> Final output sent to browser
DEBUG - 2017-03-13 01:34:20 --> Total execution time: 0.0135
INFO - 2017-03-13 01:34:22 --> Config Class Initialized
INFO - 2017-03-13 01:34:22 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:34:22 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:34:22 --> Utf8 Class Initialized
INFO - 2017-03-13 01:34:22 --> URI Class Initialized
INFO - 2017-03-13 01:34:22 --> Router Class Initialized
INFO - 2017-03-13 01:34:22 --> Output Class Initialized
INFO - 2017-03-13 01:34:22 --> Security Class Initialized
DEBUG - 2017-03-13 01:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:34:22 --> Input Class Initialized
INFO - 2017-03-13 01:34:22 --> Language Class Initialized
INFO - 2017-03-13 01:34:22 --> Loader Class Initialized
INFO - 2017-03-13 01:34:22 --> Database Driver Class Initialized
INFO - 2017-03-13 01:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:34:22 --> Controller Class Initialized
INFO - 2017-03-13 01:34:22 --> Helper loaded: url_helper
DEBUG - 2017-03-13 01:34:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:34:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 01:34:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 01:34:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 01:34:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 01:34:22 --> Final output sent to browser
DEBUG - 2017-03-13 01:34:22 --> Total execution time: 0.0134
INFO - 2017-03-13 01:35:32 --> Config Class Initialized
INFO - 2017-03-13 01:35:32 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:35:32 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:35:32 --> Utf8 Class Initialized
INFO - 2017-03-13 01:35:32 --> URI Class Initialized
INFO - 2017-03-13 01:35:32 --> Router Class Initialized
INFO - 2017-03-13 01:35:32 --> Output Class Initialized
INFO - 2017-03-13 01:35:32 --> Security Class Initialized
DEBUG - 2017-03-13 01:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:35:32 --> Input Class Initialized
INFO - 2017-03-13 01:35:32 --> Language Class Initialized
INFO - 2017-03-13 01:35:32 --> Loader Class Initialized
INFO - 2017-03-13 01:35:33 --> Database Driver Class Initialized
INFO - 2017-03-13 01:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:35:33 --> Controller Class Initialized
INFO - 2017-03-13 01:35:33 --> Helper loaded: url_helper
DEBUG - 2017-03-13 01:35:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:35:34 --> Config Class Initialized
INFO - 2017-03-13 01:35:34 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:35:34 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:35:34 --> Utf8 Class Initialized
INFO - 2017-03-13 01:35:34 --> URI Class Initialized
INFO - 2017-03-13 01:35:34 --> Router Class Initialized
INFO - 2017-03-13 01:35:34 --> Output Class Initialized
INFO - 2017-03-13 01:35:34 --> Security Class Initialized
DEBUG - 2017-03-13 01:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:35:34 --> Input Class Initialized
INFO - 2017-03-13 01:35:34 --> Language Class Initialized
INFO - 2017-03-13 01:35:34 --> Loader Class Initialized
INFO - 2017-03-13 01:35:34 --> Database Driver Class Initialized
INFO - 2017-03-13 01:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:35:34 --> Controller Class Initialized
INFO - 2017-03-13 01:35:34 --> Helper loaded: date_helper
DEBUG - 2017-03-13 01:35:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:35:34 --> Helper loaded: url_helper
INFO - 2017-03-13 01:35:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 01:35:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 01:35:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 01:35:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 01:35:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 01:35:34 --> Final output sent to browser
DEBUG - 2017-03-13 01:35:34 --> Total execution time: 0.1218
INFO - 2017-03-13 01:35:36 --> Config Class Initialized
INFO - 2017-03-13 01:35:36 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:35:36 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:35:36 --> Utf8 Class Initialized
INFO - 2017-03-13 01:35:36 --> URI Class Initialized
INFO - 2017-03-13 01:35:36 --> Router Class Initialized
INFO - 2017-03-13 01:35:36 --> Output Class Initialized
INFO - 2017-03-13 01:35:36 --> Security Class Initialized
DEBUG - 2017-03-13 01:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:35:36 --> Input Class Initialized
INFO - 2017-03-13 01:35:36 --> Language Class Initialized
INFO - 2017-03-13 01:35:36 --> Loader Class Initialized
INFO - 2017-03-13 01:35:36 --> Database Driver Class Initialized
INFO - 2017-03-13 01:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:35:36 --> Controller Class Initialized
INFO - 2017-03-13 01:35:36 --> Helper loaded: url_helper
DEBUG - 2017-03-13 01:35:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:35:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 01:35:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 01:35:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 01:35:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 01:35:36 --> Final output sent to browser
DEBUG - 2017-03-13 01:35:36 --> Total execution time: 0.0362
INFO - 2017-03-13 01:35:46 --> Config Class Initialized
INFO - 2017-03-13 01:35:46 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:35:46 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:35:46 --> Utf8 Class Initialized
INFO - 2017-03-13 01:35:46 --> URI Class Initialized
DEBUG - 2017-03-13 01:35:46 --> No URI present. Default controller set.
INFO - 2017-03-13 01:35:46 --> Router Class Initialized
INFO - 2017-03-13 01:35:46 --> Output Class Initialized
INFO - 2017-03-13 01:35:46 --> Security Class Initialized
DEBUG - 2017-03-13 01:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:35:46 --> Input Class Initialized
INFO - 2017-03-13 01:35:46 --> Language Class Initialized
INFO - 2017-03-13 01:35:46 --> Loader Class Initialized
INFO - 2017-03-13 01:35:46 --> Database Driver Class Initialized
INFO - 2017-03-13 01:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:35:46 --> Controller Class Initialized
INFO - 2017-03-13 01:35:46 --> Helper loaded: url_helper
DEBUG - 2017-03-13 01:35:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:35:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 01:35:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 01:35:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 01:35:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 01:35:46 --> Final output sent to browser
DEBUG - 2017-03-13 01:35:46 --> Total execution time: 0.0236
INFO - 2017-03-13 01:35:48 --> Config Class Initialized
INFO - 2017-03-13 01:35:48 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:35:48 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:35:48 --> Utf8 Class Initialized
INFO - 2017-03-13 01:35:48 --> URI Class Initialized
INFO - 2017-03-13 01:35:48 --> Router Class Initialized
INFO - 2017-03-13 01:35:48 --> Output Class Initialized
INFO - 2017-03-13 01:35:48 --> Security Class Initialized
DEBUG - 2017-03-13 01:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:35:48 --> Input Class Initialized
INFO - 2017-03-13 01:35:48 --> Language Class Initialized
INFO - 2017-03-13 01:35:48 --> Loader Class Initialized
INFO - 2017-03-13 01:35:48 --> Database Driver Class Initialized
INFO - 2017-03-13 01:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:35:48 --> Controller Class Initialized
INFO - 2017-03-13 01:35:48 --> Helper loaded: url_helper
DEBUG - 2017-03-13 01:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:35:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 01:35:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 01:35:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 01:35:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 01:35:48 --> Final output sent to browser
DEBUG - 2017-03-13 01:35:48 --> Total execution time: 0.0140
INFO - 2017-03-13 01:35:59 --> Config Class Initialized
INFO - 2017-03-13 01:35:59 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:35:59 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:35:59 --> Utf8 Class Initialized
INFO - 2017-03-13 01:35:59 --> URI Class Initialized
INFO - 2017-03-13 01:35:59 --> Router Class Initialized
INFO - 2017-03-13 01:35:59 --> Output Class Initialized
INFO - 2017-03-13 01:35:59 --> Security Class Initialized
DEBUG - 2017-03-13 01:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:35:59 --> Input Class Initialized
INFO - 2017-03-13 01:35:59 --> Language Class Initialized
INFO - 2017-03-13 01:35:59 --> Loader Class Initialized
INFO - 2017-03-13 01:35:59 --> Database Driver Class Initialized
INFO - 2017-03-13 01:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:35:59 --> Controller Class Initialized
INFO - 2017-03-13 01:35:59 --> Helper loaded: url_helper
DEBUG - 2017-03-13 01:35:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:36:00 --> Config Class Initialized
INFO - 2017-03-13 01:36:00 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:36:00 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:36:00 --> Utf8 Class Initialized
INFO - 2017-03-13 01:36:00 --> URI Class Initialized
INFO - 2017-03-13 01:36:00 --> Router Class Initialized
INFO - 2017-03-13 01:36:00 --> Output Class Initialized
INFO - 2017-03-13 01:36:00 --> Security Class Initialized
DEBUG - 2017-03-13 01:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:36:00 --> Input Class Initialized
INFO - 2017-03-13 01:36:00 --> Language Class Initialized
INFO - 2017-03-13 01:36:00 --> Loader Class Initialized
INFO - 2017-03-13 01:36:00 --> Database Driver Class Initialized
INFO - 2017-03-13 01:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:36:00 --> Controller Class Initialized
INFO - 2017-03-13 01:36:00 --> Helper loaded: date_helper
DEBUG - 2017-03-13 01:36:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:36:00 --> Helper loaded: url_helper
INFO - 2017-03-13 01:36:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 01:36:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 01:36:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 01:36:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 01:36:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 01:36:00 --> Final output sent to browser
DEBUG - 2017-03-13 01:36:00 --> Total execution time: 0.0145
INFO - 2017-03-13 01:36:01 --> Config Class Initialized
INFO - 2017-03-13 01:36:01 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:36:01 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:36:01 --> Utf8 Class Initialized
INFO - 2017-03-13 01:36:01 --> URI Class Initialized
INFO - 2017-03-13 01:36:01 --> Router Class Initialized
INFO - 2017-03-13 01:36:01 --> Output Class Initialized
INFO - 2017-03-13 01:36:01 --> Security Class Initialized
DEBUG - 2017-03-13 01:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:36:01 --> Input Class Initialized
INFO - 2017-03-13 01:36:01 --> Language Class Initialized
INFO - 2017-03-13 01:36:01 --> Loader Class Initialized
INFO - 2017-03-13 01:36:01 --> Database Driver Class Initialized
INFO - 2017-03-13 01:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:36:01 --> Controller Class Initialized
INFO - 2017-03-13 01:36:01 --> Helper loaded: url_helper
DEBUG - 2017-03-13 01:36:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:36:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 01:36:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 01:36:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 01:36:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 01:36:01 --> Final output sent to browser
DEBUG - 2017-03-13 01:36:01 --> Total execution time: 0.0134
INFO - 2017-03-13 01:36:06 --> Config Class Initialized
INFO - 2017-03-13 01:36:06 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:36:06 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:36:06 --> Utf8 Class Initialized
INFO - 2017-03-13 01:36:06 --> URI Class Initialized
DEBUG - 2017-03-13 01:36:06 --> No URI present. Default controller set.
INFO - 2017-03-13 01:36:06 --> Router Class Initialized
INFO - 2017-03-13 01:36:06 --> Output Class Initialized
INFO - 2017-03-13 01:36:06 --> Security Class Initialized
DEBUG - 2017-03-13 01:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:36:06 --> Input Class Initialized
INFO - 2017-03-13 01:36:06 --> Language Class Initialized
INFO - 2017-03-13 01:36:06 --> Loader Class Initialized
INFO - 2017-03-13 01:36:06 --> Database Driver Class Initialized
INFO - 2017-03-13 01:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:36:06 --> Controller Class Initialized
INFO - 2017-03-13 01:36:06 --> Helper loaded: url_helper
DEBUG - 2017-03-13 01:36:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:36:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 01:36:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 01:36:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 01:36:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 01:36:06 --> Final output sent to browser
DEBUG - 2017-03-13 01:36:06 --> Total execution time: 0.0136
INFO - 2017-03-13 01:36:08 --> Config Class Initialized
INFO - 2017-03-13 01:36:08 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:36:08 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:36:08 --> Utf8 Class Initialized
INFO - 2017-03-13 01:36:08 --> URI Class Initialized
INFO - 2017-03-13 01:36:08 --> Router Class Initialized
INFO - 2017-03-13 01:36:08 --> Output Class Initialized
INFO - 2017-03-13 01:36:08 --> Security Class Initialized
DEBUG - 2017-03-13 01:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:36:08 --> Input Class Initialized
INFO - 2017-03-13 01:36:08 --> Language Class Initialized
INFO - 2017-03-13 01:36:08 --> Loader Class Initialized
INFO - 2017-03-13 01:36:08 --> Database Driver Class Initialized
INFO - 2017-03-13 01:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:36:08 --> Controller Class Initialized
INFO - 2017-03-13 01:36:08 --> Helper loaded: url_helper
DEBUG - 2017-03-13 01:36:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:36:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 01:36:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 01:36:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 01:36:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 01:36:08 --> Final output sent to browser
DEBUG - 2017-03-13 01:36:08 --> Total execution time: 0.0138
INFO - 2017-03-13 01:36:35 --> Config Class Initialized
INFO - 2017-03-13 01:36:35 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:36:35 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:36:35 --> Utf8 Class Initialized
INFO - 2017-03-13 01:36:35 --> URI Class Initialized
INFO - 2017-03-13 01:36:35 --> Router Class Initialized
INFO - 2017-03-13 01:36:35 --> Output Class Initialized
INFO - 2017-03-13 01:36:35 --> Security Class Initialized
DEBUG - 2017-03-13 01:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:36:36 --> Input Class Initialized
INFO - 2017-03-13 01:36:36 --> Language Class Initialized
INFO - 2017-03-13 01:36:36 --> Loader Class Initialized
INFO - 2017-03-13 01:36:36 --> Database Driver Class Initialized
INFO - 2017-03-13 01:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:36:36 --> Controller Class Initialized
INFO - 2017-03-13 01:36:36 --> Helper loaded: url_helper
DEBUG - 2017-03-13 01:36:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:36:39 --> Config Class Initialized
INFO - 2017-03-13 01:36:39 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:36:39 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:36:39 --> Utf8 Class Initialized
INFO - 2017-03-13 01:36:39 --> URI Class Initialized
INFO - 2017-03-13 01:36:39 --> Router Class Initialized
INFO - 2017-03-13 01:36:39 --> Output Class Initialized
INFO - 2017-03-13 01:36:39 --> Security Class Initialized
DEBUG - 2017-03-13 01:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:36:39 --> Input Class Initialized
INFO - 2017-03-13 01:36:39 --> Language Class Initialized
INFO - 2017-03-13 01:36:39 --> Loader Class Initialized
INFO - 2017-03-13 01:36:39 --> Database Driver Class Initialized
INFO - 2017-03-13 01:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:36:39 --> Controller Class Initialized
INFO - 2017-03-13 01:36:39 --> Helper loaded: date_helper
DEBUG - 2017-03-13 01:36:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:36:39 --> Helper loaded: url_helper
INFO - 2017-03-13 01:36:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 01:36:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 01:36:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 01:36:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 01:36:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 01:36:39 --> Final output sent to browser
DEBUG - 2017-03-13 01:36:39 --> Total execution time: 0.3730
INFO - 2017-03-13 01:36:40 --> Config Class Initialized
INFO - 2017-03-13 01:36:40 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:36:40 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:36:40 --> Utf8 Class Initialized
INFO - 2017-03-13 01:36:40 --> URI Class Initialized
INFO - 2017-03-13 01:36:40 --> Router Class Initialized
INFO - 2017-03-13 01:36:40 --> Output Class Initialized
INFO - 2017-03-13 01:36:40 --> Security Class Initialized
DEBUG - 2017-03-13 01:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:36:40 --> Input Class Initialized
INFO - 2017-03-13 01:36:40 --> Language Class Initialized
INFO - 2017-03-13 01:36:40 --> Loader Class Initialized
INFO - 2017-03-13 01:36:40 --> Database Driver Class Initialized
INFO - 2017-03-13 01:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:36:40 --> Controller Class Initialized
INFO - 2017-03-13 01:36:40 --> Helper loaded: url_helper
DEBUG - 2017-03-13 01:36:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:36:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 01:36:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 01:36:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 01:36:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 01:36:40 --> Final output sent to browser
DEBUG - 2017-03-13 01:36:40 --> Total execution time: 0.0363
INFO - 2017-03-13 01:36:46 --> Config Class Initialized
INFO - 2017-03-13 01:36:46 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:36:46 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:36:46 --> Utf8 Class Initialized
INFO - 2017-03-13 01:36:46 --> URI Class Initialized
DEBUG - 2017-03-13 01:36:46 --> No URI present. Default controller set.
INFO - 2017-03-13 01:36:46 --> Router Class Initialized
INFO - 2017-03-13 01:36:46 --> Output Class Initialized
INFO - 2017-03-13 01:36:46 --> Security Class Initialized
DEBUG - 2017-03-13 01:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:36:46 --> Input Class Initialized
INFO - 2017-03-13 01:36:46 --> Language Class Initialized
INFO - 2017-03-13 01:36:46 --> Loader Class Initialized
INFO - 2017-03-13 01:36:46 --> Database Driver Class Initialized
INFO - 2017-03-13 01:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:36:46 --> Controller Class Initialized
INFO - 2017-03-13 01:36:46 --> Helper loaded: url_helper
DEBUG - 2017-03-13 01:36:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:36:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 01:36:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 01:36:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 01:36:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 01:36:46 --> Final output sent to browser
DEBUG - 2017-03-13 01:36:46 --> Total execution time: 0.1100
INFO - 2017-03-13 01:36:47 --> Config Class Initialized
INFO - 2017-03-13 01:36:47 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:36:47 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:36:47 --> Utf8 Class Initialized
INFO - 2017-03-13 01:36:47 --> URI Class Initialized
INFO - 2017-03-13 01:36:47 --> Router Class Initialized
INFO - 2017-03-13 01:36:47 --> Output Class Initialized
INFO - 2017-03-13 01:36:47 --> Security Class Initialized
DEBUG - 2017-03-13 01:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:36:47 --> Input Class Initialized
INFO - 2017-03-13 01:36:47 --> Language Class Initialized
INFO - 2017-03-13 01:36:47 --> Loader Class Initialized
INFO - 2017-03-13 01:36:47 --> Database Driver Class Initialized
INFO - 2017-03-13 01:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:36:47 --> Controller Class Initialized
INFO - 2017-03-13 01:36:47 --> Helper loaded: url_helper
DEBUG - 2017-03-13 01:36:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:36:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 01:36:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 01:36:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 01:36:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 01:36:47 --> Final output sent to browser
DEBUG - 2017-03-13 01:36:47 --> Total execution time: 0.0219
INFO - 2017-03-13 01:36:58 --> Config Class Initialized
INFO - 2017-03-13 01:36:58 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:36:58 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:36:58 --> Utf8 Class Initialized
INFO - 2017-03-13 01:36:58 --> URI Class Initialized
INFO - 2017-03-13 01:36:58 --> Router Class Initialized
INFO - 2017-03-13 01:36:58 --> Output Class Initialized
INFO - 2017-03-13 01:36:58 --> Security Class Initialized
DEBUG - 2017-03-13 01:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:36:58 --> Input Class Initialized
INFO - 2017-03-13 01:36:58 --> Language Class Initialized
INFO - 2017-03-13 01:36:58 --> Loader Class Initialized
INFO - 2017-03-13 01:36:58 --> Database Driver Class Initialized
INFO - 2017-03-13 01:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:36:58 --> Controller Class Initialized
INFO - 2017-03-13 01:36:58 --> Helper loaded: url_helper
DEBUG - 2017-03-13 01:36:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:36:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 01:36:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 01:36:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 01:36:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 01:36:58 --> Final output sent to browser
DEBUG - 2017-03-13 01:36:58 --> Total execution time: 0.0152
INFO - 2017-03-13 01:37:00 --> Config Class Initialized
INFO - 2017-03-13 01:37:00 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:37:00 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:37:00 --> Utf8 Class Initialized
INFO - 2017-03-13 01:37:00 --> URI Class Initialized
INFO - 2017-03-13 01:37:00 --> Router Class Initialized
INFO - 2017-03-13 01:37:00 --> Output Class Initialized
INFO - 2017-03-13 01:37:00 --> Security Class Initialized
DEBUG - 2017-03-13 01:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:37:00 --> Input Class Initialized
INFO - 2017-03-13 01:37:00 --> Language Class Initialized
INFO - 2017-03-13 01:37:00 --> Loader Class Initialized
INFO - 2017-03-13 01:37:00 --> Database Driver Class Initialized
INFO - 2017-03-13 01:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:37:00 --> Controller Class Initialized
INFO - 2017-03-13 01:37:00 --> Helper loaded: url_helper
DEBUG - 2017-03-13 01:37:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:37:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 01:37:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 01:37:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 01:37:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 01:37:00 --> Final output sent to browser
DEBUG - 2017-03-13 01:37:00 --> Total execution time: 0.0141
INFO - 2017-03-13 01:37:05 --> Config Class Initialized
INFO - 2017-03-13 01:37:05 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:37:05 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:37:05 --> Utf8 Class Initialized
INFO - 2017-03-13 01:37:05 --> URI Class Initialized
INFO - 2017-03-13 01:37:05 --> Router Class Initialized
INFO - 2017-03-13 01:37:05 --> Output Class Initialized
INFO - 2017-03-13 01:37:05 --> Security Class Initialized
DEBUG - 2017-03-13 01:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:37:05 --> Input Class Initialized
INFO - 2017-03-13 01:37:05 --> Language Class Initialized
INFO - 2017-03-13 01:37:05 --> Loader Class Initialized
INFO - 2017-03-13 01:37:05 --> Database Driver Class Initialized
INFO - 2017-03-13 01:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:37:05 --> Controller Class Initialized
INFO - 2017-03-13 01:37:05 --> Helper loaded: url_helper
DEBUG - 2017-03-13 01:37:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:37:07 --> Config Class Initialized
INFO - 2017-03-13 01:37:07 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:37:07 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:37:07 --> Utf8 Class Initialized
INFO - 2017-03-13 01:37:07 --> URI Class Initialized
INFO - 2017-03-13 01:37:07 --> Router Class Initialized
INFO - 2017-03-13 01:37:07 --> Output Class Initialized
INFO - 2017-03-13 01:37:07 --> Security Class Initialized
DEBUG - 2017-03-13 01:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:37:07 --> Input Class Initialized
INFO - 2017-03-13 01:37:07 --> Language Class Initialized
INFO - 2017-03-13 01:37:07 --> Loader Class Initialized
INFO - 2017-03-13 01:37:07 --> Database Driver Class Initialized
INFO - 2017-03-13 01:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:37:07 --> Controller Class Initialized
INFO - 2017-03-13 01:37:07 --> Helper loaded: date_helper
DEBUG - 2017-03-13 01:37:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:37:07 --> Helper loaded: url_helper
INFO - 2017-03-13 01:37:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 01:37:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 01:37:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 01:37:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 01:37:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 01:37:07 --> Final output sent to browser
DEBUG - 2017-03-13 01:37:07 --> Total execution time: 0.0143
INFO - 2017-03-13 01:37:07 --> Config Class Initialized
INFO - 2017-03-13 01:37:07 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:37:07 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:37:07 --> Utf8 Class Initialized
INFO - 2017-03-13 01:37:07 --> URI Class Initialized
INFO - 2017-03-13 01:37:07 --> Router Class Initialized
INFO - 2017-03-13 01:37:07 --> Output Class Initialized
INFO - 2017-03-13 01:37:07 --> Security Class Initialized
DEBUG - 2017-03-13 01:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:37:07 --> Input Class Initialized
INFO - 2017-03-13 01:37:07 --> Language Class Initialized
INFO - 2017-03-13 01:37:07 --> Loader Class Initialized
INFO - 2017-03-13 01:37:07 --> Database Driver Class Initialized
INFO - 2017-03-13 01:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:37:07 --> Controller Class Initialized
INFO - 2017-03-13 01:37:07 --> Helper loaded: url_helper
DEBUG - 2017-03-13 01:37:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:37:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 01:37:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 01:37:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 01:37:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 01:37:08 --> Final output sent to browser
DEBUG - 2017-03-13 01:37:08 --> Total execution time: 0.0133
INFO - 2017-03-13 01:37:10 --> Config Class Initialized
INFO - 2017-03-13 01:37:10 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:37:10 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:37:10 --> Utf8 Class Initialized
INFO - 2017-03-13 01:37:10 --> URI Class Initialized
DEBUG - 2017-03-13 01:37:10 --> No URI present. Default controller set.
INFO - 2017-03-13 01:37:10 --> Router Class Initialized
INFO - 2017-03-13 01:37:10 --> Output Class Initialized
INFO - 2017-03-13 01:37:10 --> Security Class Initialized
DEBUG - 2017-03-13 01:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:37:10 --> Input Class Initialized
INFO - 2017-03-13 01:37:10 --> Language Class Initialized
INFO - 2017-03-13 01:37:10 --> Loader Class Initialized
INFO - 2017-03-13 01:37:10 --> Database Driver Class Initialized
INFO - 2017-03-13 01:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:37:10 --> Controller Class Initialized
INFO - 2017-03-13 01:37:10 --> Helper loaded: url_helper
DEBUG - 2017-03-13 01:37:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:37:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 01:37:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 01:37:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 01:37:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 01:37:10 --> Final output sent to browser
DEBUG - 2017-03-13 01:37:10 --> Total execution time: 0.0138
INFO - 2017-03-13 01:37:11 --> Config Class Initialized
INFO - 2017-03-13 01:37:11 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:37:11 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:37:11 --> Utf8 Class Initialized
INFO - 2017-03-13 01:37:11 --> URI Class Initialized
INFO - 2017-03-13 01:37:11 --> Router Class Initialized
INFO - 2017-03-13 01:37:11 --> Output Class Initialized
INFO - 2017-03-13 01:37:11 --> Security Class Initialized
DEBUG - 2017-03-13 01:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:37:11 --> Input Class Initialized
INFO - 2017-03-13 01:37:11 --> Language Class Initialized
INFO - 2017-03-13 01:37:11 --> Loader Class Initialized
INFO - 2017-03-13 01:37:11 --> Database Driver Class Initialized
INFO - 2017-03-13 01:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:37:11 --> Controller Class Initialized
INFO - 2017-03-13 01:37:11 --> Helper loaded: url_helper
DEBUG - 2017-03-13 01:37:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:37:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 01:37:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 01:37:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 01:37:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 01:37:11 --> Final output sent to browser
DEBUG - 2017-03-13 01:37:11 --> Total execution time: 0.0147
INFO - 2017-03-13 01:37:12 --> Config Class Initialized
INFO - 2017-03-13 01:37:12 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:37:12 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:37:12 --> Utf8 Class Initialized
INFO - 2017-03-13 01:37:12 --> URI Class Initialized
INFO - 2017-03-13 01:37:12 --> Router Class Initialized
INFO - 2017-03-13 01:37:12 --> Output Class Initialized
INFO - 2017-03-13 01:37:12 --> Security Class Initialized
DEBUG - 2017-03-13 01:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:37:12 --> Input Class Initialized
INFO - 2017-03-13 01:37:12 --> Language Class Initialized
INFO - 2017-03-13 01:37:12 --> Loader Class Initialized
INFO - 2017-03-13 01:37:12 --> Database Driver Class Initialized
INFO - 2017-03-13 01:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:37:12 --> Controller Class Initialized
INFO - 2017-03-13 01:37:12 --> Helper loaded: date_helper
DEBUG - 2017-03-13 01:37:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:37:12 --> Helper loaded: url_helper
INFO - 2017-03-13 01:37:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 01:37:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 01:37:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 01:37:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 01:37:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 01:37:12 --> Final output sent to browser
DEBUG - 2017-03-13 01:37:12 --> Total execution time: 0.0141
INFO - 2017-03-13 01:37:12 --> Config Class Initialized
INFO - 2017-03-13 01:37:12 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:37:12 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:37:12 --> Utf8 Class Initialized
INFO - 2017-03-13 01:37:12 --> URI Class Initialized
INFO - 2017-03-13 01:37:12 --> Router Class Initialized
INFO - 2017-03-13 01:37:12 --> Output Class Initialized
INFO - 2017-03-13 01:37:12 --> Security Class Initialized
DEBUG - 2017-03-13 01:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:37:12 --> Input Class Initialized
INFO - 2017-03-13 01:37:12 --> Language Class Initialized
INFO - 2017-03-13 01:37:12 --> Loader Class Initialized
INFO - 2017-03-13 01:37:12 --> Database Driver Class Initialized
INFO - 2017-03-13 01:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:37:12 --> Controller Class Initialized
INFO - 2017-03-13 01:37:12 --> Helper loaded: url_helper
DEBUG - 2017-03-13 01:37:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:37:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 01:37:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 01:37:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 01:37:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 01:37:12 --> Final output sent to browser
DEBUG - 2017-03-13 01:37:12 --> Total execution time: 0.0137
INFO - 2017-03-13 01:37:13 --> Config Class Initialized
INFO - 2017-03-13 01:37:13 --> Hooks Class Initialized
DEBUG - 2017-03-13 01:37:13 --> UTF-8 Support Enabled
INFO - 2017-03-13 01:37:13 --> Utf8 Class Initialized
INFO - 2017-03-13 01:37:13 --> URI Class Initialized
DEBUG - 2017-03-13 01:37:13 --> No URI present. Default controller set.
INFO - 2017-03-13 01:37:13 --> Router Class Initialized
INFO - 2017-03-13 01:37:13 --> Output Class Initialized
INFO - 2017-03-13 01:37:13 --> Security Class Initialized
DEBUG - 2017-03-13 01:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 01:37:13 --> Input Class Initialized
INFO - 2017-03-13 01:37:13 --> Language Class Initialized
INFO - 2017-03-13 01:37:13 --> Loader Class Initialized
INFO - 2017-03-13 01:37:13 --> Database Driver Class Initialized
INFO - 2017-03-13 01:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 01:37:13 --> Controller Class Initialized
INFO - 2017-03-13 01:37:13 --> Helper loaded: url_helper
DEBUG - 2017-03-13 01:37:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 01:37:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 01:37:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 01:37:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 01:37:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 01:37:13 --> Final output sent to browser
DEBUG - 2017-03-13 01:37:13 --> Total execution time: 0.0142
INFO - 2017-03-13 02:29:36 --> Config Class Initialized
INFO - 2017-03-13 02:29:36 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:29:36 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:29:36 --> Utf8 Class Initialized
INFO - 2017-03-13 02:29:36 --> URI Class Initialized
DEBUG - 2017-03-13 02:29:36 --> No URI present. Default controller set.
INFO - 2017-03-13 02:29:36 --> Router Class Initialized
INFO - 2017-03-13 02:29:36 --> Output Class Initialized
INFO - 2017-03-13 02:29:36 --> Security Class Initialized
DEBUG - 2017-03-13 02:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:29:36 --> Input Class Initialized
INFO - 2017-03-13 02:29:36 --> Language Class Initialized
INFO - 2017-03-13 02:29:36 --> Loader Class Initialized
INFO - 2017-03-13 02:29:37 --> Database Driver Class Initialized
INFO - 2017-03-13 02:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:29:37 --> Controller Class Initialized
INFO - 2017-03-13 02:29:37 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:29:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:29:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:29:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:29:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:29:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:29:37 --> Final output sent to browser
DEBUG - 2017-03-13 02:29:37 --> Total execution time: 1.5211
INFO - 2017-03-13 02:29:44 --> Config Class Initialized
INFO - 2017-03-13 02:29:44 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:29:44 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:29:44 --> Utf8 Class Initialized
INFO - 2017-03-13 02:29:44 --> URI Class Initialized
INFO - 2017-03-13 02:29:44 --> Router Class Initialized
INFO - 2017-03-13 02:29:44 --> Output Class Initialized
INFO - 2017-03-13 02:29:44 --> Security Class Initialized
DEBUG - 2017-03-13 02:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:29:45 --> Input Class Initialized
INFO - 2017-03-13 02:29:45 --> Language Class Initialized
INFO - 2017-03-13 02:29:45 --> Loader Class Initialized
INFO - 2017-03-13 02:29:45 --> Database Driver Class Initialized
INFO - 2017-03-13 02:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:29:45 --> Controller Class Initialized
INFO - 2017-03-13 02:29:45 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:29:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:29:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:29:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:29:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:29:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:29:45 --> Final output sent to browser
DEBUG - 2017-03-13 02:29:45 --> Total execution time: 1.2310
INFO - 2017-03-13 02:30:59 --> Config Class Initialized
INFO - 2017-03-13 02:30:59 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:30:59 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:30:59 --> Utf8 Class Initialized
INFO - 2017-03-13 02:30:59 --> URI Class Initialized
INFO - 2017-03-13 02:30:59 --> Router Class Initialized
INFO - 2017-03-13 02:31:00 --> Output Class Initialized
INFO - 2017-03-13 02:31:00 --> Security Class Initialized
DEBUG - 2017-03-13 02:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:31:00 --> Input Class Initialized
INFO - 2017-03-13 02:31:00 --> Language Class Initialized
INFO - 2017-03-13 02:31:00 --> Loader Class Initialized
INFO - 2017-03-13 02:31:00 --> Database Driver Class Initialized
INFO - 2017-03-13 02:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:31:00 --> Controller Class Initialized
INFO - 2017-03-13 02:31:00 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:31:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:31:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-13 02:31:01 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-13 02:31:01 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-13 02:31:01 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-13 02:31:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:31:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:31:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:31:01 --> Final output sent to browser
DEBUG - 2017-03-13 02:31:01 --> Total execution time: 1.5414
INFO - 2017-03-13 02:31:05 --> Config Class Initialized
INFO - 2017-03-13 02:31:05 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:31:05 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:31:05 --> Utf8 Class Initialized
INFO - 2017-03-13 02:31:05 --> URI Class Initialized
INFO - 2017-03-13 02:31:05 --> Router Class Initialized
INFO - 2017-03-13 02:31:05 --> Output Class Initialized
INFO - 2017-03-13 02:31:05 --> Security Class Initialized
DEBUG - 2017-03-13 02:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:31:05 --> Input Class Initialized
INFO - 2017-03-13 02:31:05 --> Language Class Initialized
INFO - 2017-03-13 02:31:05 --> Loader Class Initialized
INFO - 2017-03-13 02:31:05 --> Database Driver Class Initialized
INFO - 2017-03-13 02:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:31:06 --> Controller Class Initialized
INFO - 2017-03-13 02:31:06 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:31:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:31:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:31:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:31:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:31:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:31:06 --> Final output sent to browser
DEBUG - 2017-03-13 02:31:06 --> Total execution time: 1.2491
INFO - 2017-03-13 02:31:23 --> Config Class Initialized
INFO - 2017-03-13 02:31:23 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:31:23 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:31:23 --> Utf8 Class Initialized
INFO - 2017-03-13 02:31:23 --> URI Class Initialized
INFO - 2017-03-13 02:31:23 --> Router Class Initialized
INFO - 2017-03-13 02:31:23 --> Output Class Initialized
INFO - 2017-03-13 02:31:23 --> Security Class Initialized
DEBUG - 2017-03-13 02:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:31:23 --> Input Class Initialized
INFO - 2017-03-13 02:31:23 --> Language Class Initialized
INFO - 2017-03-13 02:31:23 --> Loader Class Initialized
INFO - 2017-03-13 02:31:23 --> Database Driver Class Initialized
INFO - 2017-03-13 02:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:31:23 --> Controller Class Initialized
INFO - 2017-03-13 02:31:23 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:31:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:31:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-13 02:31:24 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-13 02:31:24 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-13 02:31:24 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-13 02:31:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:31:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:31:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:31:24 --> Final output sent to browser
DEBUG - 2017-03-13 02:31:24 --> Total execution time: 1.2624
INFO - 2017-03-13 02:31:28 --> Config Class Initialized
INFO - 2017-03-13 02:31:28 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:31:28 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:31:28 --> Utf8 Class Initialized
INFO - 2017-03-13 02:31:28 --> URI Class Initialized
INFO - 2017-03-13 02:31:28 --> Router Class Initialized
INFO - 2017-03-13 02:31:28 --> Output Class Initialized
INFO - 2017-03-13 02:31:28 --> Security Class Initialized
DEBUG - 2017-03-13 02:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:31:28 --> Input Class Initialized
INFO - 2017-03-13 02:31:28 --> Language Class Initialized
INFO - 2017-03-13 02:31:28 --> Loader Class Initialized
INFO - 2017-03-13 02:31:29 --> Database Driver Class Initialized
INFO - 2017-03-13 02:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:31:29 --> Controller Class Initialized
INFO - 2017-03-13 02:31:29 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:31:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:31:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:31:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:31:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:31:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:31:29 --> Final output sent to browser
DEBUG - 2017-03-13 02:31:29 --> Total execution time: 1.3000
INFO - 2017-03-13 02:31:48 --> Config Class Initialized
INFO - 2017-03-13 02:31:48 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:31:48 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:31:48 --> Utf8 Class Initialized
INFO - 2017-03-13 02:31:48 --> URI Class Initialized
DEBUG - 2017-03-13 02:31:48 --> No URI present. Default controller set.
INFO - 2017-03-13 02:31:48 --> Router Class Initialized
INFO - 2017-03-13 02:31:48 --> Output Class Initialized
INFO - 2017-03-13 02:31:48 --> Security Class Initialized
DEBUG - 2017-03-13 02:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:31:48 --> Input Class Initialized
INFO - 2017-03-13 02:31:48 --> Language Class Initialized
INFO - 2017-03-13 02:31:48 --> Loader Class Initialized
INFO - 2017-03-13 02:31:49 --> Database Driver Class Initialized
INFO - 2017-03-13 02:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:31:49 --> Controller Class Initialized
INFO - 2017-03-13 02:31:49 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:31:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:31:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:31:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:31:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:31:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:31:49 --> Final output sent to browser
DEBUG - 2017-03-13 02:31:49 --> Total execution time: 1.3039
INFO - 2017-03-13 02:31:53 --> Config Class Initialized
INFO - 2017-03-13 02:31:53 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:31:53 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:31:53 --> Utf8 Class Initialized
INFO - 2017-03-13 02:31:53 --> URI Class Initialized
INFO - 2017-03-13 02:31:53 --> Router Class Initialized
INFO - 2017-03-13 02:31:53 --> Output Class Initialized
INFO - 2017-03-13 02:31:53 --> Security Class Initialized
DEBUG - 2017-03-13 02:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:31:53 --> Input Class Initialized
INFO - 2017-03-13 02:31:53 --> Language Class Initialized
INFO - 2017-03-13 02:31:53 --> Loader Class Initialized
INFO - 2017-03-13 02:31:53 --> Database Driver Class Initialized
INFO - 2017-03-13 02:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:31:53 --> Controller Class Initialized
INFO - 2017-03-13 02:31:53 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:31:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:31:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:31:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:31:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:31:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:31:54 --> Final output sent to browser
DEBUG - 2017-03-13 02:31:54 --> Total execution time: 1.3384
INFO - 2017-03-13 02:31:58 --> Config Class Initialized
INFO - 2017-03-13 02:31:58 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:31:58 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:31:58 --> Utf8 Class Initialized
INFO - 2017-03-13 02:31:58 --> URI Class Initialized
INFO - 2017-03-13 02:31:58 --> Router Class Initialized
INFO - 2017-03-13 02:31:58 --> Output Class Initialized
INFO - 2017-03-13 02:31:58 --> Security Class Initialized
DEBUG - 2017-03-13 02:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:31:59 --> Input Class Initialized
INFO - 2017-03-13 02:31:59 --> Language Class Initialized
INFO - 2017-03-13 02:31:59 --> Loader Class Initialized
INFO - 2017-03-13 02:31:59 --> Database Driver Class Initialized
INFO - 2017-03-13 02:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:31:59 --> Controller Class Initialized
INFO - 2017-03-13 02:31:59 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:31:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:31:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-13 02:31:59 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-13 02:31:59 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-13 02:31:59 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-13 02:31:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:31:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:31:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:31:59 --> Final output sent to browser
DEBUG - 2017-03-13 02:31:59 --> Total execution time: 1.9283
INFO - 2017-03-13 02:32:03 --> Config Class Initialized
INFO - 2017-03-13 02:32:03 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:32:03 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:32:03 --> Utf8 Class Initialized
INFO - 2017-03-13 02:32:03 --> URI Class Initialized
INFO - 2017-03-13 02:32:03 --> Router Class Initialized
INFO - 2017-03-13 02:32:03 --> Output Class Initialized
INFO - 2017-03-13 02:32:03 --> Security Class Initialized
DEBUG - 2017-03-13 02:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:32:03 --> Input Class Initialized
INFO - 2017-03-13 02:32:03 --> Language Class Initialized
INFO - 2017-03-13 02:32:03 --> Loader Class Initialized
INFO - 2017-03-13 02:32:03 --> Database Driver Class Initialized
INFO - 2017-03-13 02:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:32:03 --> Controller Class Initialized
INFO - 2017-03-13 02:32:03 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:32:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:32:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:32:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:32:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:32:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:32:03 --> Final output sent to browser
DEBUG - 2017-03-13 02:32:03 --> Total execution time: 0.0592
INFO - 2017-03-13 02:32:18 --> Config Class Initialized
INFO - 2017-03-13 02:32:18 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:32:18 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:32:18 --> Utf8 Class Initialized
INFO - 2017-03-13 02:32:18 --> URI Class Initialized
INFO - 2017-03-13 02:32:18 --> Router Class Initialized
INFO - 2017-03-13 02:32:19 --> Output Class Initialized
INFO - 2017-03-13 02:32:19 --> Security Class Initialized
DEBUG - 2017-03-13 02:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:32:19 --> Input Class Initialized
INFO - 2017-03-13 02:32:19 --> Language Class Initialized
INFO - 2017-03-13 02:32:19 --> Loader Class Initialized
INFO - 2017-03-13 02:32:19 --> Database Driver Class Initialized
INFO - 2017-03-13 02:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:32:19 --> Controller Class Initialized
INFO - 2017-03-13 02:32:19 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:32:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-13 02:32:21 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-13 02:32:21 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Alejandra Guerra')
INFO - 2017-03-13 02:32:21 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-13 02:32:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-13 02:32:23 --> Config Class Initialized
INFO - 2017-03-13 02:32:23 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:32:23 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:32:23 --> Utf8 Class Initialized
INFO - 2017-03-13 02:32:23 --> URI Class Initialized
INFO - 2017-03-13 02:32:23 --> Router Class Initialized
INFO - 2017-03-13 02:32:23 --> Output Class Initialized
INFO - 2017-03-13 02:32:23 --> Security Class Initialized
DEBUG - 2017-03-13 02:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:32:23 --> Input Class Initialized
INFO - 2017-03-13 02:32:23 --> Language Class Initialized
INFO - 2017-03-13 02:32:23 --> Loader Class Initialized
INFO - 2017-03-13 02:32:23 --> Database Driver Class Initialized
INFO - 2017-03-13 02:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:32:23 --> Controller Class Initialized
INFO - 2017-03-13 02:32:23 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:32:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:32:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:32:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:32:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:32:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:32:23 --> Final output sent to browser
DEBUG - 2017-03-13 02:32:23 --> Total execution time: 0.3959
INFO - 2017-03-13 02:32:30 --> Config Class Initialized
INFO - 2017-03-13 02:32:30 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:32:30 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:32:30 --> Utf8 Class Initialized
INFO - 2017-03-13 02:32:30 --> URI Class Initialized
INFO - 2017-03-13 02:32:30 --> Router Class Initialized
INFO - 2017-03-13 02:32:30 --> Output Class Initialized
INFO - 2017-03-13 02:32:30 --> Security Class Initialized
DEBUG - 2017-03-13 02:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:32:30 --> Input Class Initialized
INFO - 2017-03-13 02:32:30 --> Language Class Initialized
INFO - 2017-03-13 02:32:30 --> Loader Class Initialized
INFO - 2017-03-13 02:32:30 --> Database Driver Class Initialized
INFO - 2017-03-13 02:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:32:30 --> Controller Class Initialized
INFO - 2017-03-13 02:32:30 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:32:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-13 02:32:30 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-13 02:32:30 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Alejandra Guerra')
INFO - 2017-03-13 02:32:30 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-13 02:32:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-13 02:32:31 --> Config Class Initialized
INFO - 2017-03-13 02:32:31 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:32:31 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:32:31 --> Utf8 Class Initialized
INFO - 2017-03-13 02:32:31 --> URI Class Initialized
INFO - 2017-03-13 02:32:31 --> Router Class Initialized
INFO - 2017-03-13 02:32:31 --> Output Class Initialized
INFO - 2017-03-13 02:32:31 --> Security Class Initialized
DEBUG - 2017-03-13 02:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:32:31 --> Input Class Initialized
INFO - 2017-03-13 02:32:31 --> Language Class Initialized
INFO - 2017-03-13 02:32:31 --> Loader Class Initialized
INFO - 2017-03-13 02:32:31 --> Database Driver Class Initialized
INFO - 2017-03-13 02:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:32:31 --> Controller Class Initialized
INFO - 2017-03-13 02:32:31 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:32:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:32:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:32:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:32:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:32:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:32:31 --> Final output sent to browser
DEBUG - 2017-03-13 02:32:31 --> Total execution time: 0.0133
INFO - 2017-03-13 02:32:34 --> Config Class Initialized
INFO - 2017-03-13 02:32:34 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:32:34 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:32:34 --> Utf8 Class Initialized
INFO - 2017-03-13 02:32:34 --> URI Class Initialized
DEBUG - 2017-03-13 02:32:34 --> No URI present. Default controller set.
INFO - 2017-03-13 02:32:34 --> Router Class Initialized
INFO - 2017-03-13 02:32:34 --> Output Class Initialized
INFO - 2017-03-13 02:32:34 --> Security Class Initialized
DEBUG - 2017-03-13 02:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:32:34 --> Input Class Initialized
INFO - 2017-03-13 02:32:34 --> Language Class Initialized
INFO - 2017-03-13 02:32:34 --> Loader Class Initialized
INFO - 2017-03-13 02:32:34 --> Database Driver Class Initialized
INFO - 2017-03-13 02:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:32:34 --> Controller Class Initialized
INFO - 2017-03-13 02:32:34 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:32:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:32:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:32:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:32:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:32:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:32:34 --> Final output sent to browser
DEBUG - 2017-03-13 02:32:34 --> Total execution time: 0.0361
INFO - 2017-03-13 02:34:48 --> Config Class Initialized
INFO - 2017-03-13 02:34:48 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:34:48 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:34:48 --> Utf8 Class Initialized
INFO - 2017-03-13 02:34:48 --> URI Class Initialized
DEBUG - 2017-03-13 02:34:48 --> No URI present. Default controller set.
INFO - 2017-03-13 02:34:48 --> Router Class Initialized
INFO - 2017-03-13 02:34:48 --> Output Class Initialized
INFO - 2017-03-13 02:34:48 --> Security Class Initialized
DEBUG - 2017-03-13 02:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:34:48 --> Input Class Initialized
INFO - 2017-03-13 02:34:48 --> Language Class Initialized
INFO - 2017-03-13 02:34:48 --> Loader Class Initialized
INFO - 2017-03-13 02:34:48 --> Database Driver Class Initialized
INFO - 2017-03-13 02:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:34:49 --> Controller Class Initialized
INFO - 2017-03-13 02:34:49 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:34:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:34:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:34:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:34:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:34:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:34:49 --> Final output sent to browser
DEBUG - 2017-03-13 02:34:49 --> Total execution time: 1.7594
INFO - 2017-03-13 02:35:03 --> Config Class Initialized
INFO - 2017-03-13 02:35:03 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:35:03 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:35:03 --> Utf8 Class Initialized
INFO - 2017-03-13 02:35:03 --> URI Class Initialized
INFO - 2017-03-13 02:35:03 --> Router Class Initialized
INFO - 2017-03-13 02:35:03 --> Output Class Initialized
INFO - 2017-03-13 02:35:03 --> Security Class Initialized
DEBUG - 2017-03-13 02:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:35:03 --> Input Class Initialized
INFO - 2017-03-13 02:35:03 --> Language Class Initialized
INFO - 2017-03-13 02:35:03 --> Loader Class Initialized
INFO - 2017-03-13 02:35:03 --> Database Driver Class Initialized
INFO - 2017-03-13 02:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:35:03 --> Controller Class Initialized
INFO - 2017-03-13 02:35:03 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:35:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:35:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:35:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:35:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:35:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:35:03 --> Final output sent to browser
DEBUG - 2017-03-13 02:35:03 --> Total execution time: 0.0134
INFO - 2017-03-13 02:35:22 --> Config Class Initialized
INFO - 2017-03-13 02:35:22 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:35:22 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:35:22 --> Utf8 Class Initialized
INFO - 2017-03-13 02:35:22 --> URI Class Initialized
INFO - 2017-03-13 02:35:22 --> Router Class Initialized
INFO - 2017-03-13 02:35:22 --> Output Class Initialized
INFO - 2017-03-13 02:35:22 --> Security Class Initialized
DEBUG - 2017-03-13 02:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:35:22 --> Input Class Initialized
INFO - 2017-03-13 02:35:22 --> Language Class Initialized
INFO - 2017-03-13 02:35:22 --> Loader Class Initialized
INFO - 2017-03-13 02:35:23 --> Database Driver Class Initialized
INFO - 2017-03-13 02:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:35:23 --> Controller Class Initialized
INFO - 2017-03-13 02:35:23 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:35:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-13 02:35:24 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-13 02:35:24 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Alejandra Guerra')
INFO - 2017-03-13 02:35:24 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-13 02:35:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-13 02:35:28 --> Config Class Initialized
INFO - 2017-03-13 02:35:28 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:35:28 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:35:28 --> Utf8 Class Initialized
INFO - 2017-03-13 02:35:28 --> URI Class Initialized
INFO - 2017-03-13 02:35:28 --> Router Class Initialized
INFO - 2017-03-13 02:35:28 --> Output Class Initialized
INFO - 2017-03-13 02:35:28 --> Security Class Initialized
DEBUG - 2017-03-13 02:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:35:28 --> Input Class Initialized
INFO - 2017-03-13 02:35:28 --> Language Class Initialized
INFO - 2017-03-13 02:35:28 --> Loader Class Initialized
INFO - 2017-03-13 02:35:29 --> Database Driver Class Initialized
INFO - 2017-03-13 02:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:35:29 --> Controller Class Initialized
INFO - 2017-03-13 02:35:29 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:35:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:35:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:35:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:35:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:35:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:35:30 --> Final output sent to browser
DEBUG - 2017-03-13 02:35:30 --> Total execution time: 1.9672
INFO - 2017-03-13 02:35:38 --> Config Class Initialized
INFO - 2017-03-13 02:35:38 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:35:38 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:35:38 --> Utf8 Class Initialized
INFO - 2017-03-13 02:35:38 --> URI Class Initialized
DEBUG - 2017-03-13 02:35:38 --> No URI present. Default controller set.
INFO - 2017-03-13 02:35:38 --> Router Class Initialized
INFO - 2017-03-13 02:35:39 --> Output Class Initialized
INFO - 2017-03-13 02:35:39 --> Security Class Initialized
DEBUG - 2017-03-13 02:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:35:39 --> Input Class Initialized
INFO - 2017-03-13 02:35:39 --> Language Class Initialized
INFO - 2017-03-13 02:35:39 --> Loader Class Initialized
INFO - 2017-03-13 02:35:39 --> Database Driver Class Initialized
INFO - 2017-03-13 02:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:35:39 --> Controller Class Initialized
INFO - 2017-03-13 02:35:39 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:35:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:35:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:35:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:35:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:35:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:35:39 --> Final output sent to browser
DEBUG - 2017-03-13 02:35:39 --> Total execution time: 0.0266
INFO - 2017-03-13 02:36:58 --> Config Class Initialized
INFO - 2017-03-13 02:36:58 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:36:58 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:36:58 --> Utf8 Class Initialized
INFO - 2017-03-13 02:36:58 --> URI Class Initialized
DEBUG - 2017-03-13 02:36:58 --> No URI present. Default controller set.
INFO - 2017-03-13 02:36:58 --> Router Class Initialized
INFO - 2017-03-13 02:36:58 --> Output Class Initialized
INFO - 2017-03-13 02:36:58 --> Security Class Initialized
DEBUG - 2017-03-13 02:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:36:58 --> Input Class Initialized
INFO - 2017-03-13 02:36:58 --> Language Class Initialized
INFO - 2017-03-13 02:36:58 --> Loader Class Initialized
INFO - 2017-03-13 02:36:59 --> Database Driver Class Initialized
INFO - 2017-03-13 02:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:36:59 --> Controller Class Initialized
INFO - 2017-03-13 02:36:59 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:36:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:37:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:37:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:37:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:37:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:37:00 --> Final output sent to browser
DEBUG - 2017-03-13 02:37:00 --> Total execution time: 2.2042
INFO - 2017-03-13 02:37:05 --> Config Class Initialized
INFO - 2017-03-13 02:37:05 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:37:05 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:37:05 --> Utf8 Class Initialized
INFO - 2017-03-13 02:37:05 --> URI Class Initialized
INFO - 2017-03-13 02:37:05 --> Router Class Initialized
INFO - 2017-03-13 02:37:05 --> Output Class Initialized
INFO - 2017-03-13 02:37:05 --> Security Class Initialized
DEBUG - 2017-03-13 02:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:37:05 --> Input Class Initialized
INFO - 2017-03-13 02:37:05 --> Language Class Initialized
INFO - 2017-03-13 02:37:05 --> Loader Class Initialized
INFO - 2017-03-13 02:37:06 --> Database Driver Class Initialized
INFO - 2017-03-13 02:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:37:06 --> Controller Class Initialized
INFO - 2017-03-13 02:37:06 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:37:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:37:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:37:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:37:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:37:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:37:06 --> Final output sent to browser
DEBUG - 2017-03-13 02:37:06 --> Total execution time: 1.5378
INFO - 2017-03-13 02:37:16 --> Config Class Initialized
INFO - 2017-03-13 02:37:16 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:37:16 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:37:16 --> Utf8 Class Initialized
INFO - 2017-03-13 02:37:16 --> URI Class Initialized
INFO - 2017-03-13 02:37:16 --> Router Class Initialized
INFO - 2017-03-13 02:37:16 --> Output Class Initialized
INFO - 2017-03-13 02:37:16 --> Security Class Initialized
DEBUG - 2017-03-13 02:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:37:16 --> Input Class Initialized
INFO - 2017-03-13 02:37:16 --> Language Class Initialized
INFO - 2017-03-13 02:37:16 --> Loader Class Initialized
INFO - 2017-03-13 02:37:16 --> Database Driver Class Initialized
INFO - 2017-03-13 02:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:37:17 --> Controller Class Initialized
INFO - 2017-03-13 02:37:17 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:37:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-13 02:37:19 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-13 02:37:19 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Pa Padilla')
INFO - 2017-03-13 02:37:19 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-13 02:37:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-13 02:37:20 --> Config Class Initialized
INFO - 2017-03-13 02:37:20 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:37:20 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:37:20 --> Utf8 Class Initialized
INFO - 2017-03-13 02:37:20 --> URI Class Initialized
INFO - 2017-03-13 02:37:20 --> Router Class Initialized
INFO - 2017-03-13 02:37:20 --> Output Class Initialized
INFO - 2017-03-13 02:37:20 --> Security Class Initialized
DEBUG - 2017-03-13 02:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:37:20 --> Input Class Initialized
INFO - 2017-03-13 02:37:20 --> Language Class Initialized
INFO - 2017-03-13 02:37:20 --> Loader Class Initialized
INFO - 2017-03-13 02:37:20 --> Database Driver Class Initialized
INFO - 2017-03-13 02:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:37:20 --> Controller Class Initialized
INFO - 2017-03-13 02:37:20 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:37:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:37:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:37:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:37:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:37:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:37:21 --> Final output sent to browser
DEBUG - 2017-03-13 02:37:21 --> Total execution time: 1.3675
INFO - 2017-03-13 02:37:25 --> Config Class Initialized
INFO - 2017-03-13 02:37:25 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:37:25 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:37:25 --> Utf8 Class Initialized
INFO - 2017-03-13 02:37:25 --> URI Class Initialized
DEBUG - 2017-03-13 02:37:26 --> No URI present. Default controller set.
INFO - 2017-03-13 02:37:26 --> Router Class Initialized
INFO - 2017-03-13 02:37:26 --> Output Class Initialized
INFO - 2017-03-13 02:37:26 --> Security Class Initialized
DEBUG - 2017-03-13 02:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:37:26 --> Input Class Initialized
INFO - 2017-03-13 02:37:26 --> Language Class Initialized
INFO - 2017-03-13 02:37:26 --> Loader Class Initialized
INFO - 2017-03-13 02:37:26 --> Database Driver Class Initialized
INFO - 2017-03-13 02:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:37:26 --> Controller Class Initialized
INFO - 2017-03-13 02:37:26 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:37:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:37:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:37:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:37:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:37:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:37:27 --> Final output sent to browser
DEBUG - 2017-03-13 02:37:27 --> Total execution time: 1.2348
INFO - 2017-03-13 02:37:28 --> Config Class Initialized
INFO - 2017-03-13 02:37:28 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:37:28 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:37:28 --> Utf8 Class Initialized
INFO - 2017-03-13 02:37:28 --> URI Class Initialized
INFO - 2017-03-13 02:37:28 --> Router Class Initialized
INFO - 2017-03-13 02:37:28 --> Output Class Initialized
INFO - 2017-03-13 02:37:28 --> Security Class Initialized
DEBUG - 2017-03-13 02:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:37:28 --> Input Class Initialized
INFO - 2017-03-13 02:37:28 --> Language Class Initialized
INFO - 2017-03-13 02:37:28 --> Loader Class Initialized
INFO - 2017-03-13 02:37:28 --> Database Driver Class Initialized
INFO - 2017-03-13 02:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:37:28 --> Controller Class Initialized
INFO - 2017-03-13 02:37:28 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:37:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:37:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:37:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:37:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:37:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:37:28 --> Final output sent to browser
DEBUG - 2017-03-13 02:37:28 --> Total execution time: 0.0134
INFO - 2017-03-13 02:37:47 --> Config Class Initialized
INFO - 2017-03-13 02:37:47 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:37:47 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:37:47 --> Utf8 Class Initialized
INFO - 2017-03-13 02:37:47 --> URI Class Initialized
DEBUG - 2017-03-13 02:37:47 --> No URI present. Default controller set.
INFO - 2017-03-13 02:37:47 --> Router Class Initialized
INFO - 2017-03-13 02:37:47 --> Output Class Initialized
INFO - 2017-03-13 02:37:47 --> Security Class Initialized
DEBUG - 2017-03-13 02:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:37:47 --> Input Class Initialized
INFO - 2017-03-13 02:37:47 --> Language Class Initialized
INFO - 2017-03-13 02:37:47 --> Loader Class Initialized
INFO - 2017-03-13 02:37:47 --> Database Driver Class Initialized
INFO - 2017-03-13 02:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:37:47 --> Controller Class Initialized
INFO - 2017-03-13 02:37:47 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:37:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:37:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:37:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:37:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:37:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:37:47 --> Final output sent to browser
DEBUG - 2017-03-13 02:37:47 --> Total execution time: 0.2795
INFO - 2017-03-13 02:38:03 --> Config Class Initialized
INFO - 2017-03-13 02:38:03 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:38:03 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:38:03 --> Utf8 Class Initialized
INFO - 2017-03-13 02:38:03 --> URI Class Initialized
INFO - 2017-03-13 02:38:03 --> Router Class Initialized
INFO - 2017-03-13 02:38:03 --> Output Class Initialized
INFO - 2017-03-13 02:38:03 --> Security Class Initialized
DEBUG - 2017-03-13 02:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:38:03 --> Input Class Initialized
INFO - 2017-03-13 02:38:03 --> Language Class Initialized
INFO - 2017-03-13 02:38:03 --> Loader Class Initialized
INFO - 2017-03-13 02:38:03 --> Database Driver Class Initialized
INFO - 2017-03-13 02:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:38:03 --> Controller Class Initialized
INFO - 2017-03-13 02:38:03 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:38:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:38:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:38:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:38:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:38:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:38:03 --> Final output sent to browser
DEBUG - 2017-03-13 02:38:03 --> Total execution time: 0.0297
INFO - 2017-03-13 02:38:04 --> Config Class Initialized
INFO - 2017-03-13 02:38:04 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:38:04 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:38:04 --> Utf8 Class Initialized
INFO - 2017-03-13 02:38:04 --> URI Class Initialized
INFO - 2017-03-13 02:38:04 --> Router Class Initialized
INFO - 2017-03-13 02:38:04 --> Output Class Initialized
INFO - 2017-03-13 02:38:04 --> Security Class Initialized
DEBUG - 2017-03-13 02:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:38:04 --> Input Class Initialized
INFO - 2017-03-13 02:38:04 --> Language Class Initialized
INFO - 2017-03-13 02:38:04 --> Loader Class Initialized
INFO - 2017-03-13 02:38:04 --> Database Driver Class Initialized
INFO - 2017-03-13 02:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:38:04 --> Controller Class Initialized
INFO - 2017-03-13 02:38:04 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:38:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:38:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:38:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:38:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:38:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:38:04 --> Final output sent to browser
DEBUG - 2017-03-13 02:38:04 --> Total execution time: 0.0139
INFO - 2017-03-13 02:38:28 --> Config Class Initialized
INFO - 2017-03-13 02:38:28 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:38:28 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:38:28 --> Utf8 Class Initialized
INFO - 2017-03-13 02:38:28 --> URI Class Initialized
INFO - 2017-03-13 02:38:28 --> Router Class Initialized
INFO - 2017-03-13 02:38:28 --> Output Class Initialized
INFO - 2017-03-13 02:38:28 --> Security Class Initialized
DEBUG - 2017-03-13 02:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:38:28 --> Input Class Initialized
INFO - 2017-03-13 02:38:28 --> Language Class Initialized
INFO - 2017-03-13 02:38:28 --> Loader Class Initialized
INFO - 2017-03-13 02:38:28 --> Database Driver Class Initialized
INFO - 2017-03-13 02:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:38:28 --> Controller Class Initialized
INFO - 2017-03-13 02:38:28 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:38:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:38:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:38:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:38:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:38:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:38:28 --> Final output sent to browser
DEBUG - 2017-03-13 02:38:28 --> Total execution time: 0.0147
INFO - 2017-03-13 02:38:29 --> Config Class Initialized
INFO - 2017-03-13 02:38:29 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:38:29 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:38:29 --> Utf8 Class Initialized
INFO - 2017-03-13 02:38:29 --> URI Class Initialized
INFO - 2017-03-13 02:38:29 --> Router Class Initialized
INFO - 2017-03-13 02:38:29 --> Output Class Initialized
INFO - 2017-03-13 02:38:29 --> Security Class Initialized
DEBUG - 2017-03-13 02:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:38:29 --> Input Class Initialized
INFO - 2017-03-13 02:38:29 --> Language Class Initialized
INFO - 2017-03-13 02:38:29 --> Loader Class Initialized
INFO - 2017-03-13 02:38:29 --> Database Driver Class Initialized
INFO - 2017-03-13 02:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:38:29 --> Controller Class Initialized
INFO - 2017-03-13 02:38:29 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:38:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:38:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:38:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:38:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:38:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:38:29 --> Final output sent to browser
DEBUG - 2017-03-13 02:38:29 --> Total execution time: 0.0166
INFO - 2017-03-13 02:38:41 --> Config Class Initialized
INFO - 2017-03-13 02:38:41 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:38:41 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:38:41 --> Utf8 Class Initialized
INFO - 2017-03-13 02:38:41 --> URI Class Initialized
INFO - 2017-03-13 02:38:41 --> Router Class Initialized
INFO - 2017-03-13 02:38:41 --> Output Class Initialized
INFO - 2017-03-13 02:38:41 --> Security Class Initialized
DEBUG - 2017-03-13 02:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:38:41 --> Input Class Initialized
INFO - 2017-03-13 02:38:41 --> Language Class Initialized
INFO - 2017-03-13 02:38:41 --> Loader Class Initialized
INFO - 2017-03-13 02:38:41 --> Database Driver Class Initialized
INFO - 2017-03-13 02:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:38:41 --> Controller Class Initialized
INFO - 2017-03-13 02:38:41 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:38:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:38:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:38:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:38:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:38:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:38:41 --> Final output sent to browser
DEBUG - 2017-03-13 02:38:41 --> Total execution time: 0.0141
INFO - 2017-03-13 02:38:45 --> Config Class Initialized
INFO - 2017-03-13 02:38:45 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:38:45 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:38:45 --> Utf8 Class Initialized
INFO - 2017-03-13 02:38:45 --> URI Class Initialized
DEBUG - 2017-03-13 02:38:45 --> No URI present. Default controller set.
INFO - 2017-03-13 02:38:45 --> Router Class Initialized
INFO - 2017-03-13 02:38:45 --> Output Class Initialized
INFO - 2017-03-13 02:38:45 --> Security Class Initialized
DEBUG - 2017-03-13 02:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:38:45 --> Input Class Initialized
INFO - 2017-03-13 02:38:45 --> Language Class Initialized
INFO - 2017-03-13 02:38:45 --> Loader Class Initialized
INFO - 2017-03-13 02:38:45 --> Database Driver Class Initialized
INFO - 2017-03-13 02:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:38:45 --> Controller Class Initialized
INFO - 2017-03-13 02:38:45 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:38:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:38:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:38:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:38:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:38:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:38:45 --> Final output sent to browser
DEBUG - 2017-03-13 02:38:45 --> Total execution time: 0.2570
INFO - 2017-03-13 02:38:53 --> Config Class Initialized
INFO - 2017-03-13 02:38:53 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:38:53 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:38:53 --> Utf8 Class Initialized
INFO - 2017-03-13 02:38:53 --> URI Class Initialized
INFO - 2017-03-13 02:38:53 --> Router Class Initialized
INFO - 2017-03-13 02:38:53 --> Output Class Initialized
INFO - 2017-03-13 02:38:53 --> Security Class Initialized
DEBUG - 2017-03-13 02:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:38:53 --> Input Class Initialized
INFO - 2017-03-13 02:38:53 --> Language Class Initialized
INFO - 2017-03-13 02:38:53 --> Loader Class Initialized
INFO - 2017-03-13 02:38:53 --> Database Driver Class Initialized
INFO - 2017-03-13 02:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:38:53 --> Controller Class Initialized
INFO - 2017-03-13 02:38:53 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:38:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:38:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:38:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:38:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:38:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:38:53 --> Final output sent to browser
DEBUG - 2017-03-13 02:38:53 --> Total execution time: 0.0144
INFO - 2017-03-13 02:38:54 --> Config Class Initialized
INFO - 2017-03-13 02:38:54 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:38:54 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:38:54 --> Utf8 Class Initialized
INFO - 2017-03-13 02:38:54 --> URI Class Initialized
INFO - 2017-03-13 02:38:54 --> Router Class Initialized
INFO - 2017-03-13 02:38:54 --> Output Class Initialized
INFO - 2017-03-13 02:38:54 --> Security Class Initialized
DEBUG - 2017-03-13 02:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:38:54 --> Input Class Initialized
INFO - 2017-03-13 02:38:54 --> Language Class Initialized
INFO - 2017-03-13 02:38:54 --> Loader Class Initialized
INFO - 2017-03-13 02:38:54 --> Database Driver Class Initialized
INFO - 2017-03-13 02:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:38:54 --> Controller Class Initialized
INFO - 2017-03-13 02:38:54 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:38:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:38:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:38:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:38:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:38:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:38:54 --> Final output sent to browser
DEBUG - 2017-03-13 02:38:54 --> Total execution time: 0.0153
INFO - 2017-03-13 02:38:57 --> Config Class Initialized
INFO - 2017-03-13 02:38:57 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:38:57 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:38:57 --> Utf8 Class Initialized
INFO - 2017-03-13 02:38:57 --> URI Class Initialized
INFO - 2017-03-13 02:38:57 --> Router Class Initialized
INFO - 2017-03-13 02:38:57 --> Output Class Initialized
INFO - 2017-03-13 02:38:57 --> Security Class Initialized
DEBUG - 2017-03-13 02:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:38:57 --> Input Class Initialized
INFO - 2017-03-13 02:38:57 --> Language Class Initialized
INFO - 2017-03-13 02:38:57 --> Loader Class Initialized
INFO - 2017-03-13 02:38:57 --> Database Driver Class Initialized
INFO - 2017-03-13 02:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:38:57 --> Controller Class Initialized
INFO - 2017-03-13 02:38:57 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:38:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-13 02:38:59 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-13 02:38:59 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Pa Padilla')
INFO - 2017-03-13 02:38:59 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-13 02:38:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-13 02:38:59 --> Config Class Initialized
INFO - 2017-03-13 02:38:59 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:38:59 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:38:59 --> Utf8 Class Initialized
INFO - 2017-03-13 02:38:59 --> URI Class Initialized
INFO - 2017-03-13 02:38:59 --> Router Class Initialized
INFO - 2017-03-13 02:38:59 --> Output Class Initialized
INFO - 2017-03-13 02:38:59 --> Security Class Initialized
DEBUG - 2017-03-13 02:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:38:59 --> Input Class Initialized
INFO - 2017-03-13 02:38:59 --> Language Class Initialized
INFO - 2017-03-13 02:38:59 --> Loader Class Initialized
INFO - 2017-03-13 02:38:59 --> Database Driver Class Initialized
INFO - 2017-03-13 02:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:38:59 --> Controller Class Initialized
INFO - 2017-03-13 02:38:59 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:38:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:38:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:38:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:38:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:38:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:38:59 --> Final output sent to browser
DEBUG - 2017-03-13 02:38:59 --> Total execution time: 0.0138
INFO - 2017-03-13 02:39:13 --> Config Class Initialized
INFO - 2017-03-13 02:39:13 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:39:13 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:39:13 --> Utf8 Class Initialized
INFO - 2017-03-13 02:39:13 --> URI Class Initialized
DEBUG - 2017-03-13 02:39:13 --> No URI present. Default controller set.
INFO - 2017-03-13 02:39:13 --> Router Class Initialized
INFO - 2017-03-13 02:39:13 --> Output Class Initialized
INFO - 2017-03-13 02:39:13 --> Security Class Initialized
DEBUG - 2017-03-13 02:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:39:13 --> Input Class Initialized
INFO - 2017-03-13 02:39:13 --> Language Class Initialized
INFO - 2017-03-13 02:39:13 --> Loader Class Initialized
INFO - 2017-03-13 02:39:13 --> Database Driver Class Initialized
INFO - 2017-03-13 02:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:39:13 --> Controller Class Initialized
INFO - 2017-03-13 02:39:13 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:39:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:39:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:39:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:39:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:39:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:39:13 --> Final output sent to browser
DEBUG - 2017-03-13 02:39:13 --> Total execution time: 0.0144
INFO - 2017-03-13 02:41:18 --> Config Class Initialized
INFO - 2017-03-13 02:41:18 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:41:18 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:41:18 --> Utf8 Class Initialized
INFO - 2017-03-13 02:41:18 --> URI Class Initialized
INFO - 2017-03-13 02:41:18 --> Router Class Initialized
INFO - 2017-03-13 02:41:18 --> Output Class Initialized
INFO - 2017-03-13 02:41:18 --> Security Class Initialized
DEBUG - 2017-03-13 02:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:41:18 --> Input Class Initialized
INFO - 2017-03-13 02:41:18 --> Language Class Initialized
INFO - 2017-03-13 02:41:18 --> Loader Class Initialized
INFO - 2017-03-13 02:41:18 --> Database Driver Class Initialized
INFO - 2017-03-13 02:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:41:18 --> Controller Class Initialized
INFO - 2017-03-13 02:41:18 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:41:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:41:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-13 02:41:18 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-13 02:41:18 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-13 02:41:18 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-13 02:41:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:41:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:41:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:41:18 --> Final output sent to browser
DEBUG - 2017-03-13 02:41:18 --> Total execution time: 0.0287
INFO - 2017-03-13 02:41:33 --> Config Class Initialized
INFO - 2017-03-13 02:41:33 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:41:33 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:41:33 --> Utf8 Class Initialized
INFO - 2017-03-13 02:41:33 --> URI Class Initialized
INFO - 2017-03-13 02:41:33 --> Router Class Initialized
INFO - 2017-03-13 02:41:33 --> Output Class Initialized
INFO - 2017-03-13 02:41:33 --> Security Class Initialized
DEBUG - 2017-03-13 02:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:41:33 --> Input Class Initialized
INFO - 2017-03-13 02:41:33 --> Language Class Initialized
INFO - 2017-03-13 02:41:33 --> Loader Class Initialized
INFO - 2017-03-13 02:41:33 --> Database Driver Class Initialized
INFO - 2017-03-13 02:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:41:33 --> Controller Class Initialized
INFO - 2017-03-13 02:41:33 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:41:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:41:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:41:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:41:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:41:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:41:33 --> Final output sent to browser
DEBUG - 2017-03-13 02:41:33 --> Total execution time: 0.0142
INFO - 2017-03-13 02:42:43 --> Config Class Initialized
INFO - 2017-03-13 02:42:43 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:42:43 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:42:43 --> Utf8 Class Initialized
INFO - 2017-03-13 02:42:43 --> URI Class Initialized
INFO - 2017-03-13 02:42:43 --> Router Class Initialized
INFO - 2017-03-13 02:42:43 --> Output Class Initialized
INFO - 2017-03-13 02:42:43 --> Security Class Initialized
DEBUG - 2017-03-13 02:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:42:43 --> Input Class Initialized
INFO - 2017-03-13 02:42:43 --> Language Class Initialized
INFO - 2017-03-13 02:42:43 --> Loader Class Initialized
INFO - 2017-03-13 02:42:44 --> Database Driver Class Initialized
INFO - 2017-03-13 02:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:42:44 --> Controller Class Initialized
INFO - 2017-03-13 02:42:44 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:42:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:42:46 --> Config Class Initialized
INFO - 2017-03-13 02:42:46 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:42:46 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:42:46 --> Utf8 Class Initialized
INFO - 2017-03-13 02:42:46 --> URI Class Initialized
INFO - 2017-03-13 02:42:46 --> Router Class Initialized
INFO - 2017-03-13 02:42:46 --> Output Class Initialized
INFO - 2017-03-13 02:42:46 --> Security Class Initialized
DEBUG - 2017-03-13 02:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:42:46 --> Input Class Initialized
INFO - 2017-03-13 02:42:46 --> Language Class Initialized
INFO - 2017-03-13 02:42:46 --> Loader Class Initialized
INFO - 2017-03-13 02:42:46 --> Database Driver Class Initialized
INFO - 2017-03-13 02:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:42:46 --> Controller Class Initialized
INFO - 2017-03-13 02:42:46 --> Helper loaded: date_helper
DEBUG - 2017-03-13 02:42:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:42:46 --> Helper loaded: url_helper
INFO - 2017-03-13 02:42:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:42:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 02:42:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 02:42:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 02:42:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:42:46 --> Final output sent to browser
DEBUG - 2017-03-13 02:42:46 --> Total execution time: 0.1384
INFO - 2017-03-13 02:42:49 --> Config Class Initialized
INFO - 2017-03-13 02:42:49 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:42:49 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:42:49 --> Utf8 Class Initialized
INFO - 2017-03-13 02:42:49 --> URI Class Initialized
INFO - 2017-03-13 02:42:49 --> Router Class Initialized
INFO - 2017-03-13 02:42:49 --> Output Class Initialized
INFO - 2017-03-13 02:42:49 --> Security Class Initialized
DEBUG - 2017-03-13 02:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:42:49 --> Input Class Initialized
INFO - 2017-03-13 02:42:49 --> Language Class Initialized
INFO - 2017-03-13 02:42:49 --> Loader Class Initialized
INFO - 2017-03-13 02:42:49 --> Database Driver Class Initialized
INFO - 2017-03-13 02:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:42:49 --> Controller Class Initialized
INFO - 2017-03-13 02:42:49 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:42:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:42:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:42:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:42:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:42:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:42:49 --> Final output sent to browser
DEBUG - 2017-03-13 02:42:49 --> Total execution time: 0.0467
INFO - 2017-03-13 02:43:01 --> Config Class Initialized
INFO - 2017-03-13 02:43:01 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:43:01 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:43:01 --> Utf8 Class Initialized
INFO - 2017-03-13 02:43:01 --> URI Class Initialized
INFO - 2017-03-13 02:43:01 --> Router Class Initialized
INFO - 2017-03-13 02:43:01 --> Output Class Initialized
INFO - 2017-03-13 02:43:01 --> Security Class Initialized
DEBUG - 2017-03-13 02:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:43:01 --> Input Class Initialized
INFO - 2017-03-13 02:43:01 --> Language Class Initialized
INFO - 2017-03-13 02:43:01 --> Loader Class Initialized
INFO - 2017-03-13 02:43:01 --> Database Driver Class Initialized
INFO - 2017-03-13 02:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:43:01 --> Controller Class Initialized
INFO - 2017-03-13 02:43:01 --> Helper loaded: date_helper
DEBUG - 2017-03-13 02:43:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:43:01 --> Helper loaded: url_helper
INFO - 2017-03-13 02:43:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:43:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 02:43:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 02:43:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 02:43:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:43:01 --> Final output sent to browser
DEBUG - 2017-03-13 02:43:01 --> Total execution time: 0.0145
INFO - 2017-03-13 02:43:09 --> Config Class Initialized
INFO - 2017-03-13 02:43:09 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:43:09 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:43:09 --> Utf8 Class Initialized
INFO - 2017-03-13 02:43:09 --> URI Class Initialized
INFO - 2017-03-13 02:43:09 --> Router Class Initialized
INFO - 2017-03-13 02:43:09 --> Output Class Initialized
INFO - 2017-03-13 02:43:09 --> Security Class Initialized
DEBUG - 2017-03-13 02:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:43:09 --> Input Class Initialized
INFO - 2017-03-13 02:43:09 --> Language Class Initialized
INFO - 2017-03-13 02:43:09 --> Loader Class Initialized
INFO - 2017-03-13 02:43:09 --> Database Driver Class Initialized
INFO - 2017-03-13 02:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:43:09 --> Controller Class Initialized
INFO - 2017-03-13 02:43:09 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:43:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:43:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:43:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:43:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:43:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:43:09 --> Final output sent to browser
DEBUG - 2017-03-13 02:43:09 --> Total execution time: 0.0139
INFO - 2017-03-13 02:43:15 --> Config Class Initialized
INFO - 2017-03-13 02:43:15 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:43:15 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:43:15 --> Utf8 Class Initialized
INFO - 2017-03-13 02:43:15 --> URI Class Initialized
INFO - 2017-03-13 02:43:15 --> Router Class Initialized
INFO - 2017-03-13 02:43:15 --> Output Class Initialized
INFO - 2017-03-13 02:43:15 --> Security Class Initialized
DEBUG - 2017-03-13 02:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:43:15 --> Input Class Initialized
INFO - 2017-03-13 02:43:15 --> Language Class Initialized
INFO - 2017-03-13 02:43:15 --> Loader Class Initialized
INFO - 2017-03-13 02:43:15 --> Database Driver Class Initialized
INFO - 2017-03-13 02:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:43:15 --> Controller Class Initialized
INFO - 2017-03-13 02:43:15 --> Helper loaded: date_helper
DEBUG - 2017-03-13 02:43:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:43:15 --> Helper loaded: url_helper
INFO - 2017-03-13 02:43:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:43:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 02:43:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 02:43:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 02:43:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:43:15 --> Final output sent to browser
DEBUG - 2017-03-13 02:43:15 --> Total execution time: 0.0153
INFO - 2017-03-13 02:43:18 --> Config Class Initialized
INFO - 2017-03-13 02:43:18 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:43:18 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:43:18 --> Utf8 Class Initialized
INFO - 2017-03-13 02:43:18 --> URI Class Initialized
INFO - 2017-03-13 02:43:18 --> Router Class Initialized
INFO - 2017-03-13 02:43:18 --> Output Class Initialized
INFO - 2017-03-13 02:43:18 --> Security Class Initialized
DEBUG - 2017-03-13 02:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:43:18 --> Input Class Initialized
INFO - 2017-03-13 02:43:18 --> Language Class Initialized
INFO - 2017-03-13 02:43:18 --> Loader Class Initialized
INFO - 2017-03-13 02:43:18 --> Database Driver Class Initialized
INFO - 2017-03-13 02:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:43:18 --> Controller Class Initialized
INFO - 2017-03-13 02:43:18 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:43:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:43:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:43:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:43:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:43:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:43:18 --> Final output sent to browser
DEBUG - 2017-03-13 02:43:18 --> Total execution time: 0.0195
INFO - 2017-03-13 02:43:30 --> Config Class Initialized
INFO - 2017-03-13 02:43:30 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:43:30 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:43:30 --> Utf8 Class Initialized
INFO - 2017-03-13 02:43:30 --> URI Class Initialized
INFO - 2017-03-13 02:43:30 --> Router Class Initialized
INFO - 2017-03-13 02:43:30 --> Output Class Initialized
INFO - 2017-03-13 02:43:30 --> Security Class Initialized
DEBUG - 2017-03-13 02:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:43:30 --> Input Class Initialized
INFO - 2017-03-13 02:43:30 --> Language Class Initialized
INFO - 2017-03-13 02:43:30 --> Loader Class Initialized
INFO - 2017-03-13 02:43:31 --> Database Driver Class Initialized
INFO - 2017-03-13 02:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:43:31 --> Controller Class Initialized
INFO - 2017-03-13 02:43:31 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:43:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:43:34 --> Config Class Initialized
INFO - 2017-03-13 02:43:34 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:43:34 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:43:34 --> Utf8 Class Initialized
INFO - 2017-03-13 02:43:34 --> URI Class Initialized
INFO - 2017-03-13 02:43:34 --> Router Class Initialized
INFO - 2017-03-13 02:43:34 --> Output Class Initialized
INFO - 2017-03-13 02:43:34 --> Security Class Initialized
DEBUG - 2017-03-13 02:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:43:34 --> Input Class Initialized
INFO - 2017-03-13 02:43:34 --> Language Class Initialized
INFO - 2017-03-13 02:43:34 --> Loader Class Initialized
INFO - 2017-03-13 02:43:34 --> Database Driver Class Initialized
INFO - 2017-03-13 02:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:43:35 --> Controller Class Initialized
INFO - 2017-03-13 02:43:35 --> Helper loaded: date_helper
DEBUG - 2017-03-13 02:43:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:43:35 --> Helper loaded: url_helper
INFO - 2017-03-13 02:43:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:43:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 02:43:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 02:43:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 02:43:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:43:35 --> Final output sent to browser
DEBUG - 2017-03-13 02:43:35 --> Total execution time: 1.0437
INFO - 2017-03-13 02:43:38 --> Config Class Initialized
INFO - 2017-03-13 02:43:38 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:43:38 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:43:38 --> Utf8 Class Initialized
INFO - 2017-03-13 02:43:38 --> URI Class Initialized
INFO - 2017-03-13 02:43:38 --> Router Class Initialized
INFO - 2017-03-13 02:43:38 --> Output Class Initialized
INFO - 2017-03-13 02:43:38 --> Security Class Initialized
DEBUG - 2017-03-13 02:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:43:38 --> Input Class Initialized
INFO - 2017-03-13 02:43:38 --> Language Class Initialized
INFO - 2017-03-13 02:43:38 --> Loader Class Initialized
INFO - 2017-03-13 02:43:38 --> Database Driver Class Initialized
INFO - 2017-03-13 02:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:43:38 --> Controller Class Initialized
INFO - 2017-03-13 02:43:38 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:43:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:43:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:43:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:43:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:43:38 --> Final output sent to browser
DEBUG - 2017-03-13 02:43:38 --> Total execution time: 0.2548
INFO - 2017-03-13 02:44:04 --> Config Class Initialized
INFO - 2017-03-13 02:44:04 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:44:04 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:44:04 --> Utf8 Class Initialized
INFO - 2017-03-13 02:44:04 --> URI Class Initialized
INFO - 2017-03-13 02:44:04 --> Router Class Initialized
INFO - 2017-03-13 02:44:04 --> Output Class Initialized
INFO - 2017-03-13 02:44:04 --> Security Class Initialized
DEBUG - 2017-03-13 02:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:44:04 --> Input Class Initialized
INFO - 2017-03-13 02:44:04 --> Language Class Initialized
INFO - 2017-03-13 02:44:04 --> Loader Class Initialized
INFO - 2017-03-13 02:44:04 --> Database Driver Class Initialized
INFO - 2017-03-13 02:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:44:04 --> Controller Class Initialized
INFO - 2017-03-13 02:44:04 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:44:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:44:05 --> Config Class Initialized
INFO - 2017-03-13 02:44:05 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:44:05 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:44:05 --> Utf8 Class Initialized
INFO - 2017-03-13 02:44:05 --> URI Class Initialized
INFO - 2017-03-13 02:44:05 --> Router Class Initialized
INFO - 2017-03-13 02:44:05 --> Output Class Initialized
INFO - 2017-03-13 02:44:05 --> Security Class Initialized
DEBUG - 2017-03-13 02:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:44:05 --> Input Class Initialized
INFO - 2017-03-13 02:44:05 --> Language Class Initialized
INFO - 2017-03-13 02:44:05 --> Loader Class Initialized
INFO - 2017-03-13 02:44:05 --> Database Driver Class Initialized
INFO - 2017-03-13 02:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:44:05 --> Controller Class Initialized
INFO - 2017-03-13 02:44:05 --> Helper loaded: date_helper
DEBUG - 2017-03-13 02:44:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:44:05 --> Helper loaded: url_helper
INFO - 2017-03-13 02:44:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:44:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 02:44:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 02:44:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 02:44:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:44:06 --> Final output sent to browser
DEBUG - 2017-03-13 02:44:06 --> Total execution time: 0.1033
INFO - 2017-03-13 02:44:08 --> Config Class Initialized
INFO - 2017-03-13 02:44:08 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:44:08 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:44:08 --> Utf8 Class Initialized
INFO - 2017-03-13 02:44:08 --> URI Class Initialized
INFO - 2017-03-13 02:44:08 --> Router Class Initialized
INFO - 2017-03-13 02:44:08 --> Output Class Initialized
INFO - 2017-03-13 02:44:08 --> Security Class Initialized
DEBUG - 2017-03-13 02:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:44:08 --> Input Class Initialized
INFO - 2017-03-13 02:44:08 --> Language Class Initialized
INFO - 2017-03-13 02:44:08 --> Loader Class Initialized
INFO - 2017-03-13 02:44:08 --> Database Driver Class Initialized
INFO - 2017-03-13 02:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:44:08 --> Controller Class Initialized
INFO - 2017-03-13 02:44:08 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:44:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:44:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:44:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:44:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:44:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:44:08 --> Final output sent to browser
DEBUG - 2017-03-13 02:44:08 --> Total execution time: 0.0262
INFO - 2017-03-13 02:44:16 --> Config Class Initialized
INFO - 2017-03-13 02:44:16 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:44:16 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:44:16 --> Utf8 Class Initialized
INFO - 2017-03-13 02:44:16 --> URI Class Initialized
DEBUG - 2017-03-13 02:44:16 --> No URI present. Default controller set.
INFO - 2017-03-13 02:44:16 --> Router Class Initialized
INFO - 2017-03-13 02:44:16 --> Output Class Initialized
INFO - 2017-03-13 02:44:16 --> Security Class Initialized
DEBUG - 2017-03-13 02:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:44:16 --> Input Class Initialized
INFO - 2017-03-13 02:44:16 --> Language Class Initialized
INFO - 2017-03-13 02:44:16 --> Loader Class Initialized
INFO - 2017-03-13 02:44:16 --> Database Driver Class Initialized
INFO - 2017-03-13 02:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:44:16 --> Controller Class Initialized
INFO - 2017-03-13 02:44:16 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:44:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:44:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:44:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:44:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:44:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:44:16 --> Final output sent to browser
DEBUG - 2017-03-13 02:44:16 --> Total execution time: 0.5285
INFO - 2017-03-13 02:44:25 --> Config Class Initialized
INFO - 2017-03-13 02:44:25 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:44:25 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:44:25 --> Utf8 Class Initialized
INFO - 2017-03-13 02:44:25 --> URI Class Initialized
INFO - 2017-03-13 02:44:25 --> Router Class Initialized
INFO - 2017-03-13 02:44:25 --> Output Class Initialized
INFO - 2017-03-13 02:44:25 --> Security Class Initialized
DEBUG - 2017-03-13 02:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:44:25 --> Input Class Initialized
INFO - 2017-03-13 02:44:25 --> Language Class Initialized
INFO - 2017-03-13 02:44:25 --> Loader Class Initialized
INFO - 2017-03-13 02:44:25 --> Database Driver Class Initialized
INFO - 2017-03-13 02:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:44:25 --> Controller Class Initialized
INFO - 2017-03-13 02:44:25 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:44:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:44:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:44:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:44:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:44:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:44:25 --> Final output sent to browser
DEBUG - 2017-03-13 02:44:25 --> Total execution time: 0.0134
INFO - 2017-03-13 02:44:26 --> Config Class Initialized
INFO - 2017-03-13 02:44:26 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:44:26 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:44:26 --> Utf8 Class Initialized
INFO - 2017-03-13 02:44:26 --> URI Class Initialized
DEBUG - 2017-03-13 02:44:26 --> No URI present. Default controller set.
INFO - 2017-03-13 02:44:26 --> Router Class Initialized
INFO - 2017-03-13 02:44:26 --> Output Class Initialized
INFO - 2017-03-13 02:44:26 --> Security Class Initialized
DEBUG - 2017-03-13 02:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:44:26 --> Input Class Initialized
INFO - 2017-03-13 02:44:26 --> Language Class Initialized
INFO - 2017-03-13 02:44:26 --> Loader Class Initialized
INFO - 2017-03-13 02:44:26 --> Database Driver Class Initialized
INFO - 2017-03-13 02:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:44:26 --> Controller Class Initialized
INFO - 2017-03-13 02:44:26 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:44:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:44:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:44:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:44:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:44:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:44:26 --> Final output sent to browser
DEBUG - 2017-03-13 02:44:26 --> Total execution time: 0.0141
INFO - 2017-03-13 02:44:33 --> Config Class Initialized
INFO - 2017-03-13 02:44:33 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:44:33 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:44:33 --> Utf8 Class Initialized
INFO - 2017-03-13 02:44:33 --> URI Class Initialized
INFO - 2017-03-13 02:44:33 --> Router Class Initialized
INFO - 2017-03-13 02:44:33 --> Output Class Initialized
INFO - 2017-03-13 02:44:33 --> Security Class Initialized
DEBUG - 2017-03-13 02:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:44:33 --> Input Class Initialized
INFO - 2017-03-13 02:44:33 --> Language Class Initialized
INFO - 2017-03-13 02:44:33 --> Loader Class Initialized
INFO - 2017-03-13 02:44:33 --> Database Driver Class Initialized
INFO - 2017-03-13 02:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:44:33 --> Controller Class Initialized
INFO - 2017-03-13 02:44:33 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:44:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:44:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:44:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:44:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:44:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:44:33 --> Final output sent to browser
DEBUG - 2017-03-13 02:44:33 --> Total execution time: 0.0137
INFO - 2017-03-13 02:44:41 --> Config Class Initialized
INFO - 2017-03-13 02:44:41 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:44:41 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:44:41 --> Utf8 Class Initialized
INFO - 2017-03-13 02:44:41 --> URI Class Initialized
INFO - 2017-03-13 02:44:41 --> Router Class Initialized
INFO - 2017-03-13 02:44:41 --> Output Class Initialized
INFO - 2017-03-13 02:44:41 --> Security Class Initialized
DEBUG - 2017-03-13 02:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:44:41 --> Input Class Initialized
INFO - 2017-03-13 02:44:41 --> Language Class Initialized
INFO - 2017-03-13 02:44:41 --> Loader Class Initialized
INFO - 2017-03-13 02:44:42 --> Database Driver Class Initialized
INFO - 2017-03-13 02:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:44:42 --> Controller Class Initialized
INFO - 2017-03-13 02:44:42 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:44:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:44:42 --> Config Class Initialized
INFO - 2017-03-13 02:44:42 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:44:42 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:44:42 --> Utf8 Class Initialized
INFO - 2017-03-13 02:44:42 --> URI Class Initialized
INFO - 2017-03-13 02:44:42 --> Router Class Initialized
INFO - 2017-03-13 02:44:42 --> Output Class Initialized
INFO - 2017-03-13 02:44:42 --> Security Class Initialized
DEBUG - 2017-03-13 02:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:44:42 --> Input Class Initialized
INFO - 2017-03-13 02:44:42 --> Language Class Initialized
INFO - 2017-03-13 02:44:42 --> Loader Class Initialized
INFO - 2017-03-13 02:44:42 --> Database Driver Class Initialized
INFO - 2017-03-13 02:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:44:42 --> Controller Class Initialized
INFO - 2017-03-13 02:44:42 --> Helper loaded: date_helper
DEBUG - 2017-03-13 02:44:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:44:42 --> Helper loaded: url_helper
INFO - 2017-03-13 02:44:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:44:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 02:44:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 02:44:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 02:44:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:44:42 --> Final output sent to browser
DEBUG - 2017-03-13 02:44:42 --> Total execution time: 0.0140
INFO - 2017-03-13 02:44:46 --> Config Class Initialized
INFO - 2017-03-13 02:44:46 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:44:46 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:44:46 --> Utf8 Class Initialized
INFO - 2017-03-13 02:44:46 --> URI Class Initialized
INFO - 2017-03-13 02:44:46 --> Router Class Initialized
INFO - 2017-03-13 02:44:46 --> Output Class Initialized
INFO - 2017-03-13 02:44:46 --> Security Class Initialized
DEBUG - 2017-03-13 02:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:44:46 --> Input Class Initialized
INFO - 2017-03-13 02:44:46 --> Language Class Initialized
INFO - 2017-03-13 02:44:46 --> Loader Class Initialized
INFO - 2017-03-13 02:44:47 --> Database Driver Class Initialized
INFO - 2017-03-13 02:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:44:47 --> Controller Class Initialized
INFO - 2017-03-13 02:44:47 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:44:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:44:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:44:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:44:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:44:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:44:47 --> Final output sent to browser
DEBUG - 2017-03-13 02:44:47 --> Total execution time: 1.1076
INFO - 2017-03-13 02:44:51 --> Config Class Initialized
INFO - 2017-03-13 02:44:51 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:44:52 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:44:52 --> Utf8 Class Initialized
INFO - 2017-03-13 02:44:52 --> URI Class Initialized
DEBUG - 2017-03-13 02:44:52 --> No URI present. Default controller set.
INFO - 2017-03-13 02:44:52 --> Router Class Initialized
INFO - 2017-03-13 02:44:52 --> Output Class Initialized
INFO - 2017-03-13 02:44:52 --> Security Class Initialized
DEBUG - 2017-03-13 02:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:44:52 --> Input Class Initialized
INFO - 2017-03-13 02:44:52 --> Language Class Initialized
INFO - 2017-03-13 02:44:52 --> Loader Class Initialized
INFO - 2017-03-13 02:44:52 --> Database Driver Class Initialized
INFO - 2017-03-13 02:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:44:52 --> Controller Class Initialized
INFO - 2017-03-13 02:44:52 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:44:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:44:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:44:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:44:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:44:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:44:53 --> Final output sent to browser
DEBUG - 2017-03-13 02:44:53 --> Total execution time: 1.2326
INFO - 2017-03-13 02:44:59 --> Config Class Initialized
INFO - 2017-03-13 02:44:59 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:44:59 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:44:59 --> Utf8 Class Initialized
INFO - 2017-03-13 02:44:59 --> URI Class Initialized
INFO - 2017-03-13 02:44:59 --> Router Class Initialized
INFO - 2017-03-13 02:44:59 --> Output Class Initialized
INFO - 2017-03-13 02:44:59 --> Security Class Initialized
DEBUG - 2017-03-13 02:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:44:59 --> Input Class Initialized
INFO - 2017-03-13 02:44:59 --> Language Class Initialized
INFO - 2017-03-13 02:44:59 --> Loader Class Initialized
INFO - 2017-03-13 02:44:59 --> Database Driver Class Initialized
INFO - 2017-03-13 02:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:44:59 --> Controller Class Initialized
INFO - 2017-03-13 02:44:59 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:44:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:44:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:44:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:44:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:44:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:44:59 --> Final output sent to browser
DEBUG - 2017-03-13 02:44:59 --> Total execution time: 0.0602
INFO - 2017-03-13 02:45:25 --> Config Class Initialized
INFO - 2017-03-13 02:45:25 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:45:25 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:45:25 --> Utf8 Class Initialized
INFO - 2017-03-13 02:45:25 --> URI Class Initialized
INFO - 2017-03-13 02:45:25 --> Router Class Initialized
INFO - 2017-03-13 02:45:25 --> Output Class Initialized
INFO - 2017-03-13 02:45:25 --> Security Class Initialized
DEBUG - 2017-03-13 02:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:45:25 --> Input Class Initialized
INFO - 2017-03-13 02:45:25 --> Language Class Initialized
INFO - 2017-03-13 02:45:25 --> Loader Class Initialized
INFO - 2017-03-13 02:45:25 --> Database Driver Class Initialized
INFO - 2017-03-13 02:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:45:26 --> Controller Class Initialized
INFO - 2017-03-13 02:45:26 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:45:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:45:34 --> Config Class Initialized
INFO - 2017-03-13 02:45:34 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:45:34 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:45:34 --> Utf8 Class Initialized
INFO - 2017-03-13 02:45:34 --> URI Class Initialized
INFO - 2017-03-13 02:45:34 --> Router Class Initialized
INFO - 2017-03-13 02:45:34 --> Output Class Initialized
INFO - 2017-03-13 02:45:34 --> Security Class Initialized
DEBUG - 2017-03-13 02:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:45:34 --> Input Class Initialized
INFO - 2017-03-13 02:45:34 --> Language Class Initialized
INFO - 2017-03-13 02:45:34 --> Loader Class Initialized
INFO - 2017-03-13 02:45:34 --> Database Driver Class Initialized
INFO - 2017-03-13 02:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:45:35 --> Controller Class Initialized
INFO - 2017-03-13 02:45:35 --> Helper loaded: date_helper
DEBUG - 2017-03-13 02:45:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:45:35 --> Helper loaded: url_helper
INFO - 2017-03-13 02:45:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:45:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 02:45:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 02:45:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 02:45:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:45:35 --> Final output sent to browser
DEBUG - 2017-03-13 02:45:35 --> Total execution time: 1.1764
INFO - 2017-03-13 02:45:38 --> Config Class Initialized
INFO - 2017-03-13 02:45:38 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:45:38 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:45:38 --> Utf8 Class Initialized
INFO - 2017-03-13 02:45:38 --> URI Class Initialized
INFO - 2017-03-13 02:45:38 --> Router Class Initialized
INFO - 2017-03-13 02:45:38 --> Output Class Initialized
INFO - 2017-03-13 02:45:38 --> Security Class Initialized
DEBUG - 2017-03-13 02:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:45:38 --> Input Class Initialized
INFO - 2017-03-13 02:45:38 --> Language Class Initialized
INFO - 2017-03-13 02:45:38 --> Loader Class Initialized
INFO - 2017-03-13 02:45:39 --> Database Driver Class Initialized
INFO - 2017-03-13 02:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:45:39 --> Controller Class Initialized
INFO - 2017-03-13 02:45:39 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:45:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:45:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:45:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:45:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:45:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:45:39 --> Final output sent to browser
DEBUG - 2017-03-13 02:45:39 --> Total execution time: 1.2435
INFO - 2017-03-13 02:46:57 --> Config Class Initialized
INFO - 2017-03-13 02:46:57 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:46:57 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:46:57 --> Utf8 Class Initialized
INFO - 2017-03-13 02:46:57 --> URI Class Initialized
DEBUG - 2017-03-13 02:46:57 --> No URI present. Default controller set.
INFO - 2017-03-13 02:46:57 --> Router Class Initialized
INFO - 2017-03-13 02:46:57 --> Output Class Initialized
INFO - 2017-03-13 02:46:57 --> Security Class Initialized
DEBUG - 2017-03-13 02:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:46:58 --> Input Class Initialized
INFO - 2017-03-13 02:46:58 --> Language Class Initialized
INFO - 2017-03-13 02:46:58 --> Loader Class Initialized
INFO - 2017-03-13 02:46:58 --> Database Driver Class Initialized
INFO - 2017-03-13 02:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:46:58 --> Controller Class Initialized
INFO - 2017-03-13 02:46:58 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:46:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:46:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:46:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:46:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:46:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:46:59 --> Final output sent to browser
DEBUG - 2017-03-13 02:46:59 --> Total execution time: 1.4709
INFO - 2017-03-13 02:47:18 --> Config Class Initialized
INFO - 2017-03-13 02:47:18 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:47:18 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:47:18 --> Utf8 Class Initialized
INFO - 2017-03-13 02:47:18 --> URI Class Initialized
INFO - 2017-03-13 02:47:18 --> Router Class Initialized
INFO - 2017-03-13 02:47:18 --> Output Class Initialized
INFO - 2017-03-13 02:47:18 --> Security Class Initialized
DEBUG - 2017-03-13 02:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:47:18 --> Input Class Initialized
INFO - 2017-03-13 02:47:18 --> Language Class Initialized
INFO - 2017-03-13 02:47:18 --> Loader Class Initialized
INFO - 2017-03-13 02:47:18 --> Database Driver Class Initialized
INFO - 2017-03-13 02:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:47:18 --> Controller Class Initialized
INFO - 2017-03-13 02:47:18 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:47:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:47:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:47:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:47:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:47:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:47:18 --> Final output sent to browser
DEBUG - 2017-03-13 02:47:18 --> Total execution time: 0.0140
INFO - 2017-03-13 02:47:52 --> Config Class Initialized
INFO - 2017-03-13 02:47:52 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:47:52 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:47:52 --> Utf8 Class Initialized
INFO - 2017-03-13 02:47:52 --> URI Class Initialized
INFO - 2017-03-13 02:47:52 --> Router Class Initialized
INFO - 2017-03-13 02:47:52 --> Output Class Initialized
INFO - 2017-03-13 02:47:52 --> Security Class Initialized
DEBUG - 2017-03-13 02:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:47:52 --> Input Class Initialized
INFO - 2017-03-13 02:47:52 --> Language Class Initialized
INFO - 2017-03-13 02:47:52 --> Loader Class Initialized
INFO - 2017-03-13 02:47:52 --> Database Driver Class Initialized
INFO - 2017-03-13 02:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:47:53 --> Controller Class Initialized
INFO - 2017-03-13 02:47:53 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:47:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:47:54 --> Config Class Initialized
INFO - 2017-03-13 02:47:54 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:47:54 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:47:54 --> Utf8 Class Initialized
INFO - 2017-03-13 02:47:54 --> URI Class Initialized
INFO - 2017-03-13 02:47:54 --> Router Class Initialized
INFO - 2017-03-13 02:47:54 --> Output Class Initialized
INFO - 2017-03-13 02:47:54 --> Security Class Initialized
DEBUG - 2017-03-13 02:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:47:54 --> Input Class Initialized
INFO - 2017-03-13 02:47:54 --> Language Class Initialized
INFO - 2017-03-13 02:47:54 --> Loader Class Initialized
INFO - 2017-03-13 02:47:54 --> Database Driver Class Initialized
INFO - 2017-03-13 02:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:47:54 --> Controller Class Initialized
INFO - 2017-03-13 02:47:54 --> Helper loaded: date_helper
DEBUG - 2017-03-13 02:47:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:47:54 --> Helper loaded: url_helper
INFO - 2017-03-13 02:47:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:47:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 02:47:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 02:47:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 02:47:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:47:54 --> Final output sent to browser
DEBUG - 2017-03-13 02:47:54 --> Total execution time: 0.0882
INFO - 2017-03-13 02:48:05 --> Config Class Initialized
INFO - 2017-03-13 02:48:05 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:48:05 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:48:05 --> Utf8 Class Initialized
INFO - 2017-03-13 02:48:05 --> URI Class Initialized
INFO - 2017-03-13 02:48:05 --> Router Class Initialized
INFO - 2017-03-13 02:48:05 --> Output Class Initialized
INFO - 2017-03-13 02:48:05 --> Security Class Initialized
DEBUG - 2017-03-13 02:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:48:05 --> Input Class Initialized
INFO - 2017-03-13 02:48:05 --> Language Class Initialized
INFO - 2017-03-13 02:48:05 --> Loader Class Initialized
INFO - 2017-03-13 02:48:05 --> Database Driver Class Initialized
INFO - 2017-03-13 02:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:48:05 --> Controller Class Initialized
INFO - 2017-03-13 02:48:05 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:48:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:48:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:48:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:48:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:48:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:48:05 --> Final output sent to browser
DEBUG - 2017-03-13 02:48:05 --> Total execution time: 0.0151
INFO - 2017-03-13 02:48:11 --> Config Class Initialized
INFO - 2017-03-13 02:48:11 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:48:11 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:48:11 --> Utf8 Class Initialized
INFO - 2017-03-13 02:48:11 --> URI Class Initialized
DEBUG - 2017-03-13 02:48:11 --> No URI present. Default controller set.
INFO - 2017-03-13 02:48:11 --> Router Class Initialized
INFO - 2017-03-13 02:48:11 --> Output Class Initialized
INFO - 2017-03-13 02:48:11 --> Security Class Initialized
DEBUG - 2017-03-13 02:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:48:11 --> Input Class Initialized
INFO - 2017-03-13 02:48:11 --> Language Class Initialized
INFO - 2017-03-13 02:48:11 --> Loader Class Initialized
INFO - 2017-03-13 02:48:11 --> Database Driver Class Initialized
INFO - 2017-03-13 02:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:48:11 --> Controller Class Initialized
INFO - 2017-03-13 02:48:11 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:48:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:48:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:48:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:48:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:48:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:48:11 --> Final output sent to browser
DEBUG - 2017-03-13 02:48:11 --> Total execution time: 0.0171
INFO - 2017-03-13 02:48:23 --> Config Class Initialized
INFO - 2017-03-13 02:48:23 --> Hooks Class Initialized
DEBUG - 2017-03-13 02:48:23 --> UTF-8 Support Enabled
INFO - 2017-03-13 02:48:23 --> Utf8 Class Initialized
INFO - 2017-03-13 02:48:23 --> URI Class Initialized
INFO - 2017-03-13 02:48:23 --> Router Class Initialized
INFO - 2017-03-13 02:48:23 --> Output Class Initialized
INFO - 2017-03-13 02:48:23 --> Security Class Initialized
DEBUG - 2017-03-13 02:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 02:48:23 --> Input Class Initialized
INFO - 2017-03-13 02:48:23 --> Language Class Initialized
INFO - 2017-03-13 02:48:23 --> Loader Class Initialized
INFO - 2017-03-13 02:48:23 --> Database Driver Class Initialized
INFO - 2017-03-13 02:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 02:48:23 --> Controller Class Initialized
INFO - 2017-03-13 02:48:23 --> Helper loaded: url_helper
DEBUG - 2017-03-13 02:48:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 02:48:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 02:48:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 02:48:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 02:48:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 02:48:23 --> Final output sent to browser
DEBUG - 2017-03-13 02:48:23 --> Total execution time: 0.0172
INFO - 2017-03-13 05:52:44 --> Config Class Initialized
INFO - 2017-03-13 05:52:44 --> Hooks Class Initialized
DEBUG - 2017-03-13 05:52:44 --> UTF-8 Support Enabled
INFO - 2017-03-13 05:52:44 --> Utf8 Class Initialized
INFO - 2017-03-13 05:52:44 --> URI Class Initialized
INFO - 2017-03-13 05:52:44 --> Router Class Initialized
INFO - 2017-03-13 05:52:44 --> Output Class Initialized
INFO - 2017-03-13 05:52:44 --> Security Class Initialized
DEBUG - 2017-03-13 05:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 05:52:44 --> Input Class Initialized
INFO - 2017-03-13 05:52:44 --> Language Class Initialized
INFO - 2017-03-13 05:52:45 --> Loader Class Initialized
INFO - 2017-03-13 05:52:45 --> Database Driver Class Initialized
INFO - 2017-03-13 05:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 05:52:45 --> Controller Class Initialized
INFO - 2017-03-13 05:52:46 --> Helper loaded: date_helper
DEBUG - 2017-03-13 05:52:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 05:52:46 --> Helper loaded: url_helper
INFO - 2017-03-13 05:52:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 05:52:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 05:52:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 05:52:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 05:52:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 05:52:46 --> Final output sent to browser
DEBUG - 2017-03-13 05:52:46 --> Total execution time: 2.6258
INFO - 2017-03-13 08:41:44 --> Config Class Initialized
INFO - 2017-03-13 08:41:44 --> Hooks Class Initialized
DEBUG - 2017-03-13 08:41:44 --> UTF-8 Support Enabled
INFO - 2017-03-13 08:41:44 --> Utf8 Class Initialized
INFO - 2017-03-13 08:41:44 --> URI Class Initialized
INFO - 2017-03-13 08:41:44 --> Router Class Initialized
INFO - 2017-03-13 08:41:44 --> Output Class Initialized
INFO - 2017-03-13 08:41:44 --> Security Class Initialized
DEBUG - 2017-03-13 08:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 08:41:45 --> Input Class Initialized
INFO - 2017-03-13 08:41:45 --> Language Class Initialized
INFO - 2017-03-13 08:41:45 --> Loader Class Initialized
INFO - 2017-03-13 08:41:45 --> Database Driver Class Initialized
INFO - 2017-03-13 08:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 08:41:46 --> Controller Class Initialized
INFO - 2017-03-13 08:41:46 --> Helper loaded: url_helper
DEBUG - 2017-03-13 08:41:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 08:41:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 08:41:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 08:41:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 08:41:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 08:41:46 --> Final output sent to browser
DEBUG - 2017-03-13 08:41:46 --> Total execution time: 1.7677
INFO - 2017-03-13 13:28:12 --> Config Class Initialized
INFO - 2017-03-13 13:28:12 --> Hooks Class Initialized
DEBUG - 2017-03-13 13:28:12 --> UTF-8 Support Enabled
INFO - 2017-03-13 13:28:12 --> Utf8 Class Initialized
INFO - 2017-03-13 13:28:12 --> URI Class Initialized
DEBUG - 2017-03-13 13:28:12 --> No URI present. Default controller set.
INFO - 2017-03-13 13:28:12 --> Router Class Initialized
INFO - 2017-03-13 13:28:12 --> Output Class Initialized
INFO - 2017-03-13 13:28:12 --> Security Class Initialized
DEBUG - 2017-03-13 13:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 13:28:12 --> Input Class Initialized
INFO - 2017-03-13 13:28:12 --> Language Class Initialized
INFO - 2017-03-13 13:28:12 --> Loader Class Initialized
INFO - 2017-03-13 13:28:12 --> Database Driver Class Initialized
INFO - 2017-03-13 13:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 13:28:13 --> Controller Class Initialized
INFO - 2017-03-13 13:28:13 --> Helper loaded: url_helper
DEBUG - 2017-03-13 13:28:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 13:28:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 13:28:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 13:28:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 13:28:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 13:28:13 --> Final output sent to browser
DEBUG - 2017-03-13 13:28:13 --> Total execution time: 1.7238
INFO - 2017-03-13 15:08:50 --> Config Class Initialized
INFO - 2017-03-13 15:08:50 --> Hooks Class Initialized
DEBUG - 2017-03-13 15:08:50 --> UTF-8 Support Enabled
INFO - 2017-03-13 15:08:50 --> Utf8 Class Initialized
INFO - 2017-03-13 15:08:50 --> URI Class Initialized
DEBUG - 2017-03-13 15:08:50 --> No URI present. Default controller set.
INFO - 2017-03-13 15:08:50 --> Router Class Initialized
INFO - 2017-03-13 15:08:50 --> Output Class Initialized
INFO - 2017-03-13 15:08:50 --> Security Class Initialized
DEBUG - 2017-03-13 15:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 15:08:50 --> Input Class Initialized
INFO - 2017-03-13 15:08:50 --> Language Class Initialized
INFO - 2017-03-13 15:08:50 --> Loader Class Initialized
INFO - 2017-03-13 15:08:51 --> Database Driver Class Initialized
INFO - 2017-03-13 15:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 15:08:51 --> Controller Class Initialized
INFO - 2017-03-13 15:08:51 --> Helper loaded: url_helper
DEBUG - 2017-03-13 15:08:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 15:08:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 15:08:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 15:08:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 15:08:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 15:08:51 --> Final output sent to browser
DEBUG - 2017-03-13 15:08:51 --> Total execution time: 1.7710
INFO - 2017-03-13 16:09:01 --> Config Class Initialized
INFO - 2017-03-13 16:09:01 --> Hooks Class Initialized
DEBUG - 2017-03-13 16:09:01 --> UTF-8 Support Enabled
INFO - 2017-03-13 16:09:01 --> Utf8 Class Initialized
INFO - 2017-03-13 16:09:01 --> URI Class Initialized
INFO - 2017-03-13 16:09:01 --> Router Class Initialized
INFO - 2017-03-13 16:09:02 --> Output Class Initialized
INFO - 2017-03-13 16:09:02 --> Security Class Initialized
DEBUG - 2017-03-13 16:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 16:09:02 --> Input Class Initialized
INFO - 2017-03-13 16:09:02 --> Config Class Initialized
INFO - 2017-03-13 16:09:02 --> Hooks Class Initialized
INFO - 2017-03-13 16:09:02 --> Config Class Initialized
INFO - 2017-03-13 16:09:02 --> Hooks Class Initialized
DEBUG - 2017-03-13 16:09:02 --> UTF-8 Support Enabled
INFO - 2017-03-13 16:09:02 --> Utf8 Class Initialized
INFO - 2017-03-13 16:09:02 --> URI Class Initialized
DEBUG - 2017-03-13 16:09:02 --> UTF-8 Support Enabled
INFO - 2017-03-13 16:09:02 --> Utf8 Class Initialized
INFO - 2017-03-13 16:09:02 --> URI Class Initialized
INFO - 2017-03-13 16:09:02 --> Router Class Initialized
DEBUG - 2017-03-13 16:09:02 --> No URI present. Default controller set.
INFO - 2017-03-13 16:09:02 --> Router Class Initialized
INFO - 2017-03-13 16:09:02 --> Output Class Initialized
INFO - 2017-03-13 16:09:02 --> Output Class Initialized
INFO - 2017-03-13 16:09:02 --> Security Class Initialized
INFO - 2017-03-13 16:09:02 --> Security Class Initialized
DEBUG - 2017-03-13 16:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 16:09:02 --> Input Class Initialized
DEBUG - 2017-03-13 16:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 16:09:02 --> Input Class Initialized
INFO - 2017-03-13 16:09:02 --> Language Class Initialized
INFO - 2017-03-13 16:09:02 --> Language Class Initialized
INFO - 2017-03-13 16:09:02 --> Language Class Initialized
INFO - 2017-03-13 16:09:02 --> Loader Class Initialized
INFO - 2017-03-13 16:09:02 --> Loader Class Initialized
INFO - 2017-03-13 16:09:02 --> Loader Class Initialized
INFO - 2017-03-13 16:09:02 --> Database Driver Class Initialized
INFO - 2017-03-13 16:09:02 --> Database Driver Class Initialized
INFO - 2017-03-13 16:09:02 --> Database Driver Class Initialized
INFO - 2017-03-13 16:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 16:09:02 --> Controller Class Initialized
INFO - 2017-03-13 16:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 16:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 16:09:02 --> Controller Class Initialized
INFO - 2017-03-13 16:09:03 --> Controller Class Initialized
INFO - 2017-03-13 16:09:03 --> Helper loaded: url_helper
INFO - 2017-03-13 16:09:03 --> Helper loaded: url_helper
INFO - 2017-03-13 16:09:03 --> Helper loaded: url_helper
DEBUG - 2017-03-13 16:09:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-13 16:09:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-13 16:09:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 16:09:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 16:09:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 16:09:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 16:09:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 16:09:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 16:09:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 16:09:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 16:09:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 16:09:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 16:09:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 16:09:03 --> Final output sent to browser
DEBUG - 2017-03-13 16:09:03 --> Total execution time: 1.8339
INFO - 2017-03-13 16:09:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 16:09:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 16:09:03 --> Final output sent to browser
DEBUG - 2017-03-13 16:09:03 --> Total execution time: 1.4457
INFO - 2017-03-13 16:09:03 --> Final output sent to browser
DEBUG - 2017-03-13 16:09:03 --> Total execution time: 1.4635
INFO - 2017-03-13 16:44:17 --> Config Class Initialized
INFO - 2017-03-13 16:44:17 --> Hooks Class Initialized
DEBUG - 2017-03-13 16:44:17 --> UTF-8 Support Enabled
INFO - 2017-03-13 16:44:17 --> Utf8 Class Initialized
INFO - 2017-03-13 16:44:17 --> URI Class Initialized
DEBUG - 2017-03-13 16:44:17 --> No URI present. Default controller set.
INFO - 2017-03-13 16:44:17 --> Router Class Initialized
INFO - 2017-03-13 16:44:17 --> Output Class Initialized
INFO - 2017-03-13 16:44:17 --> Security Class Initialized
DEBUG - 2017-03-13 16:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 16:44:17 --> Input Class Initialized
INFO - 2017-03-13 16:44:17 --> Language Class Initialized
INFO - 2017-03-13 16:44:17 --> Loader Class Initialized
INFO - 2017-03-13 16:44:18 --> Database Driver Class Initialized
INFO - 2017-03-13 16:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 16:44:18 --> Controller Class Initialized
INFO - 2017-03-13 16:44:18 --> Helper loaded: url_helper
DEBUG - 2017-03-13 16:44:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 16:44:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 16:44:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 16:44:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 16:44:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 16:44:19 --> Final output sent to browser
DEBUG - 2017-03-13 16:44:19 --> Total execution time: 2.2269
INFO - 2017-03-13 16:44:23 --> Config Class Initialized
INFO - 2017-03-13 16:44:23 --> Hooks Class Initialized
DEBUG - 2017-03-13 16:44:23 --> UTF-8 Support Enabled
INFO - 2017-03-13 16:44:23 --> Utf8 Class Initialized
INFO - 2017-03-13 16:44:23 --> URI Class Initialized
INFO - 2017-03-13 16:44:23 --> Router Class Initialized
INFO - 2017-03-13 16:44:23 --> Output Class Initialized
INFO - 2017-03-13 16:44:23 --> Security Class Initialized
DEBUG - 2017-03-13 16:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 16:44:23 --> Input Class Initialized
INFO - 2017-03-13 16:44:23 --> Language Class Initialized
INFO - 2017-03-13 16:44:23 --> Loader Class Initialized
INFO - 2017-03-13 16:44:23 --> Database Driver Class Initialized
INFO - 2017-03-13 16:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 16:44:24 --> Controller Class Initialized
INFO - 2017-03-13 16:44:24 --> Helper loaded: url_helper
DEBUG - 2017-03-13 16:44:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 16:44:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 16:44:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 16:44:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 16:44:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 16:44:24 --> Final output sent to browser
DEBUG - 2017-03-13 16:44:24 --> Total execution time: 1.2406
INFO - 2017-03-13 16:45:35 --> Config Class Initialized
INFO - 2017-03-13 16:45:35 --> Hooks Class Initialized
DEBUG - 2017-03-13 16:45:35 --> UTF-8 Support Enabled
INFO - 2017-03-13 16:45:35 --> Utf8 Class Initialized
INFO - 2017-03-13 16:45:35 --> URI Class Initialized
INFO - 2017-03-13 16:45:35 --> Router Class Initialized
INFO - 2017-03-13 16:45:35 --> Output Class Initialized
INFO - 2017-03-13 16:45:35 --> Security Class Initialized
DEBUG - 2017-03-13 16:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 16:45:35 --> Input Class Initialized
INFO - 2017-03-13 16:45:35 --> Language Class Initialized
INFO - 2017-03-13 16:45:35 --> Loader Class Initialized
INFO - 2017-03-13 16:45:35 --> Database Driver Class Initialized
INFO - 2017-03-13 16:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 16:45:35 --> Controller Class Initialized
INFO - 2017-03-13 16:45:35 --> Helper loaded: url_helper
DEBUG - 2017-03-13 16:45:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 16:45:39 --> Config Class Initialized
INFO - 2017-03-13 16:45:39 --> Hooks Class Initialized
DEBUG - 2017-03-13 16:45:39 --> UTF-8 Support Enabled
INFO - 2017-03-13 16:45:39 --> Utf8 Class Initialized
INFO - 2017-03-13 16:45:39 --> URI Class Initialized
INFO - 2017-03-13 16:45:39 --> Router Class Initialized
INFO - 2017-03-13 16:45:39 --> Output Class Initialized
INFO - 2017-03-13 16:45:39 --> Security Class Initialized
DEBUG - 2017-03-13 16:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 16:45:39 --> Input Class Initialized
INFO - 2017-03-13 16:45:39 --> Language Class Initialized
INFO - 2017-03-13 16:45:39 --> Loader Class Initialized
INFO - 2017-03-13 16:45:39 --> Database Driver Class Initialized
INFO - 2017-03-13 16:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 16:45:39 --> Controller Class Initialized
INFO - 2017-03-13 16:45:39 --> Helper loaded: date_helper
DEBUG - 2017-03-13 16:45:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 16:45:39 --> Helper loaded: url_helper
INFO - 2017-03-13 16:45:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 16:45:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 16:45:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 16:45:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 16:45:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 16:45:39 --> Final output sent to browser
DEBUG - 2017-03-13 16:45:39 --> Total execution time: 0.2501
INFO - 2017-03-13 16:45:40 --> Config Class Initialized
INFO - 2017-03-13 16:45:40 --> Hooks Class Initialized
DEBUG - 2017-03-13 16:45:40 --> UTF-8 Support Enabled
INFO - 2017-03-13 16:45:40 --> Utf8 Class Initialized
INFO - 2017-03-13 16:45:40 --> URI Class Initialized
INFO - 2017-03-13 16:45:40 --> Router Class Initialized
INFO - 2017-03-13 16:45:40 --> Output Class Initialized
INFO - 2017-03-13 16:45:40 --> Security Class Initialized
DEBUG - 2017-03-13 16:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 16:45:40 --> Input Class Initialized
INFO - 2017-03-13 16:45:40 --> Language Class Initialized
INFO - 2017-03-13 16:45:40 --> Loader Class Initialized
INFO - 2017-03-13 16:45:40 --> Database Driver Class Initialized
INFO - 2017-03-13 16:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 16:45:40 --> Controller Class Initialized
INFO - 2017-03-13 16:45:40 --> Helper loaded: url_helper
DEBUG - 2017-03-13 16:45:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 16:45:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 16:45:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 16:45:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 16:45:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 16:45:40 --> Final output sent to browser
DEBUG - 2017-03-13 16:45:40 --> Total execution time: 0.0133
INFO - 2017-03-13 17:33:10 --> Config Class Initialized
INFO - 2017-03-13 17:33:10 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:33:10 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:33:10 --> Utf8 Class Initialized
INFO - 2017-03-13 17:33:10 --> URI Class Initialized
DEBUG - 2017-03-13 17:33:11 --> No URI present. Default controller set.
INFO - 2017-03-13 17:33:11 --> Router Class Initialized
INFO - 2017-03-13 17:33:11 --> Output Class Initialized
INFO - 2017-03-13 17:33:11 --> Security Class Initialized
DEBUG - 2017-03-13 17:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:33:11 --> Input Class Initialized
INFO - 2017-03-13 17:33:11 --> Language Class Initialized
INFO - 2017-03-13 17:33:11 --> Loader Class Initialized
INFO - 2017-03-13 17:33:11 --> Database Driver Class Initialized
INFO - 2017-03-13 17:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:33:12 --> Controller Class Initialized
INFO - 2017-03-13 17:33:12 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:33:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:33:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:33:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:33:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:33:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:33:12 --> Final output sent to browser
DEBUG - 2017-03-13 17:33:12 --> Total execution time: 1.7626
INFO - 2017-03-13 17:33:20 --> Config Class Initialized
INFO - 2017-03-13 17:33:20 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:33:20 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:33:20 --> Utf8 Class Initialized
INFO - 2017-03-13 17:33:20 --> URI Class Initialized
INFO - 2017-03-13 17:33:20 --> Router Class Initialized
INFO - 2017-03-13 17:33:20 --> Output Class Initialized
INFO - 2017-03-13 17:33:20 --> Security Class Initialized
DEBUG - 2017-03-13 17:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:33:20 --> Input Class Initialized
INFO - 2017-03-13 17:33:20 --> Language Class Initialized
INFO - 2017-03-13 17:33:20 --> Loader Class Initialized
INFO - 2017-03-13 17:33:20 --> Database Driver Class Initialized
INFO - 2017-03-13 17:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:33:20 --> Controller Class Initialized
INFO - 2017-03-13 17:33:20 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:33:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:33:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:33:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:33:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:33:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:33:20 --> Final output sent to browser
DEBUG - 2017-03-13 17:33:20 --> Total execution time: 0.0133
INFO - 2017-03-13 17:33:26 --> Config Class Initialized
INFO - 2017-03-13 17:33:26 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:33:26 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:33:26 --> Utf8 Class Initialized
INFO - 2017-03-13 17:33:26 --> URI Class Initialized
DEBUG - 2017-03-13 17:33:26 --> No URI present. Default controller set.
INFO - 2017-03-13 17:33:26 --> Router Class Initialized
INFO - 2017-03-13 17:33:26 --> Output Class Initialized
INFO - 2017-03-13 17:33:26 --> Security Class Initialized
DEBUG - 2017-03-13 17:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:33:26 --> Input Class Initialized
INFO - 2017-03-13 17:33:26 --> Language Class Initialized
INFO - 2017-03-13 17:33:26 --> Loader Class Initialized
INFO - 2017-03-13 17:33:26 --> Database Driver Class Initialized
INFO - 2017-03-13 17:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:33:26 --> Controller Class Initialized
INFO - 2017-03-13 17:33:26 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:33:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:33:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:33:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:33:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:33:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:33:26 --> Final output sent to browser
DEBUG - 2017-03-13 17:33:26 --> Total execution time: 0.0230
INFO - 2017-03-13 17:36:33 --> Config Class Initialized
INFO - 2017-03-13 17:36:33 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:36:33 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:36:33 --> Utf8 Class Initialized
INFO - 2017-03-13 17:36:33 --> URI Class Initialized
DEBUG - 2017-03-13 17:36:33 --> No URI present. Default controller set.
INFO - 2017-03-13 17:36:33 --> Router Class Initialized
INFO - 2017-03-13 17:36:33 --> Output Class Initialized
INFO - 2017-03-13 17:36:33 --> Security Class Initialized
DEBUG - 2017-03-13 17:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:36:34 --> Input Class Initialized
INFO - 2017-03-13 17:36:34 --> Language Class Initialized
INFO - 2017-03-13 17:36:34 --> Loader Class Initialized
INFO - 2017-03-13 17:36:34 --> Database Driver Class Initialized
INFO - 2017-03-13 17:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:36:34 --> Controller Class Initialized
INFO - 2017-03-13 17:36:34 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:36:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:36:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:36:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:36:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:36:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:36:35 --> Final output sent to browser
DEBUG - 2017-03-13 17:36:35 --> Total execution time: 1.7959
INFO - 2017-03-13 17:36:42 --> Config Class Initialized
INFO - 2017-03-13 17:36:42 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:36:42 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:36:42 --> Utf8 Class Initialized
INFO - 2017-03-13 17:36:42 --> URI Class Initialized
INFO - 2017-03-13 17:36:42 --> Router Class Initialized
INFO - 2017-03-13 17:36:42 --> Output Class Initialized
INFO - 2017-03-13 17:36:42 --> Security Class Initialized
DEBUG - 2017-03-13 17:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:36:42 --> Input Class Initialized
INFO - 2017-03-13 17:36:42 --> Language Class Initialized
INFO - 2017-03-13 17:36:42 --> Loader Class Initialized
INFO - 2017-03-13 17:36:42 --> Database Driver Class Initialized
INFO - 2017-03-13 17:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:36:42 --> Controller Class Initialized
INFO - 2017-03-13 17:36:42 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:36:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:36:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:36:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:36:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:36:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:36:42 --> Final output sent to browser
DEBUG - 2017-03-13 17:36:42 --> Total execution time: 0.0149
INFO - 2017-03-13 17:37:32 --> Config Class Initialized
INFO - 2017-03-13 17:37:32 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:37:32 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:37:32 --> Utf8 Class Initialized
INFO - 2017-03-13 17:37:32 --> URI Class Initialized
DEBUG - 2017-03-13 17:37:32 --> No URI present. Default controller set.
INFO - 2017-03-13 17:37:32 --> Router Class Initialized
INFO - 2017-03-13 17:37:32 --> Output Class Initialized
INFO - 2017-03-13 17:37:32 --> Security Class Initialized
DEBUG - 2017-03-13 17:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:37:32 --> Input Class Initialized
INFO - 2017-03-13 17:37:32 --> Language Class Initialized
INFO - 2017-03-13 17:37:32 --> Loader Class Initialized
INFO - 2017-03-13 17:37:33 --> Database Driver Class Initialized
INFO - 2017-03-13 17:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:37:33 --> Controller Class Initialized
INFO - 2017-03-13 17:37:33 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:37:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:37:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:37:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:37:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:37:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:37:33 --> Final output sent to browser
DEBUG - 2017-03-13 17:37:33 --> Total execution time: 1.8077
INFO - 2017-03-13 17:37:47 --> Config Class Initialized
INFO - 2017-03-13 17:37:47 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:37:47 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:37:47 --> Utf8 Class Initialized
INFO - 2017-03-13 17:37:47 --> URI Class Initialized
INFO - 2017-03-13 17:37:47 --> Router Class Initialized
INFO - 2017-03-13 17:37:47 --> Output Class Initialized
INFO - 2017-03-13 17:37:47 --> Security Class Initialized
DEBUG - 2017-03-13 17:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:37:47 --> Input Class Initialized
INFO - 2017-03-13 17:37:47 --> Language Class Initialized
INFO - 2017-03-13 17:37:47 --> Loader Class Initialized
INFO - 2017-03-13 17:37:47 --> Database Driver Class Initialized
INFO - 2017-03-13 17:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:37:47 --> Controller Class Initialized
INFO - 2017-03-13 17:37:47 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:37:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:37:48 --> Config Class Initialized
INFO - 2017-03-13 17:37:48 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:37:48 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:37:48 --> Utf8 Class Initialized
INFO - 2017-03-13 17:37:48 --> URI Class Initialized
INFO - 2017-03-13 17:37:48 --> Router Class Initialized
INFO - 2017-03-13 17:37:48 --> Output Class Initialized
INFO - 2017-03-13 17:37:48 --> Security Class Initialized
DEBUG - 2017-03-13 17:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:37:48 --> Input Class Initialized
INFO - 2017-03-13 17:37:48 --> Language Class Initialized
INFO - 2017-03-13 17:37:48 --> Loader Class Initialized
INFO - 2017-03-13 17:37:48 --> Database Driver Class Initialized
INFO - 2017-03-13 17:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:37:48 --> Controller Class Initialized
INFO - 2017-03-13 17:37:48 --> Helper loaded: date_helper
DEBUG - 2017-03-13 17:37:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:37:48 --> Helper loaded: url_helper
INFO - 2017-03-13 17:37:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:37:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 17:37:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 17:37:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 17:37:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:37:48 --> Final output sent to browser
DEBUG - 2017-03-13 17:37:48 --> Total execution time: 0.0979
INFO - 2017-03-13 17:37:50 --> Config Class Initialized
INFO - 2017-03-13 17:37:50 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:37:50 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:37:50 --> Utf8 Class Initialized
INFO - 2017-03-13 17:37:50 --> URI Class Initialized
INFO - 2017-03-13 17:37:50 --> Router Class Initialized
INFO - 2017-03-13 17:37:50 --> Output Class Initialized
INFO - 2017-03-13 17:37:50 --> Security Class Initialized
DEBUG - 2017-03-13 17:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:37:50 --> Input Class Initialized
INFO - 2017-03-13 17:37:50 --> Language Class Initialized
INFO - 2017-03-13 17:37:50 --> Loader Class Initialized
INFO - 2017-03-13 17:37:50 --> Database Driver Class Initialized
INFO - 2017-03-13 17:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:37:50 --> Controller Class Initialized
INFO - 2017-03-13 17:37:50 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:37:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:37:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:37:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:37:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:37:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:37:50 --> Final output sent to browser
DEBUG - 2017-03-13 17:37:50 --> Total execution time: 0.0151
INFO - 2017-03-13 17:37:57 --> Config Class Initialized
INFO - 2017-03-13 17:37:57 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:37:57 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:37:57 --> Utf8 Class Initialized
INFO - 2017-03-13 17:37:57 --> URI Class Initialized
DEBUG - 2017-03-13 17:37:57 --> No URI present. Default controller set.
INFO - 2017-03-13 17:37:57 --> Router Class Initialized
INFO - 2017-03-13 17:37:57 --> Output Class Initialized
INFO - 2017-03-13 17:37:57 --> Security Class Initialized
DEBUG - 2017-03-13 17:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:37:57 --> Input Class Initialized
INFO - 2017-03-13 17:37:57 --> Language Class Initialized
INFO - 2017-03-13 17:37:57 --> Loader Class Initialized
INFO - 2017-03-13 17:37:57 --> Database Driver Class Initialized
INFO - 2017-03-13 17:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:37:57 --> Controller Class Initialized
INFO - 2017-03-13 17:37:57 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:37:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:37:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:37:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:37:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:37:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:37:57 --> Final output sent to browser
DEBUG - 2017-03-13 17:37:57 --> Total execution time: 0.0139
INFO - 2017-03-13 17:37:58 --> Config Class Initialized
INFO - 2017-03-13 17:37:58 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:37:58 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:37:58 --> Utf8 Class Initialized
INFO - 2017-03-13 17:37:58 --> URI Class Initialized
INFO - 2017-03-13 17:37:58 --> Router Class Initialized
INFO - 2017-03-13 17:37:58 --> Output Class Initialized
INFO - 2017-03-13 17:37:58 --> Security Class Initialized
DEBUG - 2017-03-13 17:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:37:58 --> Input Class Initialized
INFO - 2017-03-13 17:37:58 --> Language Class Initialized
INFO - 2017-03-13 17:37:58 --> Loader Class Initialized
INFO - 2017-03-13 17:37:58 --> Database Driver Class Initialized
INFO - 2017-03-13 17:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:37:58 --> Controller Class Initialized
INFO - 2017-03-13 17:37:58 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:37:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:37:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:37:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:37:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:37:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:37:58 --> Final output sent to browser
DEBUG - 2017-03-13 17:37:58 --> Total execution time: 0.0149
INFO - 2017-03-13 17:38:02 --> Config Class Initialized
INFO - 2017-03-13 17:38:02 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:38:02 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:38:02 --> Utf8 Class Initialized
INFO - 2017-03-13 17:38:02 --> URI Class Initialized
INFO - 2017-03-13 17:38:02 --> Router Class Initialized
INFO - 2017-03-13 17:38:02 --> Output Class Initialized
INFO - 2017-03-13 17:38:02 --> Security Class Initialized
DEBUG - 2017-03-13 17:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:38:02 --> Input Class Initialized
INFO - 2017-03-13 17:38:02 --> Language Class Initialized
INFO - 2017-03-13 17:38:02 --> Loader Class Initialized
INFO - 2017-03-13 17:38:02 --> Database Driver Class Initialized
INFO - 2017-03-13 17:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:38:02 --> Controller Class Initialized
INFO - 2017-03-13 17:38:02 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:38:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:38:03 --> Config Class Initialized
INFO - 2017-03-13 17:38:03 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:38:03 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:38:03 --> Utf8 Class Initialized
INFO - 2017-03-13 17:38:03 --> URI Class Initialized
INFO - 2017-03-13 17:38:03 --> Router Class Initialized
INFO - 2017-03-13 17:38:03 --> Output Class Initialized
INFO - 2017-03-13 17:38:03 --> Security Class Initialized
DEBUG - 2017-03-13 17:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:38:03 --> Input Class Initialized
INFO - 2017-03-13 17:38:03 --> Language Class Initialized
INFO - 2017-03-13 17:38:03 --> Loader Class Initialized
INFO - 2017-03-13 17:38:03 --> Database Driver Class Initialized
INFO - 2017-03-13 17:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:38:03 --> Controller Class Initialized
INFO - 2017-03-13 17:38:03 --> Helper loaded: date_helper
DEBUG - 2017-03-13 17:38:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:38:03 --> Helper loaded: url_helper
INFO - 2017-03-13 17:38:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:38:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 17:38:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 17:38:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 17:38:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:38:03 --> Final output sent to browser
DEBUG - 2017-03-13 17:38:03 --> Total execution time: 0.0156
INFO - 2017-03-13 17:38:04 --> Config Class Initialized
INFO - 2017-03-13 17:38:04 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:38:04 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:38:04 --> Utf8 Class Initialized
INFO - 2017-03-13 17:38:04 --> URI Class Initialized
INFO - 2017-03-13 17:38:04 --> Router Class Initialized
INFO - 2017-03-13 17:38:04 --> Output Class Initialized
INFO - 2017-03-13 17:38:04 --> Security Class Initialized
DEBUG - 2017-03-13 17:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:38:04 --> Input Class Initialized
INFO - 2017-03-13 17:38:04 --> Language Class Initialized
INFO - 2017-03-13 17:38:04 --> Loader Class Initialized
INFO - 2017-03-13 17:38:04 --> Database Driver Class Initialized
INFO - 2017-03-13 17:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:38:04 --> Controller Class Initialized
INFO - 2017-03-13 17:38:04 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:38:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:38:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:38:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:38:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:38:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:38:04 --> Final output sent to browser
DEBUG - 2017-03-13 17:38:04 --> Total execution time: 0.0137
INFO - 2017-03-13 17:38:08 --> Config Class Initialized
INFO - 2017-03-13 17:38:08 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:38:08 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:38:08 --> Utf8 Class Initialized
INFO - 2017-03-13 17:38:08 --> URI Class Initialized
DEBUG - 2017-03-13 17:38:08 --> No URI present. Default controller set.
INFO - 2017-03-13 17:38:08 --> Router Class Initialized
INFO - 2017-03-13 17:38:08 --> Output Class Initialized
INFO - 2017-03-13 17:38:08 --> Security Class Initialized
DEBUG - 2017-03-13 17:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:38:08 --> Input Class Initialized
INFO - 2017-03-13 17:38:08 --> Language Class Initialized
INFO - 2017-03-13 17:38:08 --> Loader Class Initialized
INFO - 2017-03-13 17:38:08 --> Database Driver Class Initialized
INFO - 2017-03-13 17:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:38:08 --> Controller Class Initialized
INFO - 2017-03-13 17:38:08 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:38:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:38:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:38:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:38:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:38:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:38:08 --> Final output sent to browser
DEBUG - 2017-03-13 17:38:08 --> Total execution time: 0.0138
INFO - 2017-03-13 17:38:09 --> Config Class Initialized
INFO - 2017-03-13 17:38:09 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:38:09 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:38:09 --> Utf8 Class Initialized
INFO - 2017-03-13 17:38:09 --> URI Class Initialized
INFO - 2017-03-13 17:38:09 --> Router Class Initialized
INFO - 2017-03-13 17:38:09 --> Output Class Initialized
INFO - 2017-03-13 17:38:09 --> Security Class Initialized
DEBUG - 2017-03-13 17:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:38:09 --> Input Class Initialized
INFO - 2017-03-13 17:38:09 --> Language Class Initialized
INFO - 2017-03-13 17:38:09 --> Loader Class Initialized
INFO - 2017-03-13 17:38:09 --> Database Driver Class Initialized
INFO - 2017-03-13 17:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:38:09 --> Controller Class Initialized
INFO - 2017-03-13 17:38:09 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:38:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:38:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:38:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:38:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:38:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:38:09 --> Final output sent to browser
DEBUG - 2017-03-13 17:38:09 --> Total execution time: 0.0146
INFO - 2017-03-13 17:38:26 --> Config Class Initialized
INFO - 2017-03-13 17:38:26 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:38:26 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:38:26 --> Utf8 Class Initialized
INFO - 2017-03-13 17:38:26 --> URI Class Initialized
INFO - 2017-03-13 17:38:26 --> Router Class Initialized
INFO - 2017-03-13 17:38:26 --> Output Class Initialized
INFO - 2017-03-13 17:38:26 --> Security Class Initialized
DEBUG - 2017-03-13 17:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:38:26 --> Input Class Initialized
INFO - 2017-03-13 17:38:26 --> Language Class Initialized
INFO - 2017-03-13 17:38:26 --> Loader Class Initialized
INFO - 2017-03-13 17:38:26 --> Database Driver Class Initialized
INFO - 2017-03-13 17:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:38:26 --> Controller Class Initialized
INFO - 2017-03-13 17:38:26 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:38:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:38:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:38:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:38:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:38:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:38:26 --> Final output sent to browser
DEBUG - 2017-03-13 17:38:26 --> Total execution time: 0.0152
INFO - 2017-03-13 17:38:51 --> Config Class Initialized
INFO - 2017-03-13 17:38:51 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:38:51 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:38:51 --> Utf8 Class Initialized
INFO - 2017-03-13 17:38:51 --> URI Class Initialized
INFO - 2017-03-13 17:38:51 --> Router Class Initialized
INFO - 2017-03-13 17:38:51 --> Output Class Initialized
INFO - 2017-03-13 17:38:51 --> Security Class Initialized
DEBUG - 2017-03-13 17:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:38:51 --> Input Class Initialized
INFO - 2017-03-13 17:38:51 --> Language Class Initialized
INFO - 2017-03-13 17:38:51 --> Loader Class Initialized
INFO - 2017-03-13 17:38:51 --> Database Driver Class Initialized
INFO - 2017-03-13 17:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:38:51 --> Controller Class Initialized
INFO - 2017-03-13 17:38:51 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:38:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:38:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:38:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:38:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:38:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:38:51 --> Final output sent to browser
DEBUG - 2017-03-13 17:38:51 --> Total execution time: 0.0150
INFO - 2017-03-13 17:38:56 --> Config Class Initialized
INFO - 2017-03-13 17:38:56 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:38:56 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:38:56 --> Utf8 Class Initialized
INFO - 2017-03-13 17:38:56 --> URI Class Initialized
INFO - 2017-03-13 17:38:56 --> Router Class Initialized
INFO - 2017-03-13 17:38:56 --> Output Class Initialized
INFO - 2017-03-13 17:38:56 --> Security Class Initialized
DEBUG - 2017-03-13 17:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:38:56 --> Input Class Initialized
INFO - 2017-03-13 17:38:56 --> Language Class Initialized
INFO - 2017-03-13 17:38:56 --> Loader Class Initialized
INFO - 2017-03-13 17:38:56 --> Database Driver Class Initialized
INFO - 2017-03-13 17:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:38:56 --> Controller Class Initialized
INFO - 2017-03-13 17:38:56 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:38:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:38:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:38:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:38:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:38:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:38:56 --> Final output sent to browser
DEBUG - 2017-03-13 17:38:56 --> Total execution time: 0.0154
INFO - 2017-03-13 17:38:58 --> Config Class Initialized
INFO - 2017-03-13 17:38:58 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:38:58 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:38:58 --> Utf8 Class Initialized
INFO - 2017-03-13 17:38:58 --> URI Class Initialized
INFO - 2017-03-13 17:38:58 --> Router Class Initialized
INFO - 2017-03-13 17:38:58 --> Output Class Initialized
INFO - 2017-03-13 17:38:58 --> Security Class Initialized
DEBUG - 2017-03-13 17:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:38:58 --> Input Class Initialized
INFO - 2017-03-13 17:38:58 --> Language Class Initialized
INFO - 2017-03-13 17:38:58 --> Loader Class Initialized
INFO - 2017-03-13 17:38:58 --> Database Driver Class Initialized
INFO - 2017-03-13 17:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:38:58 --> Controller Class Initialized
INFO - 2017-03-13 17:38:58 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:38:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:38:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:38:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:38:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:38:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:38:58 --> Final output sent to browser
DEBUG - 2017-03-13 17:38:58 --> Total execution time: 0.0138
INFO - 2017-03-13 17:39:19 --> Config Class Initialized
INFO - 2017-03-13 17:39:19 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:39:19 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:39:19 --> Utf8 Class Initialized
INFO - 2017-03-13 17:39:19 --> URI Class Initialized
INFO - 2017-03-13 17:39:19 --> Router Class Initialized
INFO - 2017-03-13 17:39:19 --> Output Class Initialized
INFO - 2017-03-13 17:39:19 --> Security Class Initialized
DEBUG - 2017-03-13 17:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:39:20 --> Input Class Initialized
INFO - 2017-03-13 17:39:20 --> Language Class Initialized
INFO - 2017-03-13 17:39:20 --> Loader Class Initialized
INFO - 2017-03-13 17:39:20 --> Database Driver Class Initialized
INFO - 2017-03-13 17:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:39:20 --> Controller Class Initialized
INFO - 2017-03-13 17:39:20 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:39:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:39:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:39:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:39:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:39:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:39:20 --> Final output sent to browser
DEBUG - 2017-03-13 17:39:20 --> Total execution time: 1.5178
INFO - 2017-03-13 17:39:23 --> Config Class Initialized
INFO - 2017-03-13 17:39:23 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:39:23 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:39:23 --> Utf8 Class Initialized
INFO - 2017-03-13 17:39:23 --> URI Class Initialized
INFO - 2017-03-13 17:39:23 --> Router Class Initialized
INFO - 2017-03-13 17:39:23 --> Output Class Initialized
INFO - 2017-03-13 17:39:23 --> Security Class Initialized
DEBUG - 2017-03-13 17:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:39:23 --> Input Class Initialized
INFO - 2017-03-13 17:39:23 --> Language Class Initialized
INFO - 2017-03-13 17:39:23 --> Loader Class Initialized
INFO - 2017-03-13 17:39:23 --> Database Driver Class Initialized
INFO - 2017-03-13 17:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:39:23 --> Controller Class Initialized
INFO - 2017-03-13 17:39:23 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:39:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:39:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:39:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:39:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:39:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:39:23 --> Final output sent to browser
DEBUG - 2017-03-13 17:39:23 --> Total execution time: 0.7225
INFO - 2017-03-13 17:40:03 --> Config Class Initialized
INFO - 2017-03-13 17:40:03 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:40:03 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:40:03 --> Utf8 Class Initialized
INFO - 2017-03-13 17:40:03 --> URI Class Initialized
INFO - 2017-03-13 17:40:03 --> Router Class Initialized
INFO - 2017-03-13 17:40:03 --> Output Class Initialized
INFO - 2017-03-13 17:40:03 --> Security Class Initialized
DEBUG - 2017-03-13 17:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:40:03 --> Input Class Initialized
INFO - 2017-03-13 17:40:03 --> Language Class Initialized
INFO - 2017-03-13 17:40:03 --> Loader Class Initialized
INFO - 2017-03-13 17:40:04 --> Database Driver Class Initialized
INFO - 2017-03-13 17:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:40:04 --> Controller Class Initialized
INFO - 2017-03-13 17:40:04 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:40:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:40:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:40:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:40:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:40:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:40:04 --> Final output sent to browser
DEBUG - 2017-03-13 17:40:04 --> Total execution time: 1.5628
INFO - 2017-03-13 17:40:38 --> Config Class Initialized
INFO - 2017-03-13 17:40:38 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:40:38 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:40:38 --> Utf8 Class Initialized
INFO - 2017-03-13 17:40:38 --> URI Class Initialized
INFO - 2017-03-13 17:40:38 --> Router Class Initialized
INFO - 2017-03-13 17:40:38 --> Output Class Initialized
INFO - 2017-03-13 17:40:38 --> Security Class Initialized
DEBUG - 2017-03-13 17:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:40:38 --> Input Class Initialized
INFO - 2017-03-13 17:40:38 --> Language Class Initialized
INFO - 2017-03-13 17:40:38 --> Loader Class Initialized
INFO - 2017-03-13 17:40:38 --> Database Driver Class Initialized
INFO - 2017-03-13 17:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:40:38 --> Controller Class Initialized
INFO - 2017-03-13 17:40:38 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:40:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:40:38 --> Final output sent to browser
DEBUG - 2017-03-13 17:40:38 --> Total execution time: 0.0218
INFO - 2017-03-13 17:40:39 --> Config Class Initialized
INFO - 2017-03-13 17:40:39 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:40:39 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:40:39 --> Utf8 Class Initialized
INFO - 2017-03-13 17:40:39 --> URI Class Initialized
INFO - 2017-03-13 17:40:39 --> Router Class Initialized
INFO - 2017-03-13 17:40:39 --> Output Class Initialized
INFO - 2017-03-13 17:40:39 --> Security Class Initialized
DEBUG - 2017-03-13 17:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:40:39 --> Input Class Initialized
INFO - 2017-03-13 17:40:39 --> Language Class Initialized
INFO - 2017-03-13 17:40:39 --> Loader Class Initialized
INFO - 2017-03-13 17:40:39 --> Database Driver Class Initialized
INFO - 2017-03-13 17:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:40:39 --> Controller Class Initialized
INFO - 2017-03-13 17:40:39 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:40:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:40:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:40:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:40:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:40:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:40:39 --> Final output sent to browser
DEBUG - 2017-03-13 17:40:39 --> Total execution time: 0.0144
INFO - 2017-03-13 17:40:54 --> Config Class Initialized
INFO - 2017-03-13 17:40:54 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:40:54 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:40:54 --> Utf8 Class Initialized
INFO - 2017-03-13 17:40:54 --> URI Class Initialized
INFO - 2017-03-13 17:40:54 --> Router Class Initialized
INFO - 2017-03-13 17:40:54 --> Output Class Initialized
INFO - 2017-03-13 17:40:54 --> Security Class Initialized
DEBUG - 2017-03-13 17:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:40:54 --> Input Class Initialized
INFO - 2017-03-13 17:40:54 --> Language Class Initialized
INFO - 2017-03-13 17:40:54 --> Loader Class Initialized
INFO - 2017-03-13 17:40:54 --> Database Driver Class Initialized
INFO - 2017-03-13 17:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:40:54 --> Controller Class Initialized
INFO - 2017-03-13 17:40:54 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:40:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:40:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:40:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:40:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:40:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:40:54 --> Final output sent to browser
DEBUG - 2017-03-13 17:40:54 --> Total execution time: 0.0146
INFO - 2017-03-13 17:40:55 --> Config Class Initialized
INFO - 2017-03-13 17:40:55 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:40:55 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:40:55 --> Utf8 Class Initialized
INFO - 2017-03-13 17:40:55 --> URI Class Initialized
INFO - 2017-03-13 17:40:55 --> Router Class Initialized
INFO - 2017-03-13 17:40:55 --> Output Class Initialized
INFO - 2017-03-13 17:40:55 --> Security Class Initialized
DEBUG - 2017-03-13 17:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:40:55 --> Input Class Initialized
INFO - 2017-03-13 17:40:55 --> Language Class Initialized
INFO - 2017-03-13 17:40:55 --> Loader Class Initialized
INFO - 2017-03-13 17:40:55 --> Database Driver Class Initialized
INFO - 2017-03-13 17:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:40:55 --> Controller Class Initialized
INFO - 2017-03-13 17:40:55 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:40:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:40:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:40:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:40:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:40:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:40:55 --> Final output sent to browser
DEBUG - 2017-03-13 17:40:55 --> Total execution time: 0.0145
INFO - 2017-03-13 17:41:13 --> Config Class Initialized
INFO - 2017-03-13 17:41:13 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:41:13 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:41:13 --> Utf8 Class Initialized
INFO - 2017-03-13 17:41:13 --> URI Class Initialized
INFO - 2017-03-13 17:41:13 --> Router Class Initialized
INFO - 2017-03-13 17:41:13 --> Output Class Initialized
INFO - 2017-03-13 17:41:13 --> Security Class Initialized
DEBUG - 2017-03-13 17:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:41:13 --> Input Class Initialized
INFO - 2017-03-13 17:41:13 --> Language Class Initialized
INFO - 2017-03-13 17:41:13 --> Loader Class Initialized
INFO - 2017-03-13 17:41:13 --> Database Driver Class Initialized
INFO - 2017-03-13 17:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:41:13 --> Controller Class Initialized
INFO - 2017-03-13 17:41:13 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:41:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:41:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:41:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:41:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:41:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:41:13 --> Final output sent to browser
DEBUG - 2017-03-13 17:41:13 --> Total execution time: 0.0168
INFO - 2017-03-13 17:41:14 --> Config Class Initialized
INFO - 2017-03-13 17:41:14 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:41:14 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:41:14 --> Utf8 Class Initialized
INFO - 2017-03-13 17:41:14 --> URI Class Initialized
INFO - 2017-03-13 17:41:14 --> Router Class Initialized
INFO - 2017-03-13 17:41:14 --> Output Class Initialized
INFO - 2017-03-13 17:41:14 --> Security Class Initialized
DEBUG - 2017-03-13 17:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:41:14 --> Input Class Initialized
INFO - 2017-03-13 17:41:14 --> Language Class Initialized
INFO - 2017-03-13 17:41:14 --> Loader Class Initialized
INFO - 2017-03-13 17:41:14 --> Database Driver Class Initialized
INFO - 2017-03-13 17:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:41:14 --> Controller Class Initialized
INFO - 2017-03-13 17:41:14 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:41:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:41:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:41:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:41:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:41:14 --> Final output sent to browser
DEBUG - 2017-03-13 17:41:14 --> Total execution time: 0.0140
INFO - 2017-03-13 17:41:21 --> Config Class Initialized
INFO - 2017-03-13 17:41:21 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:41:21 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:41:21 --> Utf8 Class Initialized
INFO - 2017-03-13 17:41:21 --> URI Class Initialized
DEBUG - 2017-03-13 17:41:21 --> No URI present. Default controller set.
INFO - 2017-03-13 17:41:21 --> Router Class Initialized
INFO - 2017-03-13 17:41:21 --> Output Class Initialized
INFO - 2017-03-13 17:41:21 --> Security Class Initialized
DEBUG - 2017-03-13 17:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:41:21 --> Input Class Initialized
INFO - 2017-03-13 17:41:21 --> Language Class Initialized
INFO - 2017-03-13 17:41:21 --> Loader Class Initialized
INFO - 2017-03-13 17:41:21 --> Database Driver Class Initialized
INFO - 2017-03-13 17:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:41:21 --> Controller Class Initialized
INFO - 2017-03-13 17:41:21 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:41:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:41:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:41:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:41:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:41:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:41:21 --> Final output sent to browser
DEBUG - 2017-03-13 17:41:21 --> Total execution time: 0.0458
INFO - 2017-03-13 17:41:24 --> Config Class Initialized
INFO - 2017-03-13 17:41:24 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:41:24 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:41:24 --> Utf8 Class Initialized
INFO - 2017-03-13 17:41:24 --> URI Class Initialized
INFO - 2017-03-13 17:41:24 --> Router Class Initialized
INFO - 2017-03-13 17:41:24 --> Output Class Initialized
INFO - 2017-03-13 17:41:24 --> Security Class Initialized
DEBUG - 2017-03-13 17:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:41:24 --> Input Class Initialized
INFO - 2017-03-13 17:41:24 --> Language Class Initialized
INFO - 2017-03-13 17:41:24 --> Loader Class Initialized
INFO - 2017-03-13 17:41:24 --> Database Driver Class Initialized
INFO - 2017-03-13 17:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:41:24 --> Controller Class Initialized
INFO - 2017-03-13 17:41:24 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:41:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:41:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:41:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:41:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:41:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:41:24 --> Final output sent to browser
DEBUG - 2017-03-13 17:41:24 --> Total execution time: 0.1845
INFO - 2017-03-13 17:43:24 --> Config Class Initialized
INFO - 2017-03-13 17:43:24 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:43:24 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:43:24 --> Utf8 Class Initialized
INFO - 2017-03-13 17:43:24 --> URI Class Initialized
DEBUG - 2017-03-13 17:43:24 --> No URI present. Default controller set.
INFO - 2017-03-13 17:43:24 --> Router Class Initialized
INFO - 2017-03-13 17:43:24 --> Output Class Initialized
INFO - 2017-03-13 17:43:24 --> Security Class Initialized
DEBUG - 2017-03-13 17:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:43:25 --> Input Class Initialized
INFO - 2017-03-13 17:43:25 --> Language Class Initialized
INFO - 2017-03-13 17:43:25 --> Loader Class Initialized
INFO - 2017-03-13 17:43:25 --> Database Driver Class Initialized
INFO - 2017-03-13 17:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:43:25 --> Controller Class Initialized
INFO - 2017-03-13 17:43:25 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:43:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:43:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:43:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:43:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:43:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:43:26 --> Final output sent to browser
DEBUG - 2017-03-13 17:43:26 --> Total execution time: 1.6954
INFO - 2017-03-13 17:48:07 --> Config Class Initialized
INFO - 2017-03-13 17:48:07 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:48:07 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:48:07 --> Utf8 Class Initialized
INFO - 2017-03-13 17:48:07 --> URI Class Initialized
INFO - 2017-03-13 17:48:07 --> Router Class Initialized
INFO - 2017-03-13 17:48:07 --> Output Class Initialized
INFO - 2017-03-13 17:48:07 --> Security Class Initialized
DEBUG - 2017-03-13 17:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:48:07 --> Input Class Initialized
INFO - 2017-03-13 17:48:07 --> Language Class Initialized
INFO - 2017-03-13 17:48:07 --> Loader Class Initialized
INFO - 2017-03-13 17:48:07 --> Database Driver Class Initialized
INFO - 2017-03-13 17:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:48:08 --> Controller Class Initialized
INFO - 2017-03-13 17:48:08 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:48:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:48:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:48:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:48:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:48:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:48:08 --> Final output sent to browser
DEBUG - 2017-03-13 17:48:08 --> Total execution time: 1.2523
INFO - 2017-03-13 17:50:44 --> Config Class Initialized
INFO - 2017-03-13 17:50:44 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:50:44 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:50:44 --> Utf8 Class Initialized
INFO - 2017-03-13 17:50:44 --> URI Class Initialized
DEBUG - 2017-03-13 17:50:44 --> No URI present. Default controller set.
INFO - 2017-03-13 17:50:44 --> Router Class Initialized
INFO - 2017-03-13 17:50:44 --> Output Class Initialized
INFO - 2017-03-13 17:50:44 --> Security Class Initialized
DEBUG - 2017-03-13 17:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:50:44 --> Input Class Initialized
INFO - 2017-03-13 17:50:44 --> Language Class Initialized
INFO - 2017-03-13 17:50:44 --> Loader Class Initialized
INFO - 2017-03-13 17:50:45 --> Database Driver Class Initialized
INFO - 2017-03-13 17:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:50:45 --> Controller Class Initialized
INFO - 2017-03-13 17:50:45 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:50:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:50:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:50:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:50:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:50:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:50:46 --> Final output sent to browser
DEBUG - 2017-03-13 17:50:46 --> Total execution time: 1.9135
INFO - 2017-03-13 17:52:02 --> Config Class Initialized
INFO - 2017-03-13 17:52:02 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:52:02 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:52:02 --> Utf8 Class Initialized
INFO - 2017-03-13 17:52:02 --> URI Class Initialized
INFO - 2017-03-13 17:52:02 --> Router Class Initialized
INFO - 2017-03-13 17:52:02 --> Output Class Initialized
INFO - 2017-03-13 17:52:02 --> Security Class Initialized
DEBUG - 2017-03-13 17:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:52:02 --> Input Class Initialized
INFO - 2017-03-13 17:52:02 --> Language Class Initialized
INFO - 2017-03-13 17:52:02 --> Loader Class Initialized
INFO - 2017-03-13 17:52:03 --> Database Driver Class Initialized
INFO - 2017-03-13 17:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:52:03 --> Controller Class Initialized
INFO - 2017-03-13 17:52:03 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:52:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:52:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:52:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:52:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:52:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:52:03 --> Final output sent to browser
DEBUG - 2017-03-13 17:52:03 --> Total execution time: 1.2074
INFO - 2017-03-13 17:55:32 --> Config Class Initialized
INFO - 2017-03-13 17:55:32 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:55:32 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:55:32 --> Utf8 Class Initialized
INFO - 2017-03-13 17:55:32 --> URI Class Initialized
DEBUG - 2017-03-13 17:55:32 --> No URI present. Default controller set.
INFO - 2017-03-13 17:55:32 --> Router Class Initialized
INFO - 2017-03-13 17:55:32 --> Output Class Initialized
INFO - 2017-03-13 17:55:32 --> Security Class Initialized
DEBUG - 2017-03-13 17:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:55:32 --> Input Class Initialized
INFO - 2017-03-13 17:55:32 --> Language Class Initialized
INFO - 2017-03-13 17:55:32 --> Loader Class Initialized
INFO - 2017-03-13 17:55:33 --> Database Driver Class Initialized
INFO - 2017-03-13 17:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:55:33 --> Controller Class Initialized
INFO - 2017-03-13 17:55:33 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:55:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:55:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:55:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:55:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:55:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:55:33 --> Final output sent to browser
DEBUG - 2017-03-13 17:55:33 --> Total execution time: 1.5075
INFO - 2017-03-13 17:58:30 --> Config Class Initialized
INFO - 2017-03-13 17:58:30 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:58:30 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:58:30 --> Utf8 Class Initialized
INFO - 2017-03-13 17:58:30 --> URI Class Initialized
DEBUG - 2017-03-13 17:58:30 --> No URI present. Default controller set.
INFO - 2017-03-13 17:58:30 --> Router Class Initialized
INFO - 2017-03-13 17:58:30 --> Output Class Initialized
INFO - 2017-03-13 17:58:30 --> Security Class Initialized
DEBUG - 2017-03-13 17:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:58:30 --> Input Class Initialized
INFO - 2017-03-13 17:58:30 --> Language Class Initialized
INFO - 2017-03-13 17:58:30 --> Loader Class Initialized
INFO - 2017-03-13 17:58:30 --> Database Driver Class Initialized
INFO - 2017-03-13 17:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:58:30 --> Controller Class Initialized
INFO - 2017-03-13 17:58:30 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:58:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:58:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:58:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:58:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:58:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:58:30 --> Final output sent to browser
DEBUG - 2017-03-13 17:58:30 --> Total execution time: 0.0241
INFO - 2017-03-13 17:58:35 --> Config Class Initialized
INFO - 2017-03-13 17:58:35 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:58:35 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:58:35 --> Utf8 Class Initialized
INFO - 2017-03-13 17:58:35 --> URI Class Initialized
INFO - 2017-03-13 17:58:35 --> Router Class Initialized
INFO - 2017-03-13 17:58:35 --> Output Class Initialized
INFO - 2017-03-13 17:58:35 --> Security Class Initialized
DEBUG - 2017-03-13 17:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:58:35 --> Input Class Initialized
INFO - 2017-03-13 17:58:35 --> Language Class Initialized
INFO - 2017-03-13 17:58:35 --> Loader Class Initialized
INFO - 2017-03-13 17:58:35 --> Database Driver Class Initialized
INFO - 2017-03-13 17:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:58:35 --> Controller Class Initialized
INFO - 2017-03-13 17:58:35 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:58:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:58:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:58:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:58:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:58:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:58:35 --> Final output sent to browser
DEBUG - 2017-03-13 17:58:35 --> Total execution time: 0.0135
INFO - 2017-03-13 17:59:27 --> Config Class Initialized
INFO - 2017-03-13 17:59:27 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:59:27 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:59:27 --> Utf8 Class Initialized
INFO - 2017-03-13 17:59:27 --> URI Class Initialized
INFO - 2017-03-13 17:59:27 --> Router Class Initialized
INFO - 2017-03-13 17:59:27 --> Output Class Initialized
INFO - 2017-03-13 17:59:27 --> Security Class Initialized
DEBUG - 2017-03-13 17:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:59:27 --> Input Class Initialized
INFO - 2017-03-13 17:59:27 --> Language Class Initialized
INFO - 2017-03-13 17:59:27 --> Loader Class Initialized
INFO - 2017-03-13 17:59:27 --> Database Driver Class Initialized
INFO - 2017-03-13 17:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:59:27 --> Controller Class Initialized
INFO - 2017-03-13 17:59:27 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:59:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-13 17:59:29 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-13 17:59:29 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Victoria Hernandez Garcia')
INFO - 2017-03-13 17:59:29 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-13 17:59:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-13 17:59:30 --> Config Class Initialized
INFO - 2017-03-13 17:59:30 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:59:30 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:59:30 --> Utf8 Class Initialized
INFO - 2017-03-13 17:59:30 --> URI Class Initialized
INFO - 2017-03-13 17:59:30 --> Router Class Initialized
INFO - 2017-03-13 17:59:30 --> Output Class Initialized
INFO - 2017-03-13 17:59:30 --> Security Class Initialized
DEBUG - 2017-03-13 17:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:59:30 --> Input Class Initialized
INFO - 2017-03-13 17:59:30 --> Language Class Initialized
INFO - 2017-03-13 17:59:30 --> Loader Class Initialized
INFO - 2017-03-13 17:59:30 --> Database Driver Class Initialized
INFO - 2017-03-13 17:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:59:30 --> Controller Class Initialized
INFO - 2017-03-13 17:59:30 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:59:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:59:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:59:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:59:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:59:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:59:30 --> Final output sent to browser
DEBUG - 2017-03-13 17:59:30 --> Total execution time: 0.0149
INFO - 2017-03-13 17:59:56 --> Config Class Initialized
INFO - 2017-03-13 17:59:56 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:59:56 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:59:56 --> Utf8 Class Initialized
INFO - 2017-03-13 17:59:56 --> URI Class Initialized
INFO - 2017-03-13 17:59:56 --> Router Class Initialized
INFO - 2017-03-13 17:59:56 --> Output Class Initialized
INFO - 2017-03-13 17:59:56 --> Security Class Initialized
DEBUG - 2017-03-13 17:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:59:56 --> Input Class Initialized
INFO - 2017-03-13 17:59:56 --> Language Class Initialized
INFO - 2017-03-13 17:59:56 --> Loader Class Initialized
INFO - 2017-03-13 17:59:56 --> Database Driver Class Initialized
INFO - 2017-03-13 17:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:59:56 --> Controller Class Initialized
INFO - 2017-03-13 17:59:56 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:59:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-13 17:59:57 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-13 17:59:57 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Victoria Hernandez Garcia')
INFO - 2017-03-13 17:59:57 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-13 17:59:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-13 17:59:57 --> Config Class Initialized
INFO - 2017-03-13 17:59:57 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:59:57 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:59:57 --> Utf8 Class Initialized
INFO - 2017-03-13 17:59:57 --> URI Class Initialized
INFO - 2017-03-13 17:59:57 --> Router Class Initialized
INFO - 2017-03-13 17:59:57 --> Output Class Initialized
INFO - 2017-03-13 17:59:57 --> Security Class Initialized
DEBUG - 2017-03-13 17:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:59:57 --> Input Class Initialized
INFO - 2017-03-13 17:59:57 --> Language Class Initialized
INFO - 2017-03-13 17:59:57 --> Loader Class Initialized
INFO - 2017-03-13 17:59:57 --> Database Driver Class Initialized
INFO - 2017-03-13 17:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:59:57 --> Controller Class Initialized
INFO - 2017-03-13 17:59:57 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:59:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:59:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:59:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:59:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:59:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:59:57 --> Final output sent to browser
DEBUG - 2017-03-13 17:59:57 --> Total execution time: 0.0147
INFO - 2017-03-13 17:59:58 --> Config Class Initialized
INFO - 2017-03-13 17:59:58 --> Hooks Class Initialized
DEBUG - 2017-03-13 17:59:58 --> UTF-8 Support Enabled
INFO - 2017-03-13 17:59:58 --> Utf8 Class Initialized
INFO - 2017-03-13 17:59:58 --> URI Class Initialized
DEBUG - 2017-03-13 17:59:58 --> No URI present. Default controller set.
INFO - 2017-03-13 17:59:58 --> Router Class Initialized
INFO - 2017-03-13 17:59:58 --> Output Class Initialized
INFO - 2017-03-13 17:59:58 --> Security Class Initialized
DEBUG - 2017-03-13 17:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 17:59:58 --> Input Class Initialized
INFO - 2017-03-13 17:59:58 --> Language Class Initialized
INFO - 2017-03-13 17:59:58 --> Loader Class Initialized
INFO - 2017-03-13 17:59:58 --> Database Driver Class Initialized
INFO - 2017-03-13 17:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 17:59:58 --> Controller Class Initialized
INFO - 2017-03-13 17:59:58 --> Helper loaded: url_helper
DEBUG - 2017-03-13 17:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 17:59:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 17:59:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 17:59:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 17:59:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 17:59:58 --> Final output sent to browser
DEBUG - 2017-03-13 17:59:58 --> Total execution time: 0.0138
INFO - 2017-03-13 18:00:03 --> Config Class Initialized
INFO - 2017-03-13 18:00:03 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:00:03 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:00:03 --> Utf8 Class Initialized
INFO - 2017-03-13 18:00:03 --> URI Class Initialized
INFO - 2017-03-13 18:00:03 --> Router Class Initialized
INFO - 2017-03-13 18:00:03 --> Output Class Initialized
INFO - 2017-03-13 18:00:03 --> Security Class Initialized
DEBUG - 2017-03-13 18:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:00:03 --> Input Class Initialized
INFO - 2017-03-13 18:00:03 --> Language Class Initialized
INFO - 2017-03-13 18:00:03 --> Loader Class Initialized
INFO - 2017-03-13 18:00:03 --> Database Driver Class Initialized
INFO - 2017-03-13 18:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:00:03 --> Controller Class Initialized
INFO - 2017-03-13 18:00:03 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:00:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:00:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:00:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:00:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:00:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:00:03 --> Final output sent to browser
DEBUG - 2017-03-13 18:00:03 --> Total execution time: 0.0137
INFO - 2017-03-13 18:01:20 --> Config Class Initialized
INFO - 2017-03-13 18:01:20 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:01:21 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:01:21 --> Utf8 Class Initialized
INFO - 2017-03-13 18:01:21 --> URI Class Initialized
DEBUG - 2017-03-13 18:01:21 --> No URI present. Default controller set.
INFO - 2017-03-13 18:01:21 --> Router Class Initialized
INFO - 2017-03-13 18:01:21 --> Output Class Initialized
INFO - 2017-03-13 18:01:21 --> Security Class Initialized
DEBUG - 2017-03-13 18:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:01:21 --> Input Class Initialized
INFO - 2017-03-13 18:01:21 --> Language Class Initialized
INFO - 2017-03-13 18:01:21 --> Loader Class Initialized
INFO - 2017-03-13 18:01:21 --> Database Driver Class Initialized
INFO - 2017-03-13 18:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:01:21 --> Controller Class Initialized
INFO - 2017-03-13 18:01:21 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:01:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:01:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:01:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:01:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:01:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:01:22 --> Final output sent to browser
DEBUG - 2017-03-13 18:01:22 --> Total execution time: 1.5388
INFO - 2017-03-13 18:01:29 --> Config Class Initialized
INFO - 2017-03-13 18:01:29 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:01:29 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:01:29 --> Utf8 Class Initialized
INFO - 2017-03-13 18:01:29 --> URI Class Initialized
INFO - 2017-03-13 18:01:29 --> Router Class Initialized
INFO - 2017-03-13 18:01:29 --> Output Class Initialized
INFO - 2017-03-13 18:01:29 --> Security Class Initialized
DEBUG - 2017-03-13 18:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:01:29 --> Input Class Initialized
INFO - 2017-03-13 18:01:29 --> Language Class Initialized
INFO - 2017-03-13 18:01:29 --> Loader Class Initialized
INFO - 2017-03-13 18:01:30 --> Database Driver Class Initialized
INFO - 2017-03-13 18:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:01:30 --> Controller Class Initialized
INFO - 2017-03-13 18:01:30 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:01:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:01:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:01:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:01:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:01:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:01:30 --> Final output sent to browser
DEBUG - 2017-03-13 18:01:30 --> Total execution time: 1.3518
INFO - 2017-03-13 18:01:46 --> Config Class Initialized
INFO - 2017-03-13 18:01:46 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:01:47 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:01:47 --> Utf8 Class Initialized
INFO - 2017-03-13 18:01:47 --> URI Class Initialized
INFO - 2017-03-13 18:01:47 --> Router Class Initialized
INFO - 2017-03-13 18:01:47 --> Output Class Initialized
INFO - 2017-03-13 18:01:47 --> Security Class Initialized
DEBUG - 2017-03-13 18:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:01:47 --> Input Class Initialized
INFO - 2017-03-13 18:01:47 --> Language Class Initialized
INFO - 2017-03-13 18:01:47 --> Loader Class Initialized
INFO - 2017-03-13 18:01:47 --> Database Driver Class Initialized
INFO - 2017-03-13 18:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:01:47 --> Controller Class Initialized
INFO - 2017-03-13 18:01:47 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:01:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-13 18:01:56 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-13 18:01:56 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Victoria Hernandez Garcia')
INFO - 2017-03-13 18:01:56 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-13 18:01:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-13 18:01:58 --> Config Class Initialized
INFO - 2017-03-13 18:01:58 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:01:58 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:01:58 --> Utf8 Class Initialized
INFO - 2017-03-13 18:01:58 --> URI Class Initialized
INFO - 2017-03-13 18:01:58 --> Router Class Initialized
INFO - 2017-03-13 18:01:58 --> Output Class Initialized
INFO - 2017-03-13 18:01:58 --> Security Class Initialized
DEBUG - 2017-03-13 18:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:01:59 --> Input Class Initialized
INFO - 2017-03-13 18:01:59 --> Language Class Initialized
INFO - 2017-03-13 18:01:59 --> Loader Class Initialized
INFO - 2017-03-13 18:01:59 --> Database Driver Class Initialized
INFO - 2017-03-13 18:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:01:59 --> Controller Class Initialized
INFO - 2017-03-13 18:01:59 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:01:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:01:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:01:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:01:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:01:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:01:59 --> Final output sent to browser
DEBUG - 2017-03-13 18:01:59 --> Total execution time: 1.4510
INFO - 2017-03-13 18:02:03 --> Config Class Initialized
INFO - 2017-03-13 18:02:03 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:02:03 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:02:03 --> Utf8 Class Initialized
INFO - 2017-03-13 18:02:03 --> URI Class Initialized
INFO - 2017-03-13 18:02:03 --> Router Class Initialized
INFO - 2017-03-13 18:02:03 --> Output Class Initialized
INFO - 2017-03-13 18:02:03 --> Security Class Initialized
DEBUG - 2017-03-13 18:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:02:03 --> Input Class Initialized
INFO - 2017-03-13 18:02:03 --> Language Class Initialized
INFO - 2017-03-13 18:02:03 --> Loader Class Initialized
INFO - 2017-03-13 18:02:03 --> Database Driver Class Initialized
INFO - 2017-03-13 18:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:02:03 --> Controller Class Initialized
INFO - 2017-03-13 18:02:03 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:02:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-13 18:02:05 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-13 18:02:05 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Victoria Hernandez Garcia')
INFO - 2017-03-13 18:02:05 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-13 18:02:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-13 18:02:05 --> Config Class Initialized
INFO - 2017-03-13 18:02:05 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:02:05 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:02:05 --> Utf8 Class Initialized
INFO - 2017-03-13 18:02:05 --> URI Class Initialized
INFO - 2017-03-13 18:02:05 --> Router Class Initialized
INFO - 2017-03-13 18:02:05 --> Output Class Initialized
INFO - 2017-03-13 18:02:05 --> Security Class Initialized
DEBUG - 2017-03-13 18:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:02:05 --> Input Class Initialized
INFO - 2017-03-13 18:02:05 --> Language Class Initialized
INFO - 2017-03-13 18:02:05 --> Loader Class Initialized
INFO - 2017-03-13 18:02:05 --> Database Driver Class Initialized
INFO - 2017-03-13 18:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:02:05 --> Controller Class Initialized
INFO - 2017-03-13 18:02:05 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:02:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:02:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:02:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:02:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:02:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:02:05 --> Final output sent to browser
DEBUG - 2017-03-13 18:02:05 --> Total execution time: 0.0142
INFO - 2017-03-13 18:02:06 --> Config Class Initialized
INFO - 2017-03-13 18:02:06 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:02:06 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:02:06 --> Utf8 Class Initialized
INFO - 2017-03-13 18:02:06 --> URI Class Initialized
DEBUG - 2017-03-13 18:02:06 --> No URI present. Default controller set.
INFO - 2017-03-13 18:02:06 --> Router Class Initialized
INFO - 2017-03-13 18:02:06 --> Output Class Initialized
INFO - 2017-03-13 18:02:06 --> Security Class Initialized
DEBUG - 2017-03-13 18:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:02:06 --> Input Class Initialized
INFO - 2017-03-13 18:02:06 --> Language Class Initialized
INFO - 2017-03-13 18:02:06 --> Loader Class Initialized
INFO - 2017-03-13 18:02:06 --> Database Driver Class Initialized
INFO - 2017-03-13 18:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:02:06 --> Controller Class Initialized
INFO - 2017-03-13 18:02:06 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:02:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:02:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:02:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:02:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:02:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:02:06 --> Final output sent to browser
DEBUG - 2017-03-13 18:02:06 --> Total execution time: 0.0604
INFO - 2017-03-13 18:02:08 --> Config Class Initialized
INFO - 2017-03-13 18:02:08 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:02:08 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:02:08 --> Utf8 Class Initialized
INFO - 2017-03-13 18:02:08 --> URI Class Initialized
INFO - 2017-03-13 18:02:08 --> Router Class Initialized
INFO - 2017-03-13 18:02:08 --> Output Class Initialized
INFO - 2017-03-13 18:02:08 --> Security Class Initialized
DEBUG - 2017-03-13 18:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:02:08 --> Input Class Initialized
INFO - 2017-03-13 18:02:08 --> Language Class Initialized
INFO - 2017-03-13 18:02:08 --> Loader Class Initialized
INFO - 2017-03-13 18:02:08 --> Database Driver Class Initialized
INFO - 2017-03-13 18:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:02:08 --> Controller Class Initialized
INFO - 2017-03-13 18:02:08 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:02:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:02:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:02:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:02:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:02:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:02:08 --> Final output sent to browser
DEBUG - 2017-03-13 18:02:08 --> Total execution time: 0.0184
INFO - 2017-03-13 18:02:12 --> Config Class Initialized
INFO - 2017-03-13 18:02:12 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:02:12 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:02:12 --> Utf8 Class Initialized
INFO - 2017-03-13 18:02:12 --> URI Class Initialized
DEBUG - 2017-03-13 18:02:12 --> No URI present. Default controller set.
INFO - 2017-03-13 18:02:12 --> Router Class Initialized
INFO - 2017-03-13 18:02:12 --> Output Class Initialized
INFO - 2017-03-13 18:02:12 --> Security Class Initialized
DEBUG - 2017-03-13 18:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:02:12 --> Input Class Initialized
INFO - 2017-03-13 18:02:12 --> Language Class Initialized
INFO - 2017-03-13 18:02:12 --> Loader Class Initialized
INFO - 2017-03-13 18:02:12 --> Database Driver Class Initialized
INFO - 2017-03-13 18:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:02:12 --> Controller Class Initialized
INFO - 2017-03-13 18:02:12 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:02:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:02:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:02:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:02:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:02:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:02:12 --> Final output sent to browser
DEBUG - 2017-03-13 18:02:12 --> Total execution time: 0.0641
INFO - 2017-03-13 18:02:16 --> Config Class Initialized
INFO - 2017-03-13 18:02:16 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:02:16 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:02:16 --> Utf8 Class Initialized
INFO - 2017-03-13 18:02:16 --> URI Class Initialized
INFO - 2017-03-13 18:02:16 --> Router Class Initialized
INFO - 2017-03-13 18:02:16 --> Output Class Initialized
INFO - 2017-03-13 18:02:16 --> Security Class Initialized
DEBUG - 2017-03-13 18:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:02:16 --> Input Class Initialized
INFO - 2017-03-13 18:02:16 --> Language Class Initialized
INFO - 2017-03-13 18:02:16 --> Loader Class Initialized
INFO - 2017-03-13 18:02:16 --> Database Driver Class Initialized
INFO - 2017-03-13 18:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:02:16 --> Controller Class Initialized
INFO - 2017-03-13 18:02:16 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:02:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:02:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:02:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:02:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:02:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:02:16 --> Final output sent to browser
DEBUG - 2017-03-13 18:02:16 --> Total execution time: 0.0142
INFO - 2017-03-13 18:02:46 --> Config Class Initialized
INFO - 2017-03-13 18:02:46 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:02:46 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:02:46 --> Utf8 Class Initialized
INFO - 2017-03-13 18:02:46 --> URI Class Initialized
INFO - 2017-03-13 18:02:46 --> Router Class Initialized
INFO - 2017-03-13 18:02:46 --> Output Class Initialized
INFO - 2017-03-13 18:02:46 --> Security Class Initialized
DEBUG - 2017-03-13 18:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:02:47 --> Input Class Initialized
INFO - 2017-03-13 18:02:47 --> Language Class Initialized
INFO - 2017-03-13 18:02:47 --> Loader Class Initialized
INFO - 2017-03-13 18:02:47 --> Database Driver Class Initialized
INFO - 2017-03-13 18:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:02:47 --> Controller Class Initialized
INFO - 2017-03-13 18:02:47 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:02:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:02:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:02:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:02:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:02:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:02:47 --> Final output sent to browser
DEBUG - 2017-03-13 18:02:47 --> Total execution time: 1.2717
INFO - 2017-03-13 18:02:50 --> Config Class Initialized
INFO - 2017-03-13 18:02:50 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:02:50 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:02:50 --> Utf8 Class Initialized
INFO - 2017-03-13 18:02:50 --> URI Class Initialized
INFO - 2017-03-13 18:02:50 --> Router Class Initialized
INFO - 2017-03-13 18:02:50 --> Output Class Initialized
INFO - 2017-03-13 18:02:50 --> Security Class Initialized
DEBUG - 2017-03-13 18:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:02:50 --> Input Class Initialized
INFO - 2017-03-13 18:02:50 --> Language Class Initialized
INFO - 2017-03-13 18:02:50 --> Loader Class Initialized
INFO - 2017-03-13 18:02:50 --> Database Driver Class Initialized
INFO - 2017-03-13 18:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:02:50 --> Controller Class Initialized
INFO - 2017-03-13 18:02:50 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:02:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:02:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:02:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:02:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:02:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:02:50 --> Final output sent to browser
DEBUG - 2017-03-13 18:02:50 --> Total execution time: 0.0198
INFO - 2017-03-13 18:03:06 --> Config Class Initialized
INFO - 2017-03-13 18:03:06 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:03:06 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:03:06 --> Utf8 Class Initialized
INFO - 2017-03-13 18:03:06 --> URI Class Initialized
INFO - 2017-03-13 18:03:06 --> Router Class Initialized
INFO - 2017-03-13 18:03:06 --> Output Class Initialized
INFO - 2017-03-13 18:03:06 --> Security Class Initialized
DEBUG - 2017-03-13 18:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:03:06 --> Input Class Initialized
INFO - 2017-03-13 18:03:06 --> Language Class Initialized
INFO - 2017-03-13 18:03:06 --> Loader Class Initialized
INFO - 2017-03-13 18:03:07 --> Database Driver Class Initialized
INFO - 2017-03-13 18:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:03:07 --> Controller Class Initialized
INFO - 2017-03-13 18:03:07 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:03:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-13 18:03:12 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-13 18:03:13 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Victoria Hernandez Garcia')
INFO - 2017-03-13 18:03:13 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-13 18:03:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-13 18:03:15 --> Config Class Initialized
INFO - 2017-03-13 18:03:15 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:03:16 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:03:16 --> Utf8 Class Initialized
INFO - 2017-03-13 18:03:16 --> URI Class Initialized
INFO - 2017-03-13 18:03:16 --> Router Class Initialized
INFO - 2017-03-13 18:03:16 --> Output Class Initialized
INFO - 2017-03-13 18:03:16 --> Security Class Initialized
DEBUG - 2017-03-13 18:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:03:16 --> Input Class Initialized
INFO - 2017-03-13 18:03:16 --> Language Class Initialized
INFO - 2017-03-13 18:03:16 --> Loader Class Initialized
INFO - 2017-03-13 18:03:16 --> Database Driver Class Initialized
INFO - 2017-03-13 18:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:03:16 --> Controller Class Initialized
INFO - 2017-03-13 18:03:16 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:03:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-13 18:03:18 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-13 18:03:18 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Victoria Hernandez Garcia')
INFO - 2017-03-13 18:03:18 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-13 18:03:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-13 18:03:19 --> Config Class Initialized
INFO - 2017-03-13 18:03:19 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:03:19 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:03:19 --> Utf8 Class Initialized
INFO - 2017-03-13 18:03:19 --> URI Class Initialized
INFO - 2017-03-13 18:03:19 --> Router Class Initialized
INFO - 2017-03-13 18:03:19 --> Output Class Initialized
INFO - 2017-03-13 18:03:19 --> Security Class Initialized
DEBUG - 2017-03-13 18:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:03:19 --> Input Class Initialized
INFO - 2017-03-13 18:03:19 --> Language Class Initialized
INFO - 2017-03-13 18:03:19 --> Loader Class Initialized
INFO - 2017-03-13 18:03:19 --> Database Driver Class Initialized
INFO - 2017-03-13 18:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:03:19 --> Controller Class Initialized
INFO - 2017-03-13 18:03:19 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:03:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:03:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:03:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:03:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:03:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:03:19 --> Final output sent to browser
DEBUG - 2017-03-13 18:03:19 --> Total execution time: 0.1625
INFO - 2017-03-13 18:03:32 --> Config Class Initialized
INFO - 2017-03-13 18:03:32 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:03:32 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:03:32 --> Utf8 Class Initialized
INFO - 2017-03-13 18:03:32 --> URI Class Initialized
DEBUG - 2017-03-13 18:03:32 --> No URI present. Default controller set.
INFO - 2017-03-13 18:03:32 --> Router Class Initialized
INFO - 2017-03-13 18:03:32 --> Output Class Initialized
INFO - 2017-03-13 18:03:32 --> Security Class Initialized
DEBUG - 2017-03-13 18:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:03:32 --> Input Class Initialized
INFO - 2017-03-13 18:03:32 --> Language Class Initialized
INFO - 2017-03-13 18:03:32 --> Loader Class Initialized
INFO - 2017-03-13 18:03:32 --> Database Driver Class Initialized
INFO - 2017-03-13 18:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:03:33 --> Controller Class Initialized
INFO - 2017-03-13 18:03:33 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:03:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:03:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:03:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:03:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:03:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:03:33 --> Final output sent to browser
DEBUG - 2017-03-13 18:03:33 --> Total execution time: 1.8836
INFO - 2017-03-13 18:03:42 --> Config Class Initialized
INFO - 2017-03-13 18:03:42 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:03:42 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:03:42 --> Utf8 Class Initialized
INFO - 2017-03-13 18:03:42 --> URI Class Initialized
INFO - 2017-03-13 18:03:42 --> Router Class Initialized
INFO - 2017-03-13 18:03:42 --> Output Class Initialized
INFO - 2017-03-13 18:03:42 --> Security Class Initialized
DEBUG - 2017-03-13 18:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:03:42 --> Input Class Initialized
INFO - 2017-03-13 18:03:42 --> Language Class Initialized
INFO - 2017-03-13 18:03:42 --> Loader Class Initialized
INFO - 2017-03-13 18:03:43 --> Database Driver Class Initialized
INFO - 2017-03-13 18:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:03:43 --> Controller Class Initialized
INFO - 2017-03-13 18:03:43 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:03:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:03:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:03:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:03:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:03:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:03:43 --> Final output sent to browser
DEBUG - 2017-03-13 18:03:43 --> Total execution time: 1.5179
INFO - 2017-03-13 18:05:14 --> Config Class Initialized
INFO - 2017-03-13 18:05:14 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:05:15 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:05:15 --> Utf8 Class Initialized
INFO - 2017-03-13 18:05:15 --> URI Class Initialized
INFO - 2017-03-13 18:05:15 --> Router Class Initialized
INFO - 2017-03-13 18:05:15 --> Output Class Initialized
INFO - 2017-03-13 18:05:15 --> Security Class Initialized
DEBUG - 2017-03-13 18:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:05:15 --> Input Class Initialized
INFO - 2017-03-13 18:05:15 --> Language Class Initialized
INFO - 2017-03-13 18:05:15 --> Loader Class Initialized
INFO - 2017-03-13 18:05:15 --> Database Driver Class Initialized
INFO - 2017-03-13 18:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:05:15 --> Controller Class Initialized
INFO - 2017-03-13 18:05:15 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:05:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-13 18:05:26 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-13 18:05:27 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Victoria Hernandez Garcia')
INFO - 2017-03-13 18:05:27 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-13 18:05:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-13 18:05:34 --> Config Class Initialized
INFO - 2017-03-13 18:05:34 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:05:35 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:05:35 --> Utf8 Class Initialized
INFO - 2017-03-13 18:05:35 --> URI Class Initialized
INFO - 2017-03-13 18:05:35 --> Router Class Initialized
INFO - 2017-03-13 18:05:35 --> Output Class Initialized
INFO - 2017-03-13 18:05:35 --> Security Class Initialized
DEBUG - 2017-03-13 18:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:05:35 --> Input Class Initialized
INFO - 2017-03-13 18:05:35 --> Language Class Initialized
INFO - 2017-03-13 18:05:35 --> Loader Class Initialized
INFO - 2017-03-13 18:05:36 --> Database Driver Class Initialized
INFO - 2017-03-13 18:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:05:36 --> Controller Class Initialized
INFO - 2017-03-13 18:05:36 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:05:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:05:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:05:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:05:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:05:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:05:37 --> Final output sent to browser
DEBUG - 2017-03-13 18:05:37 --> Total execution time: 1.9361
INFO - 2017-03-13 18:06:30 --> Config Class Initialized
INFO - 2017-03-13 18:06:30 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:06:30 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:06:30 --> Utf8 Class Initialized
INFO - 2017-03-13 18:06:30 --> URI Class Initialized
DEBUG - 2017-03-13 18:06:30 --> No URI present. Default controller set.
INFO - 2017-03-13 18:06:30 --> Router Class Initialized
INFO - 2017-03-13 18:06:30 --> Output Class Initialized
INFO - 2017-03-13 18:06:30 --> Security Class Initialized
DEBUG - 2017-03-13 18:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:06:30 --> Input Class Initialized
INFO - 2017-03-13 18:06:30 --> Language Class Initialized
INFO - 2017-03-13 18:06:30 --> Loader Class Initialized
INFO - 2017-03-13 18:06:30 --> Database Driver Class Initialized
INFO - 2017-03-13 18:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:06:31 --> Controller Class Initialized
INFO - 2017-03-13 18:06:31 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:06:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:06:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:06:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:06:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:06:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:06:31 --> Final output sent to browser
DEBUG - 2017-03-13 18:06:31 --> Total execution time: 1.5978
INFO - 2017-03-13 18:06:35 --> Config Class Initialized
INFO - 2017-03-13 18:06:35 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:06:35 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:06:35 --> Utf8 Class Initialized
INFO - 2017-03-13 18:06:35 --> URI Class Initialized
INFO - 2017-03-13 18:06:35 --> Router Class Initialized
INFO - 2017-03-13 18:06:35 --> Output Class Initialized
INFO - 2017-03-13 18:06:35 --> Security Class Initialized
DEBUG - 2017-03-13 18:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:06:35 --> Input Class Initialized
INFO - 2017-03-13 18:06:35 --> Language Class Initialized
INFO - 2017-03-13 18:06:35 --> Loader Class Initialized
INFO - 2017-03-13 18:06:36 --> Database Driver Class Initialized
INFO - 2017-03-13 18:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:06:36 --> Controller Class Initialized
INFO - 2017-03-13 18:06:36 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:06:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:06:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:06:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:06:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:06:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:06:37 --> Final output sent to browser
DEBUG - 2017-03-13 18:06:37 --> Total execution time: 1.6678
INFO - 2017-03-13 18:07:14 --> Config Class Initialized
INFO - 2017-03-13 18:07:14 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:07:14 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:07:14 --> Utf8 Class Initialized
INFO - 2017-03-13 18:07:14 --> URI Class Initialized
INFO - 2017-03-13 18:07:14 --> Router Class Initialized
INFO - 2017-03-13 18:07:14 --> Output Class Initialized
INFO - 2017-03-13 18:07:14 --> Security Class Initialized
DEBUG - 2017-03-13 18:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:07:14 --> Input Class Initialized
INFO - 2017-03-13 18:07:14 --> Language Class Initialized
INFO - 2017-03-13 18:07:14 --> Loader Class Initialized
INFO - 2017-03-13 18:07:15 --> Database Driver Class Initialized
INFO - 2017-03-13 18:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:07:15 --> Controller Class Initialized
INFO - 2017-03-13 18:07:15 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:07:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-13 18:07:17 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-13 18:07:17 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Victoria Hernandez Garcia')
INFO - 2017-03-13 18:07:17 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-13 18:07:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-13 18:07:18 --> Config Class Initialized
INFO - 2017-03-13 18:07:18 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:07:18 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:07:18 --> Utf8 Class Initialized
INFO - 2017-03-13 18:07:18 --> URI Class Initialized
INFO - 2017-03-13 18:07:18 --> Router Class Initialized
INFO - 2017-03-13 18:07:18 --> Output Class Initialized
INFO - 2017-03-13 18:07:18 --> Security Class Initialized
DEBUG - 2017-03-13 18:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:07:18 --> Input Class Initialized
INFO - 2017-03-13 18:07:18 --> Language Class Initialized
INFO - 2017-03-13 18:07:18 --> Loader Class Initialized
INFO - 2017-03-13 18:07:18 --> Database Driver Class Initialized
INFO - 2017-03-13 18:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:07:18 --> Controller Class Initialized
INFO - 2017-03-13 18:07:18 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:07:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:07:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:07:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:07:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:07:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:07:19 --> Final output sent to browser
DEBUG - 2017-03-13 18:07:19 --> Total execution time: 1.0324
INFO - 2017-03-13 18:07:20 --> Config Class Initialized
INFO - 2017-03-13 18:07:20 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:07:20 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:07:20 --> Utf8 Class Initialized
INFO - 2017-03-13 18:07:20 --> URI Class Initialized
INFO - 2017-03-13 18:07:20 --> Router Class Initialized
INFO - 2017-03-13 18:07:20 --> Output Class Initialized
INFO - 2017-03-13 18:07:20 --> Security Class Initialized
DEBUG - 2017-03-13 18:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:07:20 --> Input Class Initialized
INFO - 2017-03-13 18:07:20 --> Language Class Initialized
INFO - 2017-03-13 18:07:20 --> Loader Class Initialized
INFO - 2017-03-13 18:07:20 --> Database Driver Class Initialized
INFO - 2017-03-13 18:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:07:20 --> Controller Class Initialized
INFO - 2017-03-13 18:07:20 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:07:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-13 18:07:21 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-13 18:07:21 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Victoria Hernandez Garcia')
INFO - 2017-03-13 18:07:21 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-13 18:07:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-13 18:07:21 --> Config Class Initialized
INFO - 2017-03-13 18:07:21 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:07:21 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:07:21 --> Utf8 Class Initialized
INFO - 2017-03-13 18:07:21 --> URI Class Initialized
INFO - 2017-03-13 18:07:21 --> Router Class Initialized
INFO - 2017-03-13 18:07:21 --> Output Class Initialized
INFO - 2017-03-13 18:07:21 --> Security Class Initialized
DEBUG - 2017-03-13 18:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:07:21 --> Input Class Initialized
INFO - 2017-03-13 18:07:21 --> Language Class Initialized
INFO - 2017-03-13 18:07:21 --> Loader Class Initialized
INFO - 2017-03-13 18:07:21 --> Database Driver Class Initialized
INFO - 2017-03-13 18:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:07:21 --> Controller Class Initialized
INFO - 2017-03-13 18:07:21 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:07:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:07:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:07:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:07:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:07:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:07:21 --> Final output sent to browser
DEBUG - 2017-03-13 18:07:21 --> Total execution time: 0.0160
INFO - 2017-03-13 18:07:39 --> Config Class Initialized
INFO - 2017-03-13 18:07:39 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:07:39 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:07:39 --> Utf8 Class Initialized
INFO - 2017-03-13 18:07:39 --> URI Class Initialized
DEBUG - 2017-03-13 18:07:39 --> No URI present. Default controller set.
INFO - 2017-03-13 18:07:39 --> Router Class Initialized
INFO - 2017-03-13 18:07:39 --> Output Class Initialized
INFO - 2017-03-13 18:07:39 --> Security Class Initialized
DEBUG - 2017-03-13 18:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:07:39 --> Input Class Initialized
INFO - 2017-03-13 18:07:39 --> Language Class Initialized
INFO - 2017-03-13 18:07:39 --> Loader Class Initialized
INFO - 2017-03-13 18:07:39 --> Database Driver Class Initialized
INFO - 2017-03-13 18:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:07:40 --> Controller Class Initialized
INFO - 2017-03-13 18:07:40 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:07:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:07:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:07:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:07:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:07:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:07:40 --> Final output sent to browser
DEBUG - 2017-03-13 18:07:40 --> Total execution time: 1.5337
INFO - 2017-03-13 18:07:47 --> Config Class Initialized
INFO - 2017-03-13 18:07:47 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:07:47 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:07:47 --> Utf8 Class Initialized
INFO - 2017-03-13 18:07:47 --> URI Class Initialized
INFO - 2017-03-13 18:07:47 --> Router Class Initialized
INFO - 2017-03-13 18:07:47 --> Output Class Initialized
INFO - 2017-03-13 18:07:47 --> Security Class Initialized
DEBUG - 2017-03-13 18:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:07:47 --> Input Class Initialized
INFO - 2017-03-13 18:07:47 --> Language Class Initialized
INFO - 2017-03-13 18:07:47 --> Loader Class Initialized
INFO - 2017-03-13 18:07:48 --> Database Driver Class Initialized
INFO - 2017-03-13 18:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:07:48 --> Controller Class Initialized
INFO - 2017-03-13 18:07:48 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:07:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:07:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:07:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:07:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:07:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:07:49 --> Final output sent to browser
DEBUG - 2017-03-13 18:07:49 --> Total execution time: 2.1292
INFO - 2017-03-13 18:07:58 --> Config Class Initialized
INFO - 2017-03-13 18:07:58 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:07:58 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:07:58 --> Utf8 Class Initialized
INFO - 2017-03-13 18:07:58 --> URI Class Initialized
DEBUG - 2017-03-13 18:07:59 --> No URI present. Default controller set.
INFO - 2017-03-13 18:07:59 --> Router Class Initialized
INFO - 2017-03-13 18:07:59 --> Output Class Initialized
INFO - 2017-03-13 18:07:59 --> Security Class Initialized
DEBUG - 2017-03-13 18:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:07:59 --> Input Class Initialized
INFO - 2017-03-13 18:07:59 --> Language Class Initialized
INFO - 2017-03-13 18:07:59 --> Loader Class Initialized
INFO - 2017-03-13 18:07:59 --> Database Driver Class Initialized
INFO - 2017-03-13 18:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:08:00 --> Controller Class Initialized
INFO - 2017-03-13 18:08:00 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:08:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:08:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:08:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:08:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:08:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:08:00 --> Final output sent to browser
DEBUG - 2017-03-13 18:08:00 --> Total execution time: 1.9875
INFO - 2017-03-13 18:09:00 --> Config Class Initialized
INFO - 2017-03-13 18:09:00 --> Config Class Initialized
INFO - 2017-03-13 18:09:00 --> Hooks Class Initialized
INFO - 2017-03-13 18:09:00 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:09:00 --> UTF-8 Support Enabled
DEBUG - 2017-03-13 18:09:00 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:09:00 --> Utf8 Class Initialized
INFO - 2017-03-13 18:09:00 --> Utf8 Class Initialized
INFO - 2017-03-13 18:09:00 --> URI Class Initialized
INFO - 2017-03-13 18:09:00 --> URI Class Initialized
INFO - 2017-03-13 18:09:00 --> Router Class Initialized
INFO - 2017-03-13 18:09:00 --> Router Class Initialized
INFO - 2017-03-13 18:09:00 --> Output Class Initialized
INFO - 2017-03-13 18:09:00 --> Output Class Initialized
INFO - 2017-03-13 18:09:00 --> Security Class Initialized
DEBUG - 2017-03-13 18:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:09:00 --> Input Class Initialized
INFO - 2017-03-13 18:09:01 --> Security Class Initialized
INFO - 2017-03-13 18:09:01 --> Language Class Initialized
DEBUG - 2017-03-13 18:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:09:01 --> Input Class Initialized
INFO - 2017-03-13 18:09:01 --> Language Class Initialized
INFO - 2017-03-13 18:09:01 --> Loader Class Initialized
INFO - 2017-03-13 18:09:01 --> Loader Class Initialized
INFO - 2017-03-13 18:09:01 --> Database Driver Class Initialized
INFO - 2017-03-13 18:09:01 --> Database Driver Class Initialized
INFO - 2017-03-13 18:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:09:01 --> Controller Class Initialized
INFO - 2017-03-13 18:09:01 --> Helper loaded: url_helper
INFO - 2017-03-13 18:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:09:02 --> Controller Class Initialized
DEBUG - 2017-03-13 18:09:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:09:02 --> Helper loaded: date_helper
DEBUG - 2017-03-13 18:09:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:09:02 --> Helper loaded: url_helper
INFO - 2017-03-13 18:09:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:09:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 18:09:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 18:09:02 --> Config Class Initialized
INFO - 2017-03-13 18:09:02 --> Hooks Class Initialized
INFO - 2017-03-13 18:09:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 18:09:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:09:02 --> Final output sent to browser
DEBUG - 2017-03-13 18:09:02 --> Total execution time: 2.4950
DEBUG - 2017-03-13 18:09:02 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:09:02 --> Utf8 Class Initialized
INFO - 2017-03-13 18:09:02 --> URI Class Initialized
INFO - 2017-03-13 18:09:03 --> Router Class Initialized
INFO - 2017-03-13 18:09:03 --> Output Class Initialized
INFO - 2017-03-13 18:09:03 --> Security Class Initialized
DEBUG - 2017-03-13 18:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:09:03 --> Input Class Initialized
INFO - 2017-03-13 18:09:03 --> Language Class Initialized
INFO - 2017-03-13 18:09:03 --> Loader Class Initialized
INFO - 2017-03-13 18:09:03 --> Database Driver Class Initialized
INFO - 2017-03-13 18:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:09:04 --> Controller Class Initialized
INFO - 2017-03-13 18:09:04 --> Helper loaded: date_helper
DEBUG - 2017-03-13 18:09:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:09:04 --> Helper loaded: url_helper
INFO - 2017-03-13 18:09:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:09:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 18:09:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 18:09:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 18:09:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:09:05 --> Final output sent to browser
DEBUG - 2017-03-13 18:09:05 --> Total execution time: 4.8648
INFO - 2017-03-13 18:09:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-13 18:09:20 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-13 18:09:20 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-13 18:09:20 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-13 18:09:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:09:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:09:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:09:20 --> Final output sent to browser
DEBUG - 2017-03-13 18:09:20 --> Total execution time: 19.9552
INFO - 2017-03-13 18:09:44 --> Config Class Initialized
INFO - 2017-03-13 18:09:44 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:09:44 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:09:44 --> Utf8 Class Initialized
INFO - 2017-03-13 18:09:44 --> URI Class Initialized
INFO - 2017-03-13 18:09:44 --> Router Class Initialized
INFO - 2017-03-13 18:09:44 --> Output Class Initialized
INFO - 2017-03-13 18:09:44 --> Security Class Initialized
DEBUG - 2017-03-13 18:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:09:44 --> Input Class Initialized
INFO - 2017-03-13 18:09:44 --> Language Class Initialized
INFO - 2017-03-13 18:09:44 --> Loader Class Initialized
INFO - 2017-03-13 18:09:45 --> Database Driver Class Initialized
INFO - 2017-03-13 18:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:09:45 --> Controller Class Initialized
INFO - 2017-03-13 18:09:45 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:09:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:09:59 --> Config Class Initialized
INFO - 2017-03-13 18:09:59 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:10:00 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:10:00 --> Utf8 Class Initialized
INFO - 2017-03-13 18:10:00 --> URI Class Initialized
INFO - 2017-03-13 18:10:00 --> Router Class Initialized
INFO - 2017-03-13 18:10:00 --> Output Class Initialized
INFO - 2017-03-13 18:10:00 --> Security Class Initialized
DEBUG - 2017-03-13 18:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:10:00 --> Input Class Initialized
INFO - 2017-03-13 18:10:00 --> Language Class Initialized
INFO - 2017-03-13 18:10:00 --> Loader Class Initialized
INFO - 2017-03-13 18:10:00 --> Database Driver Class Initialized
INFO - 2017-03-13 18:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:10:01 --> Controller Class Initialized
INFO - 2017-03-13 18:10:01 --> Helper loaded: date_helper
DEBUG - 2017-03-13 18:10:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:10:01 --> Helper loaded: url_helper
INFO - 2017-03-13 18:10:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:10:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 18:10:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 18:10:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 18:10:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:10:01 --> Final output sent to browser
DEBUG - 2017-03-13 18:10:01 --> Total execution time: 1.8459
INFO - 2017-03-13 18:11:42 --> Config Class Initialized
INFO - 2017-03-13 18:11:42 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:11:42 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:11:42 --> Utf8 Class Initialized
INFO - 2017-03-13 18:11:42 --> URI Class Initialized
DEBUG - 2017-03-13 18:11:43 --> No URI present. Default controller set.
INFO - 2017-03-13 18:11:43 --> Router Class Initialized
INFO - 2017-03-13 18:11:43 --> Output Class Initialized
INFO - 2017-03-13 18:11:43 --> Security Class Initialized
DEBUG - 2017-03-13 18:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:11:43 --> Input Class Initialized
INFO - 2017-03-13 18:11:43 --> Language Class Initialized
INFO - 2017-03-13 18:11:43 --> Loader Class Initialized
INFO - 2017-03-13 18:11:43 --> Database Driver Class Initialized
INFO - 2017-03-13 18:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:11:44 --> Controller Class Initialized
INFO - 2017-03-13 18:11:44 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:11:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:11:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:11:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:11:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:11:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:11:45 --> Final output sent to browser
DEBUG - 2017-03-13 18:11:45 --> Total execution time: 2.6175
INFO - 2017-03-13 18:13:03 --> Config Class Initialized
INFO - 2017-03-13 18:13:03 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:13:03 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:13:03 --> Utf8 Class Initialized
INFO - 2017-03-13 18:13:03 --> URI Class Initialized
INFO - 2017-03-13 18:13:03 --> Router Class Initialized
INFO - 2017-03-13 18:13:03 --> Output Class Initialized
INFO - 2017-03-13 18:13:03 --> Security Class Initialized
DEBUG - 2017-03-13 18:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:13:03 --> Input Class Initialized
INFO - 2017-03-13 18:13:03 --> Language Class Initialized
INFO - 2017-03-13 18:13:03 --> Loader Class Initialized
INFO - 2017-03-13 18:13:03 --> Database Driver Class Initialized
INFO - 2017-03-13 18:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:13:04 --> Controller Class Initialized
INFO - 2017-03-13 18:13:04 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:13:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-13 18:13:12 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-13 18:13:12 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Victoria Hernandez Garcia')
INFO - 2017-03-13 18:13:12 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-13 18:13:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-13 18:13:45 --> Config Class Initialized
INFO - 2017-03-13 18:13:45 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:13:45 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:13:45 --> Utf8 Class Initialized
INFO - 2017-03-13 18:13:45 --> URI Class Initialized
INFO - 2017-03-13 18:13:45 --> Router Class Initialized
INFO - 2017-03-13 18:13:45 --> Output Class Initialized
INFO - 2017-03-13 18:13:45 --> Security Class Initialized
DEBUG - 2017-03-13 18:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:13:45 --> Input Class Initialized
INFO - 2017-03-13 18:13:45 --> Language Class Initialized
INFO - 2017-03-13 18:13:45 --> Loader Class Initialized
INFO - 2017-03-13 18:13:46 --> Database Driver Class Initialized
INFO - 2017-03-13 18:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:13:46 --> Controller Class Initialized
INFO - 2017-03-13 18:13:46 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:13:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:14:10 --> Config Class Initialized
INFO - 2017-03-13 18:14:10 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:14:11 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:14:11 --> Utf8 Class Initialized
INFO - 2017-03-13 18:14:11 --> URI Class Initialized
DEBUG - 2017-03-13 18:14:11 --> No URI present. Default controller set.
INFO - 2017-03-13 18:14:11 --> Router Class Initialized
INFO - 2017-03-13 18:14:12 --> Output Class Initialized
INFO - 2017-03-13 18:14:12 --> Security Class Initialized
DEBUG - 2017-03-13 18:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:14:12 --> Input Class Initialized
INFO - 2017-03-13 18:14:12 --> Language Class Initialized
INFO - 2017-03-13 18:14:12 --> Loader Class Initialized
INFO - 2017-03-13 18:14:12 --> Database Driver Class Initialized
ERROR - 2017-03-13 18:14:13 --> Severity: error --> Exception: timed out before SSL handshake /home/graduafe/public_html/application/libraries/facebook-api-php-codexworld/base_facebook.php 972
INFO - 2017-03-13 18:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:14:13 --> Controller Class Initialized
INFO - 2017-03-13 18:14:13 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:14:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:14:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:14:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:14:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:14:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:14:14 --> Final output sent to browser
DEBUG - 2017-03-13 18:14:14 --> Total execution time: 5.7870
INFO - 2017-03-13 18:16:49 --> Config Class Initialized
INFO - 2017-03-13 18:16:49 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:16:49 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:16:49 --> Utf8 Class Initialized
INFO - 2017-03-13 18:16:49 --> URI Class Initialized
INFO - 2017-03-13 18:16:49 --> Router Class Initialized
INFO - 2017-03-13 18:16:49 --> Output Class Initialized
INFO - 2017-03-13 18:16:49 --> Security Class Initialized
DEBUG - 2017-03-13 18:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:16:49 --> Input Class Initialized
INFO - 2017-03-13 18:16:49 --> Language Class Initialized
INFO - 2017-03-13 18:16:49 --> Loader Class Initialized
INFO - 2017-03-13 18:16:49 --> Database Driver Class Initialized
INFO - 2017-03-13 18:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:16:50 --> Controller Class Initialized
INFO - 2017-03-13 18:16:50 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:16:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:17:01 --> Config Class Initialized
INFO - 2017-03-13 18:17:01 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:17:01 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:17:01 --> Utf8 Class Initialized
INFO - 2017-03-13 18:17:02 --> URI Class Initialized
INFO - 2017-03-13 18:17:02 --> Router Class Initialized
INFO - 2017-03-13 18:17:02 --> Output Class Initialized
INFO - 2017-03-13 18:17:02 --> Security Class Initialized
DEBUG - 2017-03-13 18:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:17:02 --> Input Class Initialized
INFO - 2017-03-13 18:17:02 --> Language Class Initialized
INFO - 2017-03-13 18:17:02 --> Loader Class Initialized
INFO - 2017-03-13 18:17:02 --> Database Driver Class Initialized
INFO - 2017-03-13 18:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:17:02 --> Controller Class Initialized
INFO - 2017-03-13 18:17:02 --> Helper loaded: date_helper
DEBUG - 2017-03-13 18:17:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:17:03 --> Helper loaded: url_helper
INFO - 2017-03-13 18:17:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:17:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 18:17:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 18:17:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 18:17:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:17:03 --> Final output sent to browser
DEBUG - 2017-03-13 18:17:03 --> Total execution time: 1.5128
INFO - 2017-03-13 18:18:23 --> Config Class Initialized
INFO - 2017-03-13 18:18:23 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:18:24 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:18:24 --> Utf8 Class Initialized
INFO - 2017-03-13 18:18:24 --> URI Class Initialized
INFO - 2017-03-13 18:18:24 --> Router Class Initialized
INFO - 2017-03-13 18:18:24 --> Output Class Initialized
INFO - 2017-03-13 18:18:24 --> Security Class Initialized
DEBUG - 2017-03-13 18:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:18:24 --> Input Class Initialized
INFO - 2017-03-13 18:18:24 --> Language Class Initialized
INFO - 2017-03-13 18:18:24 --> Loader Class Initialized
INFO - 2017-03-13 18:18:24 --> Database Driver Class Initialized
INFO - 2017-03-13 18:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:18:25 --> Controller Class Initialized
INFO - 2017-03-13 18:18:25 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:18:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:18:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:18:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:18:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:18:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:18:25 --> Final output sent to browser
DEBUG - 2017-03-13 18:18:25 --> Total execution time: 2.2092
INFO - 2017-03-13 18:19:29 --> Config Class Initialized
INFO - 2017-03-13 18:19:29 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:19:29 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:19:29 --> Utf8 Class Initialized
INFO - 2017-03-13 18:19:29 --> URI Class Initialized
DEBUG - 2017-03-13 18:19:29 --> No URI present. Default controller set.
INFO - 2017-03-13 18:19:29 --> Router Class Initialized
INFO - 2017-03-13 18:19:29 --> Output Class Initialized
INFO - 2017-03-13 18:19:29 --> Security Class Initialized
DEBUG - 2017-03-13 18:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:19:29 --> Input Class Initialized
INFO - 2017-03-13 18:19:29 --> Language Class Initialized
INFO - 2017-03-13 18:19:29 --> Loader Class Initialized
INFO - 2017-03-13 18:19:30 --> Database Driver Class Initialized
INFO - 2017-03-13 18:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:19:30 --> Controller Class Initialized
INFO - 2017-03-13 18:19:30 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:19:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:19:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:19:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:19:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:19:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:19:30 --> Final output sent to browser
DEBUG - 2017-03-13 18:19:30 --> Total execution time: 1.2543
INFO - 2017-03-13 18:20:43 --> Config Class Initialized
INFO - 2017-03-13 18:20:43 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:20:43 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:20:43 --> Utf8 Class Initialized
INFO - 2017-03-13 18:20:43 --> URI Class Initialized
DEBUG - 2017-03-13 18:20:44 --> No URI present. Default controller set.
INFO - 2017-03-13 18:20:44 --> Router Class Initialized
INFO - 2017-03-13 18:20:44 --> Output Class Initialized
INFO - 2017-03-13 18:20:44 --> Security Class Initialized
DEBUG - 2017-03-13 18:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:20:44 --> Input Class Initialized
INFO - 2017-03-13 18:20:44 --> Language Class Initialized
INFO - 2017-03-13 18:20:44 --> Loader Class Initialized
INFO - 2017-03-13 18:20:44 --> Database Driver Class Initialized
INFO - 2017-03-13 18:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:20:45 --> Controller Class Initialized
INFO - 2017-03-13 18:20:45 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:20:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:20:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:20:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:20:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:20:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:20:46 --> Final output sent to browser
DEBUG - 2017-03-13 18:20:46 --> Total execution time: 1.9155
INFO - 2017-03-13 18:20:58 --> Config Class Initialized
INFO - 2017-03-13 18:20:58 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:20:58 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:20:58 --> Utf8 Class Initialized
INFO - 2017-03-13 18:20:58 --> URI Class Initialized
INFO - 2017-03-13 18:20:58 --> Router Class Initialized
INFO - 2017-03-13 18:20:58 --> Output Class Initialized
INFO - 2017-03-13 18:20:58 --> Security Class Initialized
DEBUG - 2017-03-13 18:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:20:58 --> Input Class Initialized
INFO - 2017-03-13 18:20:58 --> Language Class Initialized
INFO - 2017-03-13 18:20:58 --> Loader Class Initialized
INFO - 2017-03-13 18:20:58 --> Database Driver Class Initialized
INFO - 2017-03-13 18:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:20:59 --> Controller Class Initialized
INFO - 2017-03-13 18:20:59 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:20:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:20:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:20:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:20:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:20:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:20:59 --> Final output sent to browser
DEBUG - 2017-03-13 18:20:59 --> Total execution time: 1.5876
INFO - 2017-03-13 18:23:48 --> Config Class Initialized
INFO - 2017-03-13 18:23:48 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:23:48 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:23:48 --> Utf8 Class Initialized
INFO - 2017-03-13 18:23:48 --> URI Class Initialized
DEBUG - 2017-03-13 18:23:49 --> No URI present. Default controller set.
INFO - 2017-03-13 18:23:49 --> Router Class Initialized
INFO - 2017-03-13 18:23:49 --> Output Class Initialized
INFO - 2017-03-13 18:23:49 --> Security Class Initialized
DEBUG - 2017-03-13 18:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:23:49 --> Input Class Initialized
INFO - 2017-03-13 18:23:49 --> Language Class Initialized
INFO - 2017-03-13 18:23:49 --> Loader Class Initialized
INFO - 2017-03-13 18:23:49 --> Database Driver Class Initialized
INFO - 2017-03-13 18:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:23:50 --> Controller Class Initialized
INFO - 2017-03-13 18:23:50 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:23:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:23:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:23:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:23:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:23:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:23:51 --> Final output sent to browser
DEBUG - 2017-03-13 18:23:51 --> Total execution time: 1.7676
INFO - 2017-03-13 18:23:56 --> Config Class Initialized
INFO - 2017-03-13 18:23:56 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:23:56 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:23:56 --> Utf8 Class Initialized
INFO - 2017-03-13 18:23:56 --> URI Class Initialized
DEBUG - 2017-03-13 18:23:56 --> No URI present. Default controller set.
INFO - 2017-03-13 18:23:56 --> Router Class Initialized
INFO - 2017-03-13 18:23:56 --> Output Class Initialized
INFO - 2017-03-13 18:23:56 --> Security Class Initialized
DEBUG - 2017-03-13 18:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:23:57 --> Input Class Initialized
INFO - 2017-03-13 18:23:57 --> Language Class Initialized
INFO - 2017-03-13 18:23:57 --> Loader Class Initialized
INFO - 2017-03-13 18:23:57 --> Database Driver Class Initialized
INFO - 2017-03-13 18:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:23:57 --> Controller Class Initialized
INFO - 2017-03-13 18:23:57 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:23:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:23:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:23:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:23:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:23:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:23:58 --> Final output sent to browser
DEBUG - 2017-03-13 18:23:58 --> Total execution time: 1.7594
INFO - 2017-03-13 18:24:06 --> Config Class Initialized
INFO - 2017-03-13 18:24:06 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:24:06 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:24:06 --> Utf8 Class Initialized
INFO - 2017-03-13 18:24:06 --> URI Class Initialized
INFO - 2017-03-13 18:24:06 --> Router Class Initialized
INFO - 2017-03-13 18:24:06 --> Output Class Initialized
INFO - 2017-03-13 18:24:06 --> Security Class Initialized
DEBUG - 2017-03-13 18:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:24:06 --> Input Class Initialized
INFO - 2017-03-13 18:24:06 --> Language Class Initialized
INFO - 2017-03-13 18:24:06 --> Loader Class Initialized
INFO - 2017-03-13 18:24:07 --> Database Driver Class Initialized
INFO - 2017-03-13 18:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:24:07 --> Controller Class Initialized
INFO - 2017-03-13 18:24:07 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:24:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:24:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:24:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:24:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:24:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:24:08 --> Final output sent to browser
DEBUG - 2017-03-13 18:24:08 --> Total execution time: 1.7280
INFO - 2017-03-13 18:24:11 --> Config Class Initialized
INFO - 2017-03-13 18:24:11 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:24:11 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:24:11 --> Utf8 Class Initialized
INFO - 2017-03-13 18:24:11 --> URI Class Initialized
INFO - 2017-03-13 18:24:12 --> Router Class Initialized
INFO - 2017-03-13 18:24:12 --> Output Class Initialized
INFO - 2017-03-13 18:24:12 --> Security Class Initialized
DEBUG - 2017-03-13 18:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:24:12 --> Input Class Initialized
INFO - 2017-03-13 18:24:12 --> Language Class Initialized
INFO - 2017-03-13 18:24:12 --> Loader Class Initialized
INFO - 2017-03-13 18:24:12 --> Database Driver Class Initialized
INFO - 2017-03-13 18:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:24:13 --> Controller Class Initialized
INFO - 2017-03-13 18:24:13 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:24:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:24:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:24:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:24:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:24:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:24:14 --> Final output sent to browser
DEBUG - 2017-03-13 18:24:14 --> Total execution time: 2.6674
INFO - 2017-03-13 18:25:52 --> Config Class Initialized
INFO - 2017-03-13 18:25:52 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:25:53 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:25:53 --> Utf8 Class Initialized
INFO - 2017-03-13 18:25:53 --> URI Class Initialized
INFO - 2017-03-13 18:25:53 --> Router Class Initialized
INFO - 2017-03-13 18:25:53 --> Output Class Initialized
INFO - 2017-03-13 18:25:53 --> Security Class Initialized
DEBUG - 2017-03-13 18:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:25:53 --> Input Class Initialized
INFO - 2017-03-13 18:25:53 --> Language Class Initialized
INFO - 2017-03-13 18:25:54 --> Loader Class Initialized
INFO - 2017-03-13 18:25:54 --> Database Driver Class Initialized
INFO - 2017-03-13 18:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:25:55 --> Controller Class Initialized
INFO - 2017-03-13 18:25:55 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:25:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:26:02 --> Config Class Initialized
INFO - 2017-03-13 18:26:02 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:26:02 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:26:02 --> Utf8 Class Initialized
INFO - 2017-03-13 18:26:02 --> URI Class Initialized
INFO - 2017-03-13 18:26:02 --> Router Class Initialized
INFO - 2017-03-13 18:26:02 --> Output Class Initialized
INFO - 2017-03-13 18:26:02 --> Security Class Initialized
DEBUG - 2017-03-13 18:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:26:02 --> Input Class Initialized
INFO - 2017-03-13 18:26:02 --> Language Class Initialized
INFO - 2017-03-13 18:26:02 --> Loader Class Initialized
INFO - 2017-03-13 18:26:03 --> Database Driver Class Initialized
INFO - 2017-03-13 18:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:26:17 --> Controller Class Initialized
INFO - 2017-03-13 18:26:17 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:26:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-13 18:27:00 --> Severity: error --> Exception: timed out before SSL handshake /home/graduafe/public_html/application/libraries/facebook-api-php-codexworld/base_facebook.php 972
INFO - 2017-03-13 18:27:12 --> Config Class Initialized
INFO - 2017-03-13 18:27:12 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:27:12 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:27:12 --> Utf8 Class Initialized
INFO - 2017-03-13 18:27:12 --> URI Class Initialized
INFO - 2017-03-13 18:27:12 --> Router Class Initialized
INFO - 2017-03-13 18:27:12 --> Output Class Initialized
INFO - 2017-03-13 18:27:12 --> Security Class Initialized
DEBUG - 2017-03-13 18:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:27:12 --> Input Class Initialized
INFO - 2017-03-13 18:27:12 --> Language Class Initialized
INFO - 2017-03-13 18:27:12 --> Loader Class Initialized
INFO - 2017-03-13 18:27:13 --> Database Driver Class Initialized
INFO - 2017-03-13 18:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:27:13 --> Controller Class Initialized
INFO - 2017-03-13 18:27:13 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:27:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:28:04 --> Config Class Initialized
INFO - 2017-03-13 18:28:04 --> Config Class Initialized
INFO - 2017-03-13 18:28:04 --> Hooks Class Initialized
INFO - 2017-03-13 18:28:04 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:28:05 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:28:05 --> Utf8 Class Initialized
DEBUG - 2017-03-13 18:28:06 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:28:06 --> Utf8 Class Initialized
INFO - 2017-03-13 18:28:07 --> URI Class Initialized
INFO - 2017-03-13 18:28:07 --> URI Class Initialized
INFO - 2017-03-13 18:28:08 --> Router Class Initialized
INFO - 2017-03-13 18:28:08 --> Router Class Initialized
INFO - 2017-03-13 18:28:08 --> Output Class Initialized
INFO - 2017-03-13 18:28:08 --> Output Class Initialized
INFO - 2017-03-13 18:28:09 --> Security Class Initialized
INFO - 2017-03-13 18:28:09 --> Security Class Initialized
DEBUG - 2017-03-13 18:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-03-13 18:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:28:09 --> Input Class Initialized
INFO - 2017-03-13 18:28:09 --> Input Class Initialized
INFO - 2017-03-13 18:28:09 --> Language Class Initialized
INFO - 2017-03-13 18:28:10 --> Language Class Initialized
INFO - 2017-03-13 18:28:10 --> Loader Class Initialized
INFO - 2017-03-13 18:28:10 --> Loader Class Initialized
INFO - 2017-03-13 18:28:11 --> Database Driver Class Initialized
INFO - 2017-03-13 18:28:14 --> Database Driver Class Initialized
INFO - 2017-03-13 18:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:28:16 --> Controller Class Initialized
INFO - 2017-03-13 18:28:16 --> Helper loaded: url_helper
INFO - 2017-03-13 18:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:28:17 --> Controller Class Initialized
DEBUG - 2017-03-13 18:28:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:28:18 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:28:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:28:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:28:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:28:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:28:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:28:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:28:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:28:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:28:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:28:21 --> Final output sent to browser
DEBUG - 2017-03-13 18:28:21 --> Total execution time: 19.6055
INFO - 2017-03-13 18:28:21 --> Final output sent to browser
DEBUG - 2017-03-13 18:28:21 --> Total execution time: 19.7075
INFO - 2017-03-13 18:28:26 --> Config Class Initialized
INFO - 2017-03-13 18:28:27 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:28:28 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:28:28 --> Utf8 Class Initialized
INFO - 2017-03-13 18:28:29 --> URI Class Initialized
INFO - 2017-03-13 18:28:30 --> Router Class Initialized
INFO - 2017-03-13 18:28:30 --> Output Class Initialized
INFO - 2017-03-13 18:28:31 --> Security Class Initialized
DEBUG - 2017-03-13 18:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:28:31 --> Input Class Initialized
INFO - 2017-03-13 18:28:32 --> Language Class Initialized
INFO - 2017-03-13 18:28:33 --> Loader Class Initialized
INFO - 2017-03-13 18:28:34 --> Database Driver Class Initialized
INFO - 2017-03-13 18:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:28:37 --> Controller Class Initialized
INFO - 2017-03-13 18:28:37 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:28:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:28:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:28:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:28:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:28:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
ERROR - 2017-03-13 18:28:39 --> Severity: error --> Exception: timed out before SSL handshake /home/graduafe/public_html/application/libraries/facebook-api-php-codexworld/base_facebook.php 972
INFO - 2017-03-13 18:28:39 --> Final output sent to browser
DEBUG - 2017-03-13 18:28:39 --> Total execution time: 14.9797
INFO - 2017-03-13 18:29:21 --> Config Class Initialized
INFO - 2017-03-13 18:29:21 --> Config Class Initialized
INFO - 2017-03-13 18:29:21 --> Hooks Class Initialized
INFO - 2017-03-13 18:29:21 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:29:21 --> UTF-8 Support Enabled
DEBUG - 2017-03-13 18:29:21 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:29:21 --> Utf8 Class Initialized
INFO - 2017-03-13 18:29:21 --> Utf8 Class Initialized
INFO - 2017-03-13 18:29:21 --> URI Class Initialized
INFO - 2017-03-13 18:29:21 --> URI Class Initialized
INFO - 2017-03-13 18:29:21 --> Router Class Initialized
INFO - 2017-03-13 18:29:21 --> Router Class Initialized
INFO - 2017-03-13 18:29:21 --> Output Class Initialized
INFO - 2017-03-13 18:29:21 --> Output Class Initialized
INFO - 2017-03-13 18:29:21 --> Security Class Initialized
DEBUG - 2017-03-13 18:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:29:21 --> Security Class Initialized
INFO - 2017-03-13 18:29:21 --> Input Class Initialized
INFO - 2017-03-13 18:29:21 --> Language Class Initialized
DEBUG - 2017-03-13 18:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:29:21 --> Input Class Initialized
INFO - 2017-03-13 18:29:21 --> Language Class Initialized
INFO - 2017-03-13 18:29:21 --> Loader Class Initialized
INFO - 2017-03-13 18:29:22 --> Loader Class Initialized
INFO - 2017-03-13 18:29:22 --> Database Driver Class Initialized
INFO - 2017-03-13 18:29:22 --> Database Driver Class Initialized
INFO - 2017-03-13 18:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:29:22 --> Controller Class Initialized
ERROR - 2017-03-13 18:29:22 --> Severity: Warning --> unlink(/tmp/ci_session5be36b6b7f1cf3563aaa780617e62d0de58d7e1b): No such file or directory /home/graduafe/public_html/system/libraries/Session/drivers/Session_files_driver.php 311
INFO - 2017-03-13 18:29:22 --> Helper loaded: url_helper
ERROR - 2017-03-13 18:29:22 --> Severity: Warning --> session_regenerate_id(): Session object destruction failed /home/graduafe/public_html/system/libraries/Session/Session.php 644
INFO - 2017-03-13 18:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:29:22 --> Controller Class Initialized
INFO - 2017-03-13 18:29:22 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:29:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-13 18:29:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:29:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:29:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:29:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:29:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:29:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:29:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:29:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:29:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:29:23 --> Final output sent to browser
DEBUG - 2017-03-13 18:29:23 --> Total execution time: 8.8340
INFO - 2017-03-13 18:29:23 --> Final output sent to browser
DEBUG - 2017-03-13 18:29:23 --> Total execution time: 8.8229
INFO - 2017-03-13 18:29:36 --> Config Class Initialized
INFO - 2017-03-13 18:29:36 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:29:36 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:29:36 --> Utf8 Class Initialized
INFO - 2017-03-13 18:29:36 --> URI Class Initialized
DEBUG - 2017-03-13 18:29:36 --> No URI present. Default controller set.
INFO - 2017-03-13 18:29:36 --> Router Class Initialized
INFO - 2017-03-13 18:29:36 --> Output Class Initialized
INFO - 2017-03-13 18:29:36 --> Security Class Initialized
DEBUG - 2017-03-13 18:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:29:36 --> Input Class Initialized
INFO - 2017-03-13 18:29:36 --> Language Class Initialized
INFO - 2017-03-13 18:29:36 --> Loader Class Initialized
INFO - 2017-03-13 18:29:37 --> Database Driver Class Initialized
INFO - 2017-03-13 18:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:29:37 --> Controller Class Initialized
INFO - 2017-03-13 18:29:37 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:29:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:29:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:29:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:29:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:29:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:29:38 --> Final output sent to browser
DEBUG - 2017-03-13 18:29:38 --> Total execution time: 1.9960
INFO - 2017-03-13 18:29:44 --> Config Class Initialized
INFO - 2017-03-13 18:29:44 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:29:44 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:29:44 --> Utf8 Class Initialized
INFO - 2017-03-13 18:29:44 --> URI Class Initialized
INFO - 2017-03-13 18:29:44 --> Router Class Initialized
INFO - 2017-03-13 18:29:44 --> Output Class Initialized
INFO - 2017-03-13 18:29:44 --> Security Class Initialized
DEBUG - 2017-03-13 18:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:29:44 --> Input Class Initialized
INFO - 2017-03-13 18:29:44 --> Language Class Initialized
INFO - 2017-03-13 18:29:44 --> Loader Class Initialized
INFO - 2017-03-13 18:29:44 --> Database Driver Class Initialized
INFO - 2017-03-13 18:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:29:45 --> Controller Class Initialized
INFO - 2017-03-13 18:29:45 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:29:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:29:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:29:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:29:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:29:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:29:45 --> Final output sent to browser
DEBUG - 2017-03-13 18:29:45 --> Total execution time: 1.7625
INFO - 2017-03-13 18:34:12 --> Config Class Initialized
INFO - 2017-03-13 18:34:12 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:34:12 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:34:12 --> Utf8 Class Initialized
INFO - 2017-03-13 18:34:12 --> URI Class Initialized
INFO - 2017-03-13 18:34:12 --> Router Class Initialized
INFO - 2017-03-13 18:34:12 --> Output Class Initialized
INFO - 2017-03-13 18:34:12 --> Security Class Initialized
DEBUG - 2017-03-13 18:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:34:12 --> Input Class Initialized
INFO - 2017-03-13 18:34:12 --> Language Class Initialized
INFO - 2017-03-13 18:34:12 --> Loader Class Initialized
INFO - 2017-03-13 18:34:13 --> Config Class Initialized
INFO - 2017-03-13 18:34:13 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:34:13 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:34:13 --> Utf8 Class Initialized
INFO - 2017-03-13 18:34:13 --> URI Class Initialized
INFO - 2017-03-13 18:34:13 --> Router Class Initialized
INFO - 2017-03-13 18:34:13 --> Output Class Initialized
INFO - 2017-03-13 18:34:13 --> Security Class Initialized
DEBUG - 2017-03-13 18:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:34:13 --> Input Class Initialized
INFO - 2017-03-13 18:34:13 --> Language Class Initialized
INFO - 2017-03-13 18:34:13 --> Loader Class Initialized
INFO - 2017-03-13 18:34:13 --> Database Driver Class Initialized
INFO - 2017-03-13 18:34:13 --> Database Driver Class Initialized
INFO - 2017-03-13 18:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:34:13 --> Controller Class Initialized
INFO - 2017-03-13 18:34:13 --> Helper loaded: url_helper
ERROR - 2017-03-13 18:34:13 --> Severity: Warning --> unlink(/tmp/ci_session41001ea43dc10a853b736f57385a337f42d79635): No such file or directory /home/graduafe/public_html/system/libraries/Session/drivers/Session_files_driver.php 311
ERROR - 2017-03-13 18:34:13 --> Severity: Warning --> session_regenerate_id(): Session object destruction failed /home/graduafe/public_html/system/libraries/Session/Session.php 644
DEBUG - 2017-03-13 18:34:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:34:13 --> Controller Class Initialized
INFO - 2017-03-13 18:34:13 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:34:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:34:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:34:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:34:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:34:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:34:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:34:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:34:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:34:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:34:14 --> Final output sent to browser
DEBUG - 2017-03-13 18:34:14 --> Total execution time: 2.2176
INFO - 2017-03-13 18:34:14 --> Final output sent to browser
DEBUG - 2017-03-13 18:34:14 --> Total execution time: 0.9442
INFO - 2017-03-13 18:34:35 --> Config Class Initialized
INFO - 2017-03-13 18:34:35 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:34:35 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:34:35 --> Utf8 Class Initialized
INFO - 2017-03-13 18:34:35 --> URI Class Initialized
INFO - 2017-03-13 18:34:35 --> Router Class Initialized
INFO - 2017-03-13 18:34:35 --> Output Class Initialized
INFO - 2017-03-13 18:34:35 --> Security Class Initialized
DEBUG - 2017-03-13 18:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:34:35 --> Input Class Initialized
INFO - 2017-03-13 18:34:35 --> Language Class Initialized
INFO - 2017-03-13 18:34:35 --> Loader Class Initialized
INFO - 2017-03-13 18:34:36 --> Database Driver Class Initialized
INFO - 2017-03-13 18:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:34:36 --> Controller Class Initialized
INFO - 2017-03-13 18:34:36 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:34:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-13 18:34:38 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-13 18:34:38 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Victoria Hernandez Garcia')
INFO - 2017-03-13 18:34:38 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-13 18:34:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-13 18:36:04 --> Config Class Initialized
INFO - 2017-03-13 18:36:04 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:36:04 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:36:04 --> Utf8 Class Initialized
INFO - 2017-03-13 18:36:04 --> URI Class Initialized
INFO - 2017-03-13 18:36:04 --> Router Class Initialized
INFO - 2017-03-13 18:36:04 --> Output Class Initialized
INFO - 2017-03-13 18:36:04 --> Security Class Initialized
DEBUG - 2017-03-13 18:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:36:04 --> Input Class Initialized
INFO - 2017-03-13 18:36:04 --> Language Class Initialized
INFO - 2017-03-13 18:36:04 --> Loader Class Initialized
INFO - 2017-03-13 18:36:05 --> Database Driver Class Initialized
INFO - 2017-03-13 18:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:36:05 --> Controller Class Initialized
INFO - 2017-03-13 18:36:05 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:36:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:36:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:36:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:36:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:36:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:36:06 --> Final output sent to browser
DEBUG - 2017-03-13 18:36:06 --> Total execution time: 1.5543
INFO - 2017-03-13 18:47:44 --> Config Class Initialized
INFO - 2017-03-13 18:47:44 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:47:44 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:47:44 --> Utf8 Class Initialized
INFO - 2017-03-13 18:47:44 --> URI Class Initialized
DEBUG - 2017-03-13 18:47:44 --> No URI present. Default controller set.
INFO - 2017-03-13 18:47:44 --> Router Class Initialized
INFO - 2017-03-13 18:47:44 --> Output Class Initialized
INFO - 2017-03-13 18:47:44 --> Security Class Initialized
DEBUG - 2017-03-13 18:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:47:44 --> Input Class Initialized
INFO - 2017-03-13 18:47:44 --> Language Class Initialized
INFO - 2017-03-13 18:47:45 --> Loader Class Initialized
INFO - 2017-03-13 18:47:45 --> Database Driver Class Initialized
INFO - 2017-03-13 18:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:47:45 --> Controller Class Initialized
INFO - 2017-03-13 18:47:45 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:47:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:47:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:47:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:47:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:47:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:47:46 --> Final output sent to browser
DEBUG - 2017-03-13 18:47:46 --> Total execution time: 2.1068
INFO - 2017-03-13 18:47:46 --> Config Class Initialized
INFO - 2017-03-13 18:47:46 --> Hooks Class Initialized
DEBUG - 2017-03-13 18:47:46 --> UTF-8 Support Enabled
INFO - 2017-03-13 18:47:46 --> Utf8 Class Initialized
INFO - 2017-03-13 18:47:46 --> URI Class Initialized
INFO - 2017-03-13 18:47:46 --> Router Class Initialized
INFO - 2017-03-13 18:47:46 --> Output Class Initialized
INFO - 2017-03-13 18:47:46 --> Security Class Initialized
DEBUG - 2017-03-13 18:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 18:47:46 --> Input Class Initialized
INFO - 2017-03-13 18:47:46 --> Language Class Initialized
INFO - 2017-03-13 18:47:46 --> Loader Class Initialized
INFO - 2017-03-13 18:47:46 --> Database Driver Class Initialized
INFO - 2017-03-13 18:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 18:47:46 --> Controller Class Initialized
INFO - 2017-03-13 18:47:46 --> Helper loaded: url_helper
DEBUG - 2017-03-13 18:47:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 18:47:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 18:47:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 18:47:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 18:47:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 18:47:46 --> Final output sent to browser
DEBUG - 2017-03-13 18:47:46 --> Total execution time: 0.0143
INFO - 2017-03-13 19:02:33 --> Config Class Initialized
INFO - 2017-03-13 19:02:33 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:02:33 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:02:33 --> Utf8 Class Initialized
INFO - 2017-03-13 19:02:33 --> URI Class Initialized
DEBUG - 2017-03-13 19:02:33 --> No URI present. Default controller set.
INFO - 2017-03-13 19:02:33 --> Router Class Initialized
INFO - 2017-03-13 19:02:33 --> Output Class Initialized
INFO - 2017-03-13 19:02:33 --> Security Class Initialized
DEBUG - 2017-03-13 19:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:02:33 --> Input Class Initialized
INFO - 2017-03-13 19:02:33 --> Language Class Initialized
INFO - 2017-03-13 19:02:33 --> Loader Class Initialized
INFO - 2017-03-13 19:02:34 --> Database Driver Class Initialized
INFO - 2017-03-13 19:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:02:34 --> Controller Class Initialized
INFO - 2017-03-13 19:02:34 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:02:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:02:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:02:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:02:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:02:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:02:34 --> Final output sent to browser
DEBUG - 2017-03-13 19:02:34 --> Total execution time: 1.7793
INFO - 2017-03-13 19:02:53 --> Config Class Initialized
INFO - 2017-03-13 19:02:53 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:02:53 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:02:53 --> Utf8 Class Initialized
INFO - 2017-03-13 19:02:53 --> URI Class Initialized
INFO - 2017-03-13 19:02:53 --> Router Class Initialized
INFO - 2017-03-13 19:02:53 --> Output Class Initialized
INFO - 2017-03-13 19:02:53 --> Security Class Initialized
DEBUG - 2017-03-13 19:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:02:53 --> Input Class Initialized
INFO - 2017-03-13 19:02:53 --> Language Class Initialized
INFO - 2017-03-13 19:02:53 --> Loader Class Initialized
INFO - 2017-03-13 19:02:53 --> Database Driver Class Initialized
INFO - 2017-03-13 19:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:02:53 --> Controller Class Initialized
INFO - 2017-03-13 19:02:53 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:02:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:02:54 --> Config Class Initialized
INFO - 2017-03-13 19:02:54 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:02:54 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:02:54 --> Utf8 Class Initialized
INFO - 2017-03-13 19:02:54 --> URI Class Initialized
INFO - 2017-03-13 19:02:54 --> Router Class Initialized
INFO - 2017-03-13 19:02:54 --> Output Class Initialized
INFO - 2017-03-13 19:02:54 --> Security Class Initialized
DEBUG - 2017-03-13 19:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:02:54 --> Input Class Initialized
INFO - 2017-03-13 19:02:54 --> Language Class Initialized
INFO - 2017-03-13 19:02:54 --> Loader Class Initialized
INFO - 2017-03-13 19:02:54 --> Database Driver Class Initialized
INFO - 2017-03-13 19:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:02:54 --> Controller Class Initialized
INFO - 2017-03-13 19:02:54 --> Helper loaded: date_helper
DEBUG - 2017-03-13 19:02:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:02:54 --> Helper loaded: url_helper
INFO - 2017-03-13 19:02:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:02:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 19:02:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 19:02:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 19:02:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:02:54 --> Final output sent to browser
DEBUG - 2017-03-13 19:02:54 --> Total execution time: 0.1646
INFO - 2017-03-13 19:02:56 --> Config Class Initialized
INFO - 2017-03-13 19:02:56 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:02:56 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:02:56 --> Utf8 Class Initialized
INFO - 2017-03-13 19:02:56 --> URI Class Initialized
INFO - 2017-03-13 19:02:56 --> Router Class Initialized
INFO - 2017-03-13 19:02:56 --> Output Class Initialized
INFO - 2017-03-13 19:02:56 --> Security Class Initialized
DEBUG - 2017-03-13 19:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:02:56 --> Input Class Initialized
INFO - 2017-03-13 19:02:56 --> Language Class Initialized
INFO - 2017-03-13 19:02:56 --> Loader Class Initialized
INFO - 2017-03-13 19:02:56 --> Database Driver Class Initialized
INFO - 2017-03-13 19:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:02:56 --> Controller Class Initialized
INFO - 2017-03-13 19:02:56 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:02:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:02:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:02:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:02:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:02:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:02:56 --> Final output sent to browser
DEBUG - 2017-03-13 19:02:56 --> Total execution time: 0.0136
INFO - 2017-03-13 19:03:08 --> Config Class Initialized
INFO - 2017-03-13 19:03:08 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:03:08 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:03:08 --> Utf8 Class Initialized
INFO - 2017-03-13 19:03:08 --> URI Class Initialized
DEBUG - 2017-03-13 19:03:08 --> No URI present. Default controller set.
INFO - 2017-03-13 19:03:08 --> Router Class Initialized
INFO - 2017-03-13 19:03:08 --> Output Class Initialized
INFO - 2017-03-13 19:03:08 --> Security Class Initialized
DEBUG - 2017-03-13 19:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:03:08 --> Input Class Initialized
INFO - 2017-03-13 19:03:08 --> Language Class Initialized
INFO - 2017-03-13 19:03:08 --> Loader Class Initialized
INFO - 2017-03-13 19:03:08 --> Database Driver Class Initialized
INFO - 2017-03-13 19:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:03:08 --> Controller Class Initialized
INFO - 2017-03-13 19:03:08 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:03:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:03:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:03:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:03:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:03:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:03:08 --> Final output sent to browser
DEBUG - 2017-03-13 19:03:08 --> Total execution time: 0.0139
INFO - 2017-03-13 19:03:12 --> Config Class Initialized
INFO - 2017-03-13 19:03:12 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:03:12 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:03:12 --> Utf8 Class Initialized
INFO - 2017-03-13 19:03:12 --> URI Class Initialized
INFO - 2017-03-13 19:03:12 --> Router Class Initialized
INFO - 2017-03-13 19:03:12 --> Output Class Initialized
INFO - 2017-03-13 19:03:12 --> Security Class Initialized
DEBUG - 2017-03-13 19:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:03:12 --> Input Class Initialized
INFO - 2017-03-13 19:03:12 --> Language Class Initialized
INFO - 2017-03-13 19:03:12 --> Loader Class Initialized
INFO - 2017-03-13 19:03:12 --> Database Driver Class Initialized
INFO - 2017-03-13 19:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:03:12 --> Controller Class Initialized
INFO - 2017-03-13 19:03:12 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:03:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:03:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:03:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:03:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:03:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:03:12 --> Final output sent to browser
DEBUG - 2017-03-13 19:03:12 --> Total execution time: 0.0140
INFO - 2017-03-13 19:03:44 --> Config Class Initialized
INFO - 2017-03-13 19:03:44 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:03:44 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:03:44 --> Utf8 Class Initialized
INFO - 2017-03-13 19:03:44 --> URI Class Initialized
DEBUG - 2017-03-13 19:03:44 --> No URI present. Default controller set.
INFO - 2017-03-13 19:03:44 --> Router Class Initialized
INFO - 2017-03-13 19:03:44 --> Output Class Initialized
INFO - 2017-03-13 19:03:44 --> Security Class Initialized
DEBUG - 2017-03-13 19:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:03:44 --> Input Class Initialized
INFO - 2017-03-13 19:03:44 --> Language Class Initialized
INFO - 2017-03-13 19:03:44 --> Loader Class Initialized
INFO - 2017-03-13 19:03:44 --> Database Driver Class Initialized
INFO - 2017-03-13 19:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:03:44 --> Controller Class Initialized
INFO - 2017-03-13 19:03:44 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:03:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:03:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:03:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:03:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:03:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:03:44 --> Final output sent to browser
DEBUG - 2017-03-13 19:03:44 --> Total execution time: 0.0133
INFO - 2017-03-13 19:03:52 --> Config Class Initialized
INFO - 2017-03-13 19:03:52 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:03:52 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:03:52 --> Utf8 Class Initialized
INFO - 2017-03-13 19:03:52 --> URI Class Initialized
INFO - 2017-03-13 19:03:52 --> Router Class Initialized
INFO - 2017-03-13 19:03:52 --> Output Class Initialized
INFO - 2017-03-13 19:03:52 --> Security Class Initialized
DEBUG - 2017-03-13 19:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:03:52 --> Input Class Initialized
INFO - 2017-03-13 19:03:52 --> Language Class Initialized
INFO - 2017-03-13 19:03:52 --> Loader Class Initialized
INFO - 2017-03-13 19:03:52 --> Database Driver Class Initialized
INFO - 2017-03-13 19:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:03:52 --> Controller Class Initialized
INFO - 2017-03-13 19:03:52 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:03:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:03:52 --> Config Class Initialized
INFO - 2017-03-13 19:03:52 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:03:52 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:03:52 --> Utf8 Class Initialized
INFO - 2017-03-13 19:03:52 --> URI Class Initialized
INFO - 2017-03-13 19:03:52 --> Router Class Initialized
INFO - 2017-03-13 19:03:52 --> Output Class Initialized
INFO - 2017-03-13 19:03:52 --> Security Class Initialized
DEBUG - 2017-03-13 19:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:03:52 --> Input Class Initialized
INFO - 2017-03-13 19:03:52 --> Language Class Initialized
INFO - 2017-03-13 19:03:52 --> Loader Class Initialized
INFO - 2017-03-13 19:03:52 --> Database Driver Class Initialized
INFO - 2017-03-13 19:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:03:52 --> Controller Class Initialized
INFO - 2017-03-13 19:03:52 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:03:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:03:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:03:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:03:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:03:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:03:52 --> Final output sent to browser
DEBUG - 2017-03-13 19:03:52 --> Total execution time: 0.0146
INFO - 2017-03-13 19:03:53 --> Config Class Initialized
INFO - 2017-03-13 19:03:53 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:03:53 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:03:53 --> Utf8 Class Initialized
INFO - 2017-03-13 19:03:53 --> URI Class Initialized
INFO - 2017-03-13 19:03:53 --> Router Class Initialized
INFO - 2017-03-13 19:03:53 --> Output Class Initialized
INFO - 2017-03-13 19:03:53 --> Security Class Initialized
DEBUG - 2017-03-13 19:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:03:53 --> Input Class Initialized
INFO - 2017-03-13 19:03:53 --> Language Class Initialized
INFO - 2017-03-13 19:03:53 --> Loader Class Initialized
INFO - 2017-03-13 19:03:53 --> Database Driver Class Initialized
INFO - 2017-03-13 19:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:03:53 --> Controller Class Initialized
INFO - 2017-03-13 19:03:53 --> Helper loaded: date_helper
DEBUG - 2017-03-13 19:03:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:03:53 --> Helper loaded: url_helper
INFO - 2017-03-13 19:03:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:03:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 19:03:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 19:03:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 19:03:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:03:53 --> Final output sent to browser
DEBUG - 2017-03-13 19:03:53 --> Total execution time: 0.0136
INFO - 2017-03-13 19:03:54 --> Config Class Initialized
INFO - 2017-03-13 19:03:54 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:03:54 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:03:54 --> Utf8 Class Initialized
INFO - 2017-03-13 19:03:54 --> URI Class Initialized
INFO - 2017-03-13 19:03:54 --> Router Class Initialized
INFO - 2017-03-13 19:03:54 --> Output Class Initialized
INFO - 2017-03-13 19:03:54 --> Security Class Initialized
DEBUG - 2017-03-13 19:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:03:54 --> Input Class Initialized
INFO - 2017-03-13 19:03:54 --> Language Class Initialized
INFO - 2017-03-13 19:03:54 --> Loader Class Initialized
INFO - 2017-03-13 19:03:54 --> Database Driver Class Initialized
INFO - 2017-03-13 19:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:03:54 --> Controller Class Initialized
INFO - 2017-03-13 19:03:54 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:03:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:03:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:03:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:03:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:03:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:03:54 --> Final output sent to browser
DEBUG - 2017-03-13 19:03:54 --> Total execution time: 0.0137
INFO - 2017-03-13 19:03:55 --> Config Class Initialized
INFO - 2017-03-13 19:03:55 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:03:55 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:03:55 --> Utf8 Class Initialized
INFO - 2017-03-13 19:03:55 --> URI Class Initialized
DEBUG - 2017-03-13 19:03:55 --> No URI present. Default controller set.
INFO - 2017-03-13 19:03:55 --> Router Class Initialized
INFO - 2017-03-13 19:03:55 --> Output Class Initialized
INFO - 2017-03-13 19:03:55 --> Security Class Initialized
DEBUG - 2017-03-13 19:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:03:55 --> Input Class Initialized
INFO - 2017-03-13 19:03:55 --> Language Class Initialized
INFO - 2017-03-13 19:03:55 --> Loader Class Initialized
INFO - 2017-03-13 19:03:55 --> Database Driver Class Initialized
INFO - 2017-03-13 19:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:03:55 --> Controller Class Initialized
INFO - 2017-03-13 19:03:55 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:03:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:03:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:03:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:03:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:03:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:03:55 --> Final output sent to browser
DEBUG - 2017-03-13 19:03:55 --> Total execution time: 0.0134
INFO - 2017-03-13 19:03:58 --> Config Class Initialized
INFO - 2017-03-13 19:03:58 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:03:58 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:03:58 --> Utf8 Class Initialized
INFO - 2017-03-13 19:03:58 --> URI Class Initialized
INFO - 2017-03-13 19:03:58 --> Router Class Initialized
INFO - 2017-03-13 19:03:58 --> Output Class Initialized
INFO - 2017-03-13 19:03:58 --> Security Class Initialized
DEBUG - 2017-03-13 19:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:03:58 --> Input Class Initialized
INFO - 2017-03-13 19:03:58 --> Language Class Initialized
INFO - 2017-03-13 19:03:58 --> Loader Class Initialized
INFO - 2017-03-13 19:03:59 --> Database Driver Class Initialized
INFO - 2017-03-13 19:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:03:59 --> Controller Class Initialized
INFO - 2017-03-13 19:03:59 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:03:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:03:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:03:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:03:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:03:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:03:59 --> Final output sent to browser
DEBUG - 2017-03-13 19:03:59 --> Total execution time: 0.0142
INFO - 2017-03-13 19:04:00 --> Config Class Initialized
INFO - 2017-03-13 19:04:00 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:04:00 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:04:00 --> Utf8 Class Initialized
INFO - 2017-03-13 19:04:00 --> URI Class Initialized
INFO - 2017-03-13 19:04:00 --> Router Class Initialized
INFO - 2017-03-13 19:04:00 --> Output Class Initialized
INFO - 2017-03-13 19:04:00 --> Security Class Initialized
DEBUG - 2017-03-13 19:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:04:00 --> Input Class Initialized
INFO - 2017-03-13 19:04:00 --> Language Class Initialized
INFO - 2017-03-13 19:04:00 --> Loader Class Initialized
INFO - 2017-03-13 19:04:00 --> Database Driver Class Initialized
INFO - 2017-03-13 19:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:04:00 --> Controller Class Initialized
INFO - 2017-03-13 19:04:00 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:04:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:04:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:04:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:04:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:04:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:04:00 --> Final output sent to browser
DEBUG - 2017-03-13 19:04:00 --> Total execution time: 0.0137
INFO - 2017-03-13 19:04:16 --> Config Class Initialized
INFO - 2017-03-13 19:04:16 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:04:16 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:04:16 --> Utf8 Class Initialized
INFO - 2017-03-13 19:04:16 --> URI Class Initialized
INFO - 2017-03-13 19:04:16 --> Router Class Initialized
INFO - 2017-03-13 19:04:16 --> Output Class Initialized
INFO - 2017-03-13 19:04:16 --> Security Class Initialized
DEBUG - 2017-03-13 19:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:04:16 --> Input Class Initialized
INFO - 2017-03-13 19:04:16 --> Language Class Initialized
INFO - 2017-03-13 19:04:16 --> Loader Class Initialized
INFO - 2017-03-13 19:04:16 --> Database Driver Class Initialized
INFO - 2017-03-13 19:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:04:16 --> Controller Class Initialized
INFO - 2017-03-13 19:04:16 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:04:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:04:17 --> Config Class Initialized
INFO - 2017-03-13 19:04:17 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:04:17 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:04:17 --> Utf8 Class Initialized
INFO - 2017-03-13 19:04:17 --> URI Class Initialized
INFO - 2017-03-13 19:04:17 --> Router Class Initialized
INFO - 2017-03-13 19:04:17 --> Output Class Initialized
INFO - 2017-03-13 19:04:17 --> Security Class Initialized
DEBUG - 2017-03-13 19:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:04:17 --> Input Class Initialized
INFO - 2017-03-13 19:04:17 --> Language Class Initialized
INFO - 2017-03-13 19:04:17 --> Loader Class Initialized
INFO - 2017-03-13 19:04:17 --> Database Driver Class Initialized
INFO - 2017-03-13 19:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:04:17 --> Controller Class Initialized
INFO - 2017-03-13 19:04:17 --> Helper loaded: date_helper
DEBUG - 2017-03-13 19:04:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:04:17 --> Helper loaded: url_helper
INFO - 2017-03-13 19:04:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:04:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 19:04:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 19:04:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 19:04:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:04:17 --> Final output sent to browser
DEBUG - 2017-03-13 19:04:17 --> Total execution time: 0.0133
INFO - 2017-03-13 19:04:18 --> Config Class Initialized
INFO - 2017-03-13 19:04:18 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:04:18 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:04:18 --> Utf8 Class Initialized
INFO - 2017-03-13 19:04:18 --> URI Class Initialized
INFO - 2017-03-13 19:04:18 --> Router Class Initialized
INFO - 2017-03-13 19:04:18 --> Output Class Initialized
INFO - 2017-03-13 19:04:18 --> Security Class Initialized
DEBUG - 2017-03-13 19:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:04:18 --> Input Class Initialized
INFO - 2017-03-13 19:04:18 --> Language Class Initialized
INFO - 2017-03-13 19:04:18 --> Loader Class Initialized
INFO - 2017-03-13 19:04:18 --> Database Driver Class Initialized
INFO - 2017-03-13 19:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:04:18 --> Controller Class Initialized
INFO - 2017-03-13 19:04:18 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:04:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:04:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:04:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:04:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:04:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:04:18 --> Final output sent to browser
DEBUG - 2017-03-13 19:04:18 --> Total execution time: 0.0158
INFO - 2017-03-13 19:04:20 --> Config Class Initialized
INFO - 2017-03-13 19:04:20 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:04:20 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:04:20 --> Utf8 Class Initialized
INFO - 2017-03-13 19:04:20 --> URI Class Initialized
INFO - 2017-03-13 19:04:20 --> Router Class Initialized
INFO - 2017-03-13 19:04:20 --> Output Class Initialized
INFO - 2017-03-13 19:04:20 --> Security Class Initialized
DEBUG - 2017-03-13 19:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:04:20 --> Input Class Initialized
INFO - 2017-03-13 19:04:20 --> Language Class Initialized
INFO - 2017-03-13 19:04:20 --> Loader Class Initialized
INFO - 2017-03-13 19:04:20 --> Database Driver Class Initialized
INFO - 2017-03-13 19:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:04:20 --> Controller Class Initialized
INFO - 2017-03-13 19:04:20 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:04:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:04:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:04:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:04:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:04:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:04:20 --> Final output sent to browser
DEBUG - 2017-03-13 19:04:20 --> Total execution time: 0.0148
INFO - 2017-03-13 19:04:22 --> Config Class Initialized
INFO - 2017-03-13 19:04:22 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:04:22 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:04:22 --> Utf8 Class Initialized
INFO - 2017-03-13 19:04:22 --> URI Class Initialized
INFO - 2017-03-13 19:04:22 --> Router Class Initialized
INFO - 2017-03-13 19:04:22 --> Output Class Initialized
INFO - 2017-03-13 19:04:22 --> Security Class Initialized
DEBUG - 2017-03-13 19:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:04:22 --> Input Class Initialized
INFO - 2017-03-13 19:04:22 --> Language Class Initialized
INFO - 2017-03-13 19:04:22 --> Loader Class Initialized
INFO - 2017-03-13 19:04:22 --> Database Driver Class Initialized
INFO - 2017-03-13 19:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:04:22 --> Controller Class Initialized
INFO - 2017-03-13 19:04:22 --> Helper loaded: date_helper
DEBUG - 2017-03-13 19:04:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:04:22 --> Helper loaded: url_helper
INFO - 2017-03-13 19:04:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:04:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 19:04:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 19:04:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 19:04:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:04:22 --> Final output sent to browser
DEBUG - 2017-03-13 19:04:22 --> Total execution time: 0.0148
INFO - 2017-03-13 19:04:24 --> Config Class Initialized
INFO - 2017-03-13 19:04:24 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:04:24 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:04:24 --> Utf8 Class Initialized
INFO - 2017-03-13 19:04:24 --> URI Class Initialized
DEBUG - 2017-03-13 19:04:24 --> No URI present. Default controller set.
INFO - 2017-03-13 19:04:24 --> Router Class Initialized
INFO - 2017-03-13 19:04:24 --> Output Class Initialized
INFO - 2017-03-13 19:04:24 --> Security Class Initialized
DEBUG - 2017-03-13 19:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:04:24 --> Input Class Initialized
INFO - 2017-03-13 19:04:24 --> Language Class Initialized
INFO - 2017-03-13 19:04:24 --> Loader Class Initialized
INFO - 2017-03-13 19:04:24 --> Database Driver Class Initialized
INFO - 2017-03-13 19:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:04:24 --> Controller Class Initialized
INFO - 2017-03-13 19:04:24 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:04:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:04:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:04:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:04:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:04:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:04:24 --> Final output sent to browser
DEBUG - 2017-03-13 19:04:24 --> Total execution time: 0.0137
INFO - 2017-03-13 19:04:42 --> Config Class Initialized
INFO - 2017-03-13 19:04:42 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:04:42 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:04:42 --> Utf8 Class Initialized
INFO - 2017-03-13 19:04:42 --> URI Class Initialized
INFO - 2017-03-13 19:04:42 --> Router Class Initialized
INFO - 2017-03-13 19:04:42 --> Output Class Initialized
INFO - 2017-03-13 19:04:42 --> Security Class Initialized
DEBUG - 2017-03-13 19:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:04:42 --> Input Class Initialized
INFO - 2017-03-13 19:04:42 --> Language Class Initialized
INFO - 2017-03-13 19:04:42 --> Loader Class Initialized
INFO - 2017-03-13 19:04:42 --> Database Driver Class Initialized
INFO - 2017-03-13 19:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:04:42 --> Controller Class Initialized
INFO - 2017-03-13 19:04:42 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:04:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:04:43 --> Config Class Initialized
INFO - 2017-03-13 19:04:43 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:04:43 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:04:43 --> Utf8 Class Initialized
INFO - 2017-03-13 19:04:43 --> URI Class Initialized
INFO - 2017-03-13 19:04:43 --> Router Class Initialized
INFO - 2017-03-13 19:04:43 --> Output Class Initialized
INFO - 2017-03-13 19:04:43 --> Security Class Initialized
DEBUG - 2017-03-13 19:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:04:43 --> Input Class Initialized
INFO - 2017-03-13 19:04:43 --> Language Class Initialized
INFO - 2017-03-13 19:04:43 --> Loader Class Initialized
INFO - 2017-03-13 19:04:43 --> Database Driver Class Initialized
INFO - 2017-03-13 19:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:04:43 --> Controller Class Initialized
INFO - 2017-03-13 19:04:43 --> Helper loaded: date_helper
DEBUG - 2017-03-13 19:04:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:04:43 --> Helper loaded: url_helper
INFO - 2017-03-13 19:04:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:04:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 19:04:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 19:04:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 19:04:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:04:43 --> Final output sent to browser
DEBUG - 2017-03-13 19:04:43 --> Total execution time: 0.0138
INFO - 2017-03-13 19:05:26 --> Config Class Initialized
INFO - 2017-03-13 19:05:26 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:05:26 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:05:26 --> Utf8 Class Initialized
INFO - 2017-03-13 19:05:26 --> URI Class Initialized
DEBUG - 2017-03-13 19:05:26 --> No URI present. Default controller set.
INFO - 2017-03-13 19:05:26 --> Router Class Initialized
INFO - 2017-03-13 19:05:26 --> Output Class Initialized
INFO - 2017-03-13 19:05:26 --> Security Class Initialized
DEBUG - 2017-03-13 19:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:05:26 --> Input Class Initialized
INFO - 2017-03-13 19:05:26 --> Language Class Initialized
INFO - 2017-03-13 19:05:26 --> Loader Class Initialized
INFO - 2017-03-13 19:05:26 --> Database Driver Class Initialized
INFO - 2017-03-13 19:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:05:26 --> Controller Class Initialized
INFO - 2017-03-13 19:05:26 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:05:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:05:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:05:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:05:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:05:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:05:26 --> Final output sent to browser
DEBUG - 2017-03-13 19:05:26 --> Total execution time: 0.0141
INFO - 2017-03-13 19:06:00 --> Config Class Initialized
INFO - 2017-03-13 19:06:00 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:06:00 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:06:00 --> Utf8 Class Initialized
INFO - 2017-03-13 19:06:00 --> URI Class Initialized
INFO - 2017-03-13 19:06:00 --> Router Class Initialized
INFO - 2017-03-13 19:06:00 --> Output Class Initialized
INFO - 2017-03-13 19:06:00 --> Security Class Initialized
DEBUG - 2017-03-13 19:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:06:00 --> Input Class Initialized
INFO - 2017-03-13 19:06:00 --> Language Class Initialized
INFO - 2017-03-13 19:06:00 --> Loader Class Initialized
INFO - 2017-03-13 19:06:00 --> Database Driver Class Initialized
INFO - 2017-03-13 19:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:06:00 --> Controller Class Initialized
INFO - 2017-03-13 19:06:00 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:06:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:06:00 --> Config Class Initialized
INFO - 2017-03-13 19:06:00 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:06:00 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:06:00 --> Utf8 Class Initialized
INFO - 2017-03-13 19:06:00 --> URI Class Initialized
INFO - 2017-03-13 19:06:00 --> Router Class Initialized
INFO - 2017-03-13 19:06:00 --> Output Class Initialized
INFO - 2017-03-13 19:06:00 --> Security Class Initialized
DEBUG - 2017-03-13 19:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:06:00 --> Input Class Initialized
INFO - 2017-03-13 19:06:00 --> Language Class Initialized
INFO - 2017-03-13 19:06:00 --> Loader Class Initialized
INFO - 2017-03-13 19:06:00 --> Database Driver Class Initialized
INFO - 2017-03-13 19:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:06:00 --> Controller Class Initialized
INFO - 2017-03-13 19:06:00 --> Helper loaded: date_helper
DEBUG - 2017-03-13 19:06:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:06:00 --> Helper loaded: url_helper
INFO - 2017-03-13 19:06:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:06:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 19:06:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 19:06:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 19:06:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:06:00 --> Final output sent to browser
DEBUG - 2017-03-13 19:06:00 --> Total execution time: 0.0373
INFO - 2017-03-13 19:06:18 --> Config Class Initialized
INFO - 2017-03-13 19:06:18 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:06:18 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:06:18 --> Utf8 Class Initialized
INFO - 2017-03-13 19:06:18 --> URI Class Initialized
DEBUG - 2017-03-13 19:06:18 --> No URI present. Default controller set.
INFO - 2017-03-13 19:06:18 --> Router Class Initialized
INFO - 2017-03-13 19:06:18 --> Output Class Initialized
INFO - 2017-03-13 19:06:18 --> Security Class Initialized
DEBUG - 2017-03-13 19:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:06:18 --> Input Class Initialized
INFO - 2017-03-13 19:06:18 --> Language Class Initialized
INFO - 2017-03-13 19:06:18 --> Loader Class Initialized
INFO - 2017-03-13 19:06:18 --> Database Driver Class Initialized
INFO - 2017-03-13 19:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:06:18 --> Controller Class Initialized
INFO - 2017-03-13 19:06:18 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:06:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:06:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:06:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:06:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:06:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:06:18 --> Final output sent to browser
DEBUG - 2017-03-13 19:06:18 --> Total execution time: 0.0152
INFO - 2017-03-13 19:07:10 --> Config Class Initialized
INFO - 2017-03-13 19:07:10 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:07:10 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:07:10 --> Utf8 Class Initialized
INFO - 2017-03-13 19:07:10 --> URI Class Initialized
INFO - 2017-03-13 19:07:10 --> Router Class Initialized
INFO - 2017-03-13 19:07:10 --> Output Class Initialized
INFO - 2017-03-13 19:07:10 --> Security Class Initialized
DEBUG - 2017-03-13 19:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:07:10 --> Input Class Initialized
INFO - 2017-03-13 19:07:10 --> Language Class Initialized
INFO - 2017-03-13 19:07:10 --> Loader Class Initialized
INFO - 2017-03-13 19:07:10 --> Database Driver Class Initialized
INFO - 2017-03-13 19:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:07:10 --> Controller Class Initialized
INFO - 2017-03-13 19:07:10 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:07:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:07:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:07:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:07:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:07:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:07:10 --> Final output sent to browser
DEBUG - 2017-03-13 19:07:10 --> Total execution time: 0.0161
INFO - 2017-03-13 19:07:46 --> Config Class Initialized
INFO - 2017-03-13 19:07:46 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:07:46 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:07:46 --> Utf8 Class Initialized
INFO - 2017-03-13 19:07:46 --> URI Class Initialized
INFO - 2017-03-13 19:07:46 --> Router Class Initialized
INFO - 2017-03-13 19:07:46 --> Output Class Initialized
INFO - 2017-03-13 19:07:46 --> Security Class Initialized
DEBUG - 2017-03-13 19:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:07:46 --> Input Class Initialized
INFO - 2017-03-13 19:07:46 --> Language Class Initialized
INFO - 2017-03-13 19:07:46 --> Loader Class Initialized
INFO - 2017-03-13 19:07:46 --> Database Driver Class Initialized
INFO - 2017-03-13 19:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:07:46 --> Controller Class Initialized
INFO - 2017-03-13 19:07:46 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:07:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:07:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:07:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:07:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:07:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:07:46 --> Final output sent to browser
DEBUG - 2017-03-13 19:07:46 --> Total execution time: 0.0198
INFO - 2017-03-13 19:07:57 --> Config Class Initialized
INFO - 2017-03-13 19:07:57 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:07:57 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:07:57 --> Utf8 Class Initialized
INFO - 2017-03-13 19:07:57 --> URI Class Initialized
INFO - 2017-03-13 19:07:57 --> Router Class Initialized
INFO - 2017-03-13 19:07:57 --> Output Class Initialized
INFO - 2017-03-13 19:07:57 --> Security Class Initialized
DEBUG - 2017-03-13 19:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:07:57 --> Input Class Initialized
INFO - 2017-03-13 19:07:57 --> Language Class Initialized
INFO - 2017-03-13 19:07:57 --> Loader Class Initialized
INFO - 2017-03-13 19:07:57 --> Database Driver Class Initialized
INFO - 2017-03-13 19:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:07:57 --> Controller Class Initialized
INFO - 2017-03-13 19:07:57 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:07:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:07:58 --> Config Class Initialized
INFO - 2017-03-13 19:07:58 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:07:58 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:07:58 --> Utf8 Class Initialized
INFO - 2017-03-13 19:07:58 --> URI Class Initialized
INFO - 2017-03-13 19:07:58 --> Router Class Initialized
INFO - 2017-03-13 19:07:58 --> Output Class Initialized
INFO - 2017-03-13 19:07:58 --> Security Class Initialized
DEBUG - 2017-03-13 19:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:07:58 --> Input Class Initialized
INFO - 2017-03-13 19:07:58 --> Language Class Initialized
INFO - 2017-03-13 19:07:58 --> Loader Class Initialized
INFO - 2017-03-13 19:07:58 --> Database Driver Class Initialized
INFO - 2017-03-13 19:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:07:58 --> Controller Class Initialized
INFO - 2017-03-13 19:07:58 --> Helper loaded: date_helper
DEBUG - 2017-03-13 19:07:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:07:58 --> Helper loaded: url_helper
INFO - 2017-03-13 19:07:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:07:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 19:07:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 19:07:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 19:07:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:07:58 --> Final output sent to browser
DEBUG - 2017-03-13 19:07:58 --> Total execution time: 0.0139
INFO - 2017-03-13 19:08:09 --> Config Class Initialized
INFO - 2017-03-13 19:08:09 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:08:09 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:08:09 --> Utf8 Class Initialized
INFO - 2017-03-13 19:08:09 --> URI Class Initialized
DEBUG - 2017-03-13 19:08:09 --> No URI present. Default controller set.
INFO - 2017-03-13 19:08:09 --> Router Class Initialized
INFO - 2017-03-13 19:08:09 --> Output Class Initialized
INFO - 2017-03-13 19:08:09 --> Security Class Initialized
DEBUG - 2017-03-13 19:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:08:09 --> Input Class Initialized
INFO - 2017-03-13 19:08:09 --> Language Class Initialized
INFO - 2017-03-13 19:08:09 --> Loader Class Initialized
INFO - 2017-03-13 19:08:09 --> Database Driver Class Initialized
INFO - 2017-03-13 19:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:08:09 --> Controller Class Initialized
INFO - 2017-03-13 19:08:09 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:08:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:08:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:08:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:08:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:08:09 --> Final output sent to browser
DEBUG - 2017-03-13 19:08:09 --> Total execution time: 0.0129
INFO - 2017-03-13 19:08:10 --> Config Class Initialized
INFO - 2017-03-13 19:08:10 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:08:10 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:08:10 --> Utf8 Class Initialized
INFO - 2017-03-13 19:08:10 --> URI Class Initialized
INFO - 2017-03-13 19:08:10 --> Router Class Initialized
INFO - 2017-03-13 19:08:10 --> Output Class Initialized
INFO - 2017-03-13 19:08:10 --> Security Class Initialized
DEBUG - 2017-03-13 19:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:08:10 --> Input Class Initialized
INFO - 2017-03-13 19:08:10 --> Language Class Initialized
INFO - 2017-03-13 19:08:10 --> Loader Class Initialized
INFO - 2017-03-13 19:08:10 --> Database Driver Class Initialized
INFO - 2017-03-13 19:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:08:10 --> Controller Class Initialized
INFO - 2017-03-13 19:08:10 --> Helper loaded: date_helper
DEBUG - 2017-03-13 19:08:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:08:10 --> Helper loaded: url_helper
INFO - 2017-03-13 19:08:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:08:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 19:08:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 19:08:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 19:08:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:08:10 --> Final output sent to browser
DEBUG - 2017-03-13 19:08:10 --> Total execution time: 0.0133
INFO - 2017-03-13 19:08:10 --> Config Class Initialized
INFO - 2017-03-13 19:08:10 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:08:10 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:08:10 --> Utf8 Class Initialized
INFO - 2017-03-13 19:08:10 --> URI Class Initialized
DEBUG - 2017-03-13 19:08:10 --> No URI present. Default controller set.
INFO - 2017-03-13 19:08:10 --> Router Class Initialized
INFO - 2017-03-13 19:08:10 --> Output Class Initialized
INFO - 2017-03-13 19:08:10 --> Security Class Initialized
DEBUG - 2017-03-13 19:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:08:10 --> Input Class Initialized
INFO - 2017-03-13 19:08:10 --> Language Class Initialized
INFO - 2017-03-13 19:08:10 --> Loader Class Initialized
INFO - 2017-03-13 19:08:10 --> Database Driver Class Initialized
INFO - 2017-03-13 19:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:08:10 --> Controller Class Initialized
INFO - 2017-03-13 19:08:10 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:08:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:08:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:08:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:08:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:08:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:08:10 --> Final output sent to browser
DEBUG - 2017-03-13 19:08:10 --> Total execution time: 0.0132
INFO - 2017-03-13 19:08:15 --> Config Class Initialized
INFO - 2017-03-13 19:08:15 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:08:15 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:08:15 --> Utf8 Class Initialized
INFO - 2017-03-13 19:08:15 --> URI Class Initialized
DEBUG - 2017-03-13 19:08:15 --> No URI present. Default controller set.
INFO - 2017-03-13 19:08:15 --> Router Class Initialized
INFO - 2017-03-13 19:08:15 --> Output Class Initialized
INFO - 2017-03-13 19:08:15 --> Security Class Initialized
DEBUG - 2017-03-13 19:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:08:15 --> Input Class Initialized
INFO - 2017-03-13 19:08:15 --> Language Class Initialized
INFO - 2017-03-13 19:08:15 --> Loader Class Initialized
INFO - 2017-03-13 19:08:15 --> Database Driver Class Initialized
INFO - 2017-03-13 19:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:08:15 --> Controller Class Initialized
INFO - 2017-03-13 19:08:15 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:08:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:08:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:08:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:08:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:08:15 --> Final output sent to browser
DEBUG - 2017-03-13 19:08:15 --> Total execution time: 0.0135
INFO - 2017-03-13 19:08:15 --> Config Class Initialized
INFO - 2017-03-13 19:08:15 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:08:15 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:08:15 --> Utf8 Class Initialized
INFO - 2017-03-13 19:08:15 --> URI Class Initialized
INFO - 2017-03-13 19:08:15 --> Router Class Initialized
INFO - 2017-03-13 19:08:15 --> Output Class Initialized
INFO - 2017-03-13 19:08:15 --> Security Class Initialized
DEBUG - 2017-03-13 19:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:08:15 --> Input Class Initialized
INFO - 2017-03-13 19:08:15 --> Language Class Initialized
INFO - 2017-03-13 19:08:15 --> Loader Class Initialized
INFO - 2017-03-13 19:08:15 --> Database Driver Class Initialized
INFO - 2017-03-13 19:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:08:15 --> Controller Class Initialized
INFO - 2017-03-13 19:08:15 --> Helper loaded: date_helper
DEBUG - 2017-03-13 19:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:08:15 --> Helper loaded: url_helper
INFO - 2017-03-13 19:08:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:08:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 19:08:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 19:08:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 19:08:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:08:15 --> Final output sent to browser
DEBUG - 2017-03-13 19:08:15 --> Total execution time: 0.0140
INFO - 2017-03-13 19:08:16 --> Config Class Initialized
INFO - 2017-03-13 19:08:16 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:08:16 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:08:16 --> Utf8 Class Initialized
INFO - 2017-03-13 19:08:16 --> URI Class Initialized
DEBUG - 2017-03-13 19:08:16 --> No URI present. Default controller set.
INFO - 2017-03-13 19:08:16 --> Router Class Initialized
INFO - 2017-03-13 19:08:16 --> Output Class Initialized
INFO - 2017-03-13 19:08:16 --> Security Class Initialized
DEBUG - 2017-03-13 19:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:08:16 --> Input Class Initialized
INFO - 2017-03-13 19:08:16 --> Language Class Initialized
INFO - 2017-03-13 19:08:16 --> Loader Class Initialized
INFO - 2017-03-13 19:08:16 --> Database Driver Class Initialized
INFO - 2017-03-13 19:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:08:16 --> Controller Class Initialized
INFO - 2017-03-13 19:08:16 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:08:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:08:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:08:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:08:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:08:16 --> Final output sent to browser
DEBUG - 2017-03-13 19:08:16 --> Total execution time: 0.0134
INFO - 2017-03-13 19:08:27 --> Config Class Initialized
INFO - 2017-03-13 19:08:27 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:08:27 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:08:27 --> Utf8 Class Initialized
INFO - 2017-03-13 19:08:27 --> URI Class Initialized
INFO - 2017-03-13 19:08:27 --> Router Class Initialized
INFO - 2017-03-13 19:08:27 --> Output Class Initialized
INFO - 2017-03-13 19:08:27 --> Security Class Initialized
DEBUG - 2017-03-13 19:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:08:27 --> Input Class Initialized
INFO - 2017-03-13 19:08:27 --> Language Class Initialized
INFO - 2017-03-13 19:08:27 --> Loader Class Initialized
INFO - 2017-03-13 19:08:27 --> Database Driver Class Initialized
INFO - 2017-03-13 19:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:08:27 --> Controller Class Initialized
INFO - 2017-03-13 19:08:27 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:08:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-13 19:08:28 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-13 19:08:28 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Miriam Avelar')
INFO - 2017-03-13 19:08:28 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-13 19:08:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-13 19:08:28 --> Config Class Initialized
INFO - 2017-03-13 19:08:28 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:08:28 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:08:28 --> Utf8 Class Initialized
INFO - 2017-03-13 19:08:28 --> URI Class Initialized
DEBUG - 2017-03-13 19:08:28 --> No URI present. Default controller set.
INFO - 2017-03-13 19:08:28 --> Router Class Initialized
INFO - 2017-03-13 19:08:28 --> Output Class Initialized
INFO - 2017-03-13 19:08:28 --> Security Class Initialized
DEBUG - 2017-03-13 19:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:08:28 --> Input Class Initialized
INFO - 2017-03-13 19:08:28 --> Language Class Initialized
INFO - 2017-03-13 19:08:28 --> Loader Class Initialized
INFO - 2017-03-13 19:08:28 --> Database Driver Class Initialized
INFO - 2017-03-13 19:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:08:28 --> Controller Class Initialized
INFO - 2017-03-13 19:08:28 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:08:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:08:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:08:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:08:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:08:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:08:28 --> Final output sent to browser
DEBUG - 2017-03-13 19:08:28 --> Total execution time: 0.0128
INFO - 2017-03-13 19:08:35 --> Config Class Initialized
INFO - 2017-03-13 19:08:35 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:08:35 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:08:35 --> Utf8 Class Initialized
INFO - 2017-03-13 19:08:35 --> URI Class Initialized
INFO - 2017-03-13 19:08:35 --> Router Class Initialized
INFO - 2017-03-13 19:08:35 --> Output Class Initialized
INFO - 2017-03-13 19:08:35 --> Security Class Initialized
DEBUG - 2017-03-13 19:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:08:35 --> Input Class Initialized
INFO - 2017-03-13 19:08:35 --> Language Class Initialized
INFO - 2017-03-13 19:08:35 --> Loader Class Initialized
INFO - 2017-03-13 19:08:35 --> Database Driver Class Initialized
INFO - 2017-03-13 19:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:08:35 --> Controller Class Initialized
INFO - 2017-03-13 19:08:35 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:08:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:08:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:08:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:08:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:08:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:08:35 --> Final output sent to browser
DEBUG - 2017-03-13 19:08:35 --> Total execution time: 0.0134
INFO - 2017-03-13 19:08:40 --> Config Class Initialized
INFO - 2017-03-13 19:08:40 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:08:40 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:08:40 --> Utf8 Class Initialized
INFO - 2017-03-13 19:08:40 --> URI Class Initialized
INFO - 2017-03-13 19:08:40 --> Router Class Initialized
INFO - 2017-03-13 19:08:40 --> Output Class Initialized
INFO - 2017-03-13 19:08:40 --> Security Class Initialized
DEBUG - 2017-03-13 19:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:08:40 --> Input Class Initialized
INFO - 2017-03-13 19:08:40 --> Language Class Initialized
INFO - 2017-03-13 19:08:40 --> Loader Class Initialized
INFO - 2017-03-13 19:08:40 --> Database Driver Class Initialized
INFO - 2017-03-13 19:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:08:40 --> Controller Class Initialized
INFO - 2017-03-13 19:08:40 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:08:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-13 19:08:41 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-13 19:08:41 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Miriam Avelar')
INFO - 2017-03-13 19:08:41 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-13 19:08:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-13 19:08:46 --> Config Class Initialized
INFO - 2017-03-13 19:08:46 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:08:46 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:08:46 --> Utf8 Class Initialized
INFO - 2017-03-13 19:08:46 --> URI Class Initialized
INFO - 2017-03-13 19:08:46 --> Router Class Initialized
INFO - 2017-03-13 19:08:46 --> Output Class Initialized
INFO - 2017-03-13 19:08:46 --> Security Class Initialized
DEBUG - 2017-03-13 19:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:08:46 --> Input Class Initialized
INFO - 2017-03-13 19:08:46 --> Language Class Initialized
INFO - 2017-03-13 19:08:46 --> Loader Class Initialized
INFO - 2017-03-13 19:08:46 --> Database Driver Class Initialized
INFO - 2017-03-13 19:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:08:46 --> Controller Class Initialized
INFO - 2017-03-13 19:08:46 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:08:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-13 19:08:46 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-13 19:08:46 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Miriam Avelar')
INFO - 2017-03-13 19:08:46 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-13 19:08:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-13 19:09:23 --> Config Class Initialized
INFO - 2017-03-13 19:09:23 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:09:23 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:09:23 --> Utf8 Class Initialized
INFO - 2017-03-13 19:09:23 --> URI Class Initialized
DEBUG - 2017-03-13 19:09:23 --> No URI present. Default controller set.
INFO - 2017-03-13 19:09:23 --> Router Class Initialized
INFO - 2017-03-13 19:09:23 --> Output Class Initialized
INFO - 2017-03-13 19:09:23 --> Security Class Initialized
DEBUG - 2017-03-13 19:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:09:23 --> Input Class Initialized
INFO - 2017-03-13 19:09:23 --> Language Class Initialized
INFO - 2017-03-13 19:09:23 --> Loader Class Initialized
INFO - 2017-03-13 19:09:23 --> Database Driver Class Initialized
INFO - 2017-03-13 19:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:09:23 --> Controller Class Initialized
INFO - 2017-03-13 19:09:23 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:09:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:09:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:09:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:09:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:09:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:09:23 --> Final output sent to browser
DEBUG - 2017-03-13 19:09:23 --> Total execution time: 0.0140
INFO - 2017-03-13 19:09:31 --> Config Class Initialized
INFO - 2017-03-13 19:09:31 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:09:31 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:09:31 --> Utf8 Class Initialized
INFO - 2017-03-13 19:09:31 --> URI Class Initialized
INFO - 2017-03-13 19:09:31 --> Router Class Initialized
INFO - 2017-03-13 19:09:31 --> Output Class Initialized
INFO - 2017-03-13 19:09:31 --> Security Class Initialized
DEBUG - 2017-03-13 19:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:09:31 --> Input Class Initialized
INFO - 2017-03-13 19:09:31 --> Language Class Initialized
INFO - 2017-03-13 19:09:31 --> Loader Class Initialized
INFO - 2017-03-13 19:09:31 --> Database Driver Class Initialized
INFO - 2017-03-13 19:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:09:31 --> Controller Class Initialized
INFO - 2017-03-13 19:09:31 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:09:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:09:31 --> Config Class Initialized
INFO - 2017-03-13 19:09:31 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:09:31 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:09:31 --> Utf8 Class Initialized
INFO - 2017-03-13 19:09:31 --> URI Class Initialized
INFO - 2017-03-13 19:09:31 --> Router Class Initialized
INFO - 2017-03-13 19:09:31 --> Output Class Initialized
INFO - 2017-03-13 19:09:31 --> Security Class Initialized
DEBUG - 2017-03-13 19:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:09:31 --> Input Class Initialized
INFO - 2017-03-13 19:09:31 --> Language Class Initialized
INFO - 2017-03-13 19:09:31 --> Loader Class Initialized
INFO - 2017-03-13 19:09:31 --> Database Driver Class Initialized
INFO - 2017-03-13 19:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:09:31 --> Controller Class Initialized
INFO - 2017-03-13 19:09:31 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:09:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:09:32 --> Config Class Initialized
INFO - 2017-03-13 19:09:32 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:09:32 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:09:32 --> Utf8 Class Initialized
INFO - 2017-03-13 19:09:32 --> URI Class Initialized
INFO - 2017-03-13 19:09:32 --> Router Class Initialized
INFO - 2017-03-13 19:09:32 --> Output Class Initialized
INFO - 2017-03-13 19:09:32 --> Security Class Initialized
DEBUG - 2017-03-13 19:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:09:32 --> Input Class Initialized
INFO - 2017-03-13 19:09:32 --> Language Class Initialized
INFO - 2017-03-13 19:09:32 --> Loader Class Initialized
INFO - 2017-03-13 19:09:32 --> Database Driver Class Initialized
INFO - 2017-03-13 19:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:09:32 --> Controller Class Initialized
INFO - 2017-03-13 19:09:32 --> Helper loaded: date_helper
DEBUG - 2017-03-13 19:09:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:09:32 --> Helper loaded: url_helper
INFO - 2017-03-13 19:09:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:09:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 19:09:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 19:09:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 19:09:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:09:32 --> Final output sent to browser
DEBUG - 2017-03-13 19:09:32 --> Total execution time: 0.0491
INFO - 2017-03-13 19:09:32 --> Config Class Initialized
INFO - 2017-03-13 19:09:32 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:09:32 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:09:32 --> Utf8 Class Initialized
INFO - 2017-03-13 19:09:32 --> URI Class Initialized
INFO - 2017-03-13 19:09:32 --> Router Class Initialized
INFO - 2017-03-13 19:09:32 --> Output Class Initialized
INFO - 2017-03-13 19:09:32 --> Security Class Initialized
DEBUG - 2017-03-13 19:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:09:32 --> Input Class Initialized
INFO - 2017-03-13 19:09:32 --> Language Class Initialized
INFO - 2017-03-13 19:09:32 --> Loader Class Initialized
INFO - 2017-03-13 19:09:32 --> Database Driver Class Initialized
INFO - 2017-03-13 19:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:09:32 --> Controller Class Initialized
INFO - 2017-03-13 19:09:32 --> Helper loaded: date_helper
DEBUG - 2017-03-13 19:09:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:09:32 --> Helper loaded: url_helper
INFO - 2017-03-13 19:09:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:09:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 19:09:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 19:09:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 19:09:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:09:32 --> Final output sent to browser
DEBUG - 2017-03-13 19:09:32 --> Total execution time: 0.0140
INFO - 2017-03-13 19:09:33 --> Config Class Initialized
INFO - 2017-03-13 19:09:33 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:09:33 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:09:33 --> Utf8 Class Initialized
INFO - 2017-03-13 19:09:33 --> URI Class Initialized
INFO - 2017-03-13 19:09:33 --> Router Class Initialized
INFO - 2017-03-13 19:09:33 --> Output Class Initialized
INFO - 2017-03-13 19:09:33 --> Security Class Initialized
DEBUG - 2017-03-13 19:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:09:33 --> Input Class Initialized
INFO - 2017-03-13 19:09:33 --> Language Class Initialized
INFO - 2017-03-13 19:09:33 --> Loader Class Initialized
INFO - 2017-03-13 19:09:33 --> Database Driver Class Initialized
INFO - 2017-03-13 19:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:09:33 --> Controller Class Initialized
INFO - 2017-03-13 19:09:33 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:09:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:09:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:09:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:09:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:09:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:09:33 --> Final output sent to browser
DEBUG - 2017-03-13 19:09:33 --> Total execution time: 0.0137
INFO - 2017-03-13 19:09:48 --> Config Class Initialized
INFO - 2017-03-13 19:09:48 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:09:48 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:09:48 --> Utf8 Class Initialized
INFO - 2017-03-13 19:09:48 --> URI Class Initialized
INFO - 2017-03-13 19:09:48 --> Router Class Initialized
INFO - 2017-03-13 19:09:48 --> Output Class Initialized
INFO - 2017-03-13 19:09:48 --> Security Class Initialized
DEBUG - 2017-03-13 19:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:09:48 --> Input Class Initialized
INFO - 2017-03-13 19:09:48 --> Language Class Initialized
INFO - 2017-03-13 19:09:48 --> Loader Class Initialized
INFO - 2017-03-13 19:09:48 --> Database Driver Class Initialized
INFO - 2017-03-13 19:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:09:48 --> Controller Class Initialized
INFO - 2017-03-13 19:09:48 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:09:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:09:49 --> Config Class Initialized
INFO - 2017-03-13 19:09:49 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:09:49 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:09:49 --> Utf8 Class Initialized
INFO - 2017-03-13 19:09:49 --> URI Class Initialized
INFO - 2017-03-13 19:09:49 --> Router Class Initialized
INFO - 2017-03-13 19:09:49 --> Output Class Initialized
INFO - 2017-03-13 19:09:49 --> Security Class Initialized
DEBUG - 2017-03-13 19:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:09:49 --> Input Class Initialized
INFO - 2017-03-13 19:09:49 --> Language Class Initialized
INFO - 2017-03-13 19:09:49 --> Loader Class Initialized
INFO - 2017-03-13 19:09:49 --> Database Driver Class Initialized
INFO - 2017-03-13 19:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:09:49 --> Controller Class Initialized
INFO - 2017-03-13 19:09:49 --> Helper loaded: date_helper
DEBUG - 2017-03-13 19:09:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:09:49 --> Helper loaded: url_helper
INFO - 2017-03-13 19:09:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:09:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 19:09:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 19:09:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 19:09:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:09:49 --> Final output sent to browser
DEBUG - 2017-03-13 19:09:49 --> Total execution time: 0.0144
INFO - 2017-03-13 19:09:50 --> Config Class Initialized
INFO - 2017-03-13 19:09:50 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:09:50 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:09:50 --> Utf8 Class Initialized
INFO - 2017-03-13 19:09:50 --> URI Class Initialized
INFO - 2017-03-13 19:09:50 --> Router Class Initialized
INFO - 2017-03-13 19:09:50 --> Output Class Initialized
INFO - 2017-03-13 19:09:50 --> Security Class Initialized
DEBUG - 2017-03-13 19:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:09:50 --> Input Class Initialized
INFO - 2017-03-13 19:09:50 --> Language Class Initialized
INFO - 2017-03-13 19:09:50 --> Loader Class Initialized
INFO - 2017-03-13 19:09:50 --> Database Driver Class Initialized
INFO - 2017-03-13 19:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:09:50 --> Controller Class Initialized
INFO - 2017-03-13 19:09:50 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:09:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:09:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:09:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:09:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:09:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:09:50 --> Final output sent to browser
DEBUG - 2017-03-13 19:09:50 --> Total execution time: 0.0231
INFO - 2017-03-13 19:09:51 --> Config Class Initialized
INFO - 2017-03-13 19:09:51 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:09:51 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:09:51 --> Utf8 Class Initialized
INFO - 2017-03-13 19:09:51 --> URI Class Initialized
DEBUG - 2017-03-13 19:09:51 --> No URI present. Default controller set.
INFO - 2017-03-13 19:09:51 --> Router Class Initialized
INFO - 2017-03-13 19:09:51 --> Output Class Initialized
INFO - 2017-03-13 19:09:51 --> Security Class Initialized
DEBUG - 2017-03-13 19:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:09:51 --> Input Class Initialized
INFO - 2017-03-13 19:09:51 --> Language Class Initialized
INFO - 2017-03-13 19:09:51 --> Loader Class Initialized
INFO - 2017-03-13 19:09:51 --> Database Driver Class Initialized
INFO - 2017-03-13 19:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:09:51 --> Controller Class Initialized
INFO - 2017-03-13 19:09:51 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:09:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:09:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:09:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:09:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:09:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:09:51 --> Final output sent to browser
DEBUG - 2017-03-13 19:09:51 --> Total execution time: 0.0135
INFO - 2017-03-13 19:10:33 --> Config Class Initialized
INFO - 2017-03-13 19:10:33 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:10:33 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:10:33 --> Utf8 Class Initialized
INFO - 2017-03-13 19:10:33 --> URI Class Initialized
DEBUG - 2017-03-13 19:10:33 --> No URI present. Default controller set.
INFO - 2017-03-13 19:10:33 --> Router Class Initialized
INFO - 2017-03-13 19:10:33 --> Output Class Initialized
INFO - 2017-03-13 19:10:33 --> Security Class Initialized
DEBUG - 2017-03-13 19:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:10:33 --> Input Class Initialized
INFO - 2017-03-13 19:10:33 --> Language Class Initialized
INFO - 2017-03-13 19:10:33 --> Loader Class Initialized
INFO - 2017-03-13 19:10:33 --> Database Driver Class Initialized
INFO - 2017-03-13 19:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:10:33 --> Controller Class Initialized
INFO - 2017-03-13 19:10:33 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:10:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:10:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:10:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:10:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:10:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:10:33 --> Final output sent to browser
DEBUG - 2017-03-13 19:10:33 --> Total execution time: 0.0139
INFO - 2017-03-13 19:11:13 --> Config Class Initialized
INFO - 2017-03-13 19:11:13 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:11:13 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:11:13 --> Utf8 Class Initialized
INFO - 2017-03-13 19:11:13 --> URI Class Initialized
DEBUG - 2017-03-13 19:11:13 --> No URI present. Default controller set.
INFO - 2017-03-13 19:11:13 --> Router Class Initialized
INFO - 2017-03-13 19:11:13 --> Output Class Initialized
INFO - 2017-03-13 19:11:13 --> Security Class Initialized
DEBUG - 2017-03-13 19:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:11:13 --> Input Class Initialized
INFO - 2017-03-13 19:11:13 --> Language Class Initialized
INFO - 2017-03-13 19:11:13 --> Loader Class Initialized
INFO - 2017-03-13 19:11:13 --> Database Driver Class Initialized
INFO - 2017-03-13 19:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:11:13 --> Controller Class Initialized
INFO - 2017-03-13 19:11:13 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:11:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:11:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:11:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:11:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:11:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:11:13 --> Final output sent to browser
DEBUG - 2017-03-13 19:11:13 --> Total execution time: 0.0164
INFO - 2017-03-13 19:11:23 --> Config Class Initialized
INFO - 2017-03-13 19:11:23 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:11:23 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:11:23 --> Utf8 Class Initialized
INFO - 2017-03-13 19:11:23 --> URI Class Initialized
INFO - 2017-03-13 19:11:23 --> Router Class Initialized
INFO - 2017-03-13 19:11:23 --> Output Class Initialized
INFO - 2017-03-13 19:11:23 --> Security Class Initialized
DEBUG - 2017-03-13 19:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:11:23 --> Input Class Initialized
INFO - 2017-03-13 19:11:23 --> Language Class Initialized
INFO - 2017-03-13 19:11:23 --> Loader Class Initialized
INFO - 2017-03-13 19:11:23 --> Database Driver Class Initialized
INFO - 2017-03-13 19:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:11:23 --> Controller Class Initialized
INFO - 2017-03-13 19:11:23 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:11:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-13 19:11:24 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-13 19:11:24 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Miriam Avelar')
INFO - 2017-03-13 19:11:24 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-13 19:11:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-13 19:11:44 --> Config Class Initialized
INFO - 2017-03-13 19:11:44 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:11:44 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:11:44 --> Utf8 Class Initialized
INFO - 2017-03-13 19:11:44 --> URI Class Initialized
DEBUG - 2017-03-13 19:11:44 --> No URI present. Default controller set.
INFO - 2017-03-13 19:11:44 --> Router Class Initialized
INFO - 2017-03-13 19:11:44 --> Output Class Initialized
INFO - 2017-03-13 19:11:44 --> Security Class Initialized
DEBUG - 2017-03-13 19:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:11:44 --> Input Class Initialized
INFO - 2017-03-13 19:11:44 --> Language Class Initialized
INFO - 2017-03-13 19:11:44 --> Loader Class Initialized
INFO - 2017-03-13 19:11:44 --> Database Driver Class Initialized
INFO - 2017-03-13 19:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:11:44 --> Controller Class Initialized
INFO - 2017-03-13 19:11:44 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:11:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:11:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:11:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:11:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:11:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:11:44 --> Final output sent to browser
DEBUG - 2017-03-13 19:11:44 --> Total execution time: 0.0140
INFO - 2017-03-13 19:11:51 --> Config Class Initialized
INFO - 2017-03-13 19:11:51 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:11:51 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:11:51 --> Utf8 Class Initialized
INFO - 2017-03-13 19:11:51 --> URI Class Initialized
INFO - 2017-03-13 19:11:51 --> Router Class Initialized
INFO - 2017-03-13 19:11:51 --> Output Class Initialized
INFO - 2017-03-13 19:11:51 --> Security Class Initialized
DEBUG - 2017-03-13 19:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:11:51 --> Input Class Initialized
INFO - 2017-03-13 19:11:51 --> Language Class Initialized
INFO - 2017-03-13 19:11:51 --> Loader Class Initialized
INFO - 2017-03-13 19:11:51 --> Database Driver Class Initialized
INFO - 2017-03-13 19:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:11:51 --> Controller Class Initialized
INFO - 2017-03-13 19:11:51 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:11:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:11:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:11:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:11:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:11:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:11:51 --> Final output sent to browser
DEBUG - 2017-03-13 19:11:51 --> Total execution time: 0.0141
INFO - 2017-03-13 19:12:03 --> Config Class Initialized
INFO - 2017-03-13 19:12:03 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:12:03 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:12:03 --> Utf8 Class Initialized
INFO - 2017-03-13 19:12:03 --> URI Class Initialized
INFO - 2017-03-13 19:12:03 --> Router Class Initialized
INFO - 2017-03-13 19:12:03 --> Output Class Initialized
INFO - 2017-03-13 19:12:03 --> Security Class Initialized
DEBUG - 2017-03-13 19:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:12:03 --> Input Class Initialized
INFO - 2017-03-13 19:12:03 --> Language Class Initialized
INFO - 2017-03-13 19:12:03 --> Loader Class Initialized
INFO - 2017-03-13 19:12:03 --> Database Driver Class Initialized
INFO - 2017-03-13 19:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:12:03 --> Controller Class Initialized
INFO - 2017-03-13 19:12:03 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:12:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:12:04 --> Config Class Initialized
INFO - 2017-03-13 19:12:04 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:12:04 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:12:04 --> Utf8 Class Initialized
INFO - 2017-03-13 19:12:04 --> URI Class Initialized
INFO - 2017-03-13 19:12:04 --> Router Class Initialized
INFO - 2017-03-13 19:12:04 --> Output Class Initialized
INFO - 2017-03-13 19:12:04 --> Security Class Initialized
DEBUG - 2017-03-13 19:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:12:04 --> Input Class Initialized
INFO - 2017-03-13 19:12:04 --> Language Class Initialized
INFO - 2017-03-13 19:12:04 --> Loader Class Initialized
INFO - 2017-03-13 19:12:04 --> Database Driver Class Initialized
INFO - 2017-03-13 19:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:12:04 --> Controller Class Initialized
INFO - 2017-03-13 19:12:04 --> Helper loaded: date_helper
DEBUG - 2017-03-13 19:12:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:12:04 --> Helper loaded: url_helper
INFO - 2017-03-13 19:12:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:12:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 19:12:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 19:12:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 19:12:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:12:04 --> Final output sent to browser
DEBUG - 2017-03-13 19:12:04 --> Total execution time: 0.0135
INFO - 2017-03-13 19:12:04 --> Config Class Initialized
INFO - 2017-03-13 19:12:04 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:12:04 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:12:04 --> Utf8 Class Initialized
INFO - 2017-03-13 19:12:04 --> URI Class Initialized
INFO - 2017-03-13 19:12:04 --> Router Class Initialized
INFO - 2017-03-13 19:12:04 --> Output Class Initialized
INFO - 2017-03-13 19:12:04 --> Security Class Initialized
DEBUG - 2017-03-13 19:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:12:04 --> Input Class Initialized
INFO - 2017-03-13 19:12:04 --> Language Class Initialized
INFO - 2017-03-13 19:12:04 --> Loader Class Initialized
INFO - 2017-03-13 19:12:04 --> Database Driver Class Initialized
INFO - 2017-03-13 19:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:12:05 --> Controller Class Initialized
INFO - 2017-03-13 19:12:05 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:12:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:12:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:12:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:12:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:12:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:12:05 --> Final output sent to browser
DEBUG - 2017-03-13 19:12:05 --> Total execution time: 0.0200
INFO - 2017-03-13 19:12:13 --> Config Class Initialized
INFO - 2017-03-13 19:12:13 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:12:13 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:12:13 --> Utf8 Class Initialized
INFO - 2017-03-13 19:12:13 --> URI Class Initialized
DEBUG - 2017-03-13 19:12:13 --> No URI present. Default controller set.
INFO - 2017-03-13 19:12:13 --> Router Class Initialized
INFO - 2017-03-13 19:12:13 --> Output Class Initialized
INFO - 2017-03-13 19:12:13 --> Security Class Initialized
DEBUG - 2017-03-13 19:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:12:13 --> Input Class Initialized
INFO - 2017-03-13 19:12:13 --> Language Class Initialized
INFO - 2017-03-13 19:12:13 --> Loader Class Initialized
INFO - 2017-03-13 19:12:13 --> Database Driver Class Initialized
INFO - 2017-03-13 19:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:12:13 --> Controller Class Initialized
INFO - 2017-03-13 19:12:13 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:12:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:12:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:12:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:12:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:12:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:12:13 --> Final output sent to browser
DEBUG - 2017-03-13 19:12:13 --> Total execution time: 0.0140
INFO - 2017-03-13 19:12:14 --> Config Class Initialized
INFO - 2017-03-13 19:12:14 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:12:14 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:12:14 --> Utf8 Class Initialized
INFO - 2017-03-13 19:12:14 --> URI Class Initialized
INFO - 2017-03-13 19:12:14 --> Router Class Initialized
INFO - 2017-03-13 19:12:14 --> Output Class Initialized
INFO - 2017-03-13 19:12:14 --> Security Class Initialized
DEBUG - 2017-03-13 19:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:12:14 --> Input Class Initialized
INFO - 2017-03-13 19:12:14 --> Language Class Initialized
INFO - 2017-03-13 19:12:14 --> Loader Class Initialized
INFO - 2017-03-13 19:12:14 --> Database Driver Class Initialized
INFO - 2017-03-13 19:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:12:14 --> Controller Class Initialized
INFO - 2017-03-13 19:12:14 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:12:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:12:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:12:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:12:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:12:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:12:14 --> Final output sent to browser
DEBUG - 2017-03-13 19:12:14 --> Total execution time: 0.0478
INFO - 2017-03-13 19:14:36 --> Config Class Initialized
INFO - 2017-03-13 19:14:36 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:14:36 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:14:36 --> Utf8 Class Initialized
INFO - 2017-03-13 19:14:36 --> URI Class Initialized
DEBUG - 2017-03-13 19:14:36 --> No URI present. Default controller set.
INFO - 2017-03-13 19:14:36 --> Router Class Initialized
INFO - 2017-03-13 19:14:36 --> Output Class Initialized
INFO - 2017-03-13 19:14:36 --> Security Class Initialized
DEBUG - 2017-03-13 19:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:14:36 --> Input Class Initialized
INFO - 2017-03-13 19:14:36 --> Language Class Initialized
INFO - 2017-03-13 19:14:36 --> Loader Class Initialized
INFO - 2017-03-13 19:14:36 --> Database Driver Class Initialized
INFO - 2017-03-13 19:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:14:36 --> Controller Class Initialized
INFO - 2017-03-13 19:14:36 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:14:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:14:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:14:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:14:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:14:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:14:36 --> Final output sent to browser
DEBUG - 2017-03-13 19:14:36 --> Total execution time: 0.0158
INFO - 2017-03-13 19:14:38 --> Config Class Initialized
INFO - 2017-03-13 19:14:38 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:14:38 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:14:38 --> Utf8 Class Initialized
INFO - 2017-03-13 19:14:38 --> URI Class Initialized
DEBUG - 2017-03-13 19:14:38 --> No URI present. Default controller set.
INFO - 2017-03-13 19:14:38 --> Router Class Initialized
INFO - 2017-03-13 19:14:38 --> Output Class Initialized
INFO - 2017-03-13 19:14:38 --> Security Class Initialized
DEBUG - 2017-03-13 19:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:14:38 --> Input Class Initialized
INFO - 2017-03-13 19:14:38 --> Language Class Initialized
INFO - 2017-03-13 19:14:38 --> Loader Class Initialized
INFO - 2017-03-13 19:14:38 --> Database Driver Class Initialized
INFO - 2017-03-13 19:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:14:38 --> Controller Class Initialized
INFO - 2017-03-13 19:14:38 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:14:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:14:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:14:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:14:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:14:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:14:38 --> Final output sent to browser
DEBUG - 2017-03-13 19:14:38 --> Total execution time: 0.0165
INFO - 2017-03-13 19:15:53 --> Config Class Initialized
INFO - 2017-03-13 19:15:53 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:15:53 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:15:53 --> Utf8 Class Initialized
INFO - 2017-03-13 19:15:53 --> URI Class Initialized
DEBUG - 2017-03-13 19:15:53 --> No URI present. Default controller set.
INFO - 2017-03-13 19:15:53 --> Router Class Initialized
INFO - 2017-03-13 19:15:53 --> Output Class Initialized
INFO - 2017-03-13 19:15:53 --> Security Class Initialized
DEBUG - 2017-03-13 19:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:15:53 --> Input Class Initialized
INFO - 2017-03-13 19:15:53 --> Language Class Initialized
INFO - 2017-03-13 19:15:53 --> Loader Class Initialized
INFO - 2017-03-13 19:15:53 --> Database Driver Class Initialized
INFO - 2017-03-13 19:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:15:53 --> Controller Class Initialized
INFO - 2017-03-13 19:15:53 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:15:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:15:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:15:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:15:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:15:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:15:53 --> Final output sent to browser
DEBUG - 2017-03-13 19:15:53 --> Total execution time: 0.0650
INFO - 2017-03-13 19:15:59 --> Config Class Initialized
INFO - 2017-03-13 19:15:59 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:15:59 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:15:59 --> Utf8 Class Initialized
INFO - 2017-03-13 19:15:59 --> URI Class Initialized
INFO - 2017-03-13 19:15:59 --> Router Class Initialized
INFO - 2017-03-13 19:15:59 --> Output Class Initialized
INFO - 2017-03-13 19:15:59 --> Security Class Initialized
DEBUG - 2017-03-13 19:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:15:59 --> Input Class Initialized
INFO - 2017-03-13 19:15:59 --> Language Class Initialized
INFO - 2017-03-13 19:15:59 --> Loader Class Initialized
INFO - 2017-03-13 19:15:59 --> Database Driver Class Initialized
INFO - 2017-03-13 19:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:15:59 --> Controller Class Initialized
INFO - 2017-03-13 19:15:59 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:15:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:15:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:15:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:15:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:15:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:15:59 --> Final output sent to browser
DEBUG - 2017-03-13 19:15:59 --> Total execution time: 0.0135
INFO - 2017-03-13 19:16:02 --> Config Class Initialized
INFO - 2017-03-13 19:16:02 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:16:02 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:16:02 --> Utf8 Class Initialized
INFO - 2017-03-13 19:16:02 --> URI Class Initialized
INFO - 2017-03-13 19:16:02 --> Router Class Initialized
INFO - 2017-03-13 19:16:02 --> Output Class Initialized
INFO - 2017-03-13 19:16:02 --> Security Class Initialized
DEBUG - 2017-03-13 19:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:16:02 --> Input Class Initialized
INFO - 2017-03-13 19:16:02 --> Language Class Initialized
INFO - 2017-03-13 19:16:02 --> Loader Class Initialized
INFO - 2017-03-13 19:16:02 --> Database Driver Class Initialized
INFO - 2017-03-13 19:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:16:03 --> Controller Class Initialized
INFO - 2017-03-13 19:16:03 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:16:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:16:04 --> Config Class Initialized
INFO - 2017-03-13 19:16:04 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:16:04 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:16:04 --> Utf8 Class Initialized
INFO - 2017-03-13 19:16:04 --> URI Class Initialized
INFO - 2017-03-13 19:16:04 --> Router Class Initialized
INFO - 2017-03-13 19:16:04 --> Output Class Initialized
INFO - 2017-03-13 19:16:04 --> Security Class Initialized
DEBUG - 2017-03-13 19:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:16:04 --> Input Class Initialized
INFO - 2017-03-13 19:16:04 --> Language Class Initialized
INFO - 2017-03-13 19:16:04 --> Loader Class Initialized
INFO - 2017-03-13 19:16:04 --> Database Driver Class Initialized
INFO - 2017-03-13 19:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:16:04 --> Controller Class Initialized
INFO - 2017-03-13 19:16:04 --> Helper loaded: date_helper
DEBUG - 2017-03-13 19:16:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:16:04 --> Helper loaded: url_helper
INFO - 2017-03-13 19:16:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:16:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 19:16:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 19:16:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 19:16:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:16:04 --> Final output sent to browser
DEBUG - 2017-03-13 19:16:04 --> Total execution time: 0.0138
INFO - 2017-03-13 19:16:05 --> Config Class Initialized
INFO - 2017-03-13 19:16:05 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:16:05 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:16:05 --> Utf8 Class Initialized
INFO - 2017-03-13 19:16:05 --> URI Class Initialized
INFO - 2017-03-13 19:16:05 --> Router Class Initialized
INFO - 2017-03-13 19:16:05 --> Output Class Initialized
INFO - 2017-03-13 19:16:05 --> Security Class Initialized
DEBUG - 2017-03-13 19:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:16:05 --> Input Class Initialized
INFO - 2017-03-13 19:16:05 --> Language Class Initialized
INFO - 2017-03-13 19:16:05 --> Loader Class Initialized
INFO - 2017-03-13 19:16:05 --> Database Driver Class Initialized
INFO - 2017-03-13 19:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:16:05 --> Controller Class Initialized
INFO - 2017-03-13 19:16:05 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:16:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:16:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:16:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:16:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:16:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:16:05 --> Final output sent to browser
DEBUG - 2017-03-13 19:16:05 --> Total execution time: 0.0197
INFO - 2017-03-13 19:16:12 --> Config Class Initialized
INFO - 2017-03-13 19:16:12 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:16:12 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:16:12 --> Utf8 Class Initialized
INFO - 2017-03-13 19:16:12 --> URI Class Initialized
DEBUG - 2017-03-13 19:16:12 --> No URI present. Default controller set.
INFO - 2017-03-13 19:16:12 --> Router Class Initialized
INFO - 2017-03-13 19:16:12 --> Output Class Initialized
INFO - 2017-03-13 19:16:12 --> Security Class Initialized
DEBUG - 2017-03-13 19:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:16:12 --> Input Class Initialized
INFO - 2017-03-13 19:16:12 --> Language Class Initialized
INFO - 2017-03-13 19:16:12 --> Loader Class Initialized
INFO - 2017-03-13 19:16:12 --> Database Driver Class Initialized
INFO - 2017-03-13 19:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:16:12 --> Controller Class Initialized
INFO - 2017-03-13 19:16:12 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:16:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:16:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:16:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:16:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:16:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:16:12 --> Final output sent to browser
DEBUG - 2017-03-13 19:16:12 --> Total execution time: 0.0230
INFO - 2017-03-13 19:16:14 --> Config Class Initialized
INFO - 2017-03-13 19:16:14 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:16:14 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:16:14 --> Utf8 Class Initialized
INFO - 2017-03-13 19:16:14 --> URI Class Initialized
INFO - 2017-03-13 19:16:14 --> Router Class Initialized
INFO - 2017-03-13 19:16:14 --> Output Class Initialized
INFO - 2017-03-13 19:16:14 --> Security Class Initialized
DEBUG - 2017-03-13 19:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:16:14 --> Input Class Initialized
INFO - 2017-03-13 19:16:14 --> Language Class Initialized
INFO - 2017-03-13 19:16:14 --> Loader Class Initialized
INFO - 2017-03-13 19:16:14 --> Database Driver Class Initialized
INFO - 2017-03-13 19:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:16:14 --> Controller Class Initialized
INFO - 2017-03-13 19:16:14 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:16:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:16:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:16:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:16:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:16:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:16:14 --> Final output sent to browser
DEBUG - 2017-03-13 19:16:14 --> Total execution time: 0.0143
INFO - 2017-03-13 19:16:59 --> Config Class Initialized
INFO - 2017-03-13 19:16:59 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:16:59 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:16:59 --> Utf8 Class Initialized
INFO - 2017-03-13 19:16:59 --> URI Class Initialized
INFO - 2017-03-13 19:16:59 --> Router Class Initialized
INFO - 2017-03-13 19:16:59 --> Output Class Initialized
INFO - 2017-03-13 19:16:59 --> Security Class Initialized
DEBUG - 2017-03-13 19:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:16:59 --> Input Class Initialized
INFO - 2017-03-13 19:16:59 --> Language Class Initialized
INFO - 2017-03-13 19:16:59 --> Loader Class Initialized
INFO - 2017-03-13 19:16:59 --> Database Driver Class Initialized
INFO - 2017-03-13 19:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:17:00 --> Controller Class Initialized
INFO - 2017-03-13 19:17:00 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:17:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:17:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:17:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:17:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:17:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:17:00 --> Final output sent to browser
DEBUG - 2017-03-13 19:17:00 --> Total execution time: 0.0153
INFO - 2017-03-13 19:17:02 --> Config Class Initialized
INFO - 2017-03-13 19:17:02 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:17:02 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:17:02 --> Utf8 Class Initialized
INFO - 2017-03-13 19:17:02 --> URI Class Initialized
INFO - 2017-03-13 19:17:02 --> Router Class Initialized
INFO - 2017-03-13 19:17:02 --> Output Class Initialized
INFO - 2017-03-13 19:17:02 --> Security Class Initialized
DEBUG - 2017-03-13 19:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:17:02 --> Input Class Initialized
INFO - 2017-03-13 19:17:02 --> Language Class Initialized
INFO - 2017-03-13 19:17:02 --> Loader Class Initialized
INFO - 2017-03-13 19:17:02 --> Database Driver Class Initialized
INFO - 2017-03-13 19:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:17:02 --> Controller Class Initialized
INFO - 2017-03-13 19:17:02 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:17:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:17:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:17:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:17:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:17:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:17:02 --> Final output sent to browser
DEBUG - 2017-03-13 19:17:02 --> Total execution time: 0.0132
INFO - 2017-03-13 19:17:04 --> Config Class Initialized
INFO - 2017-03-13 19:17:04 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:17:04 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:17:04 --> Utf8 Class Initialized
INFO - 2017-03-13 19:17:04 --> URI Class Initialized
DEBUG - 2017-03-13 19:17:04 --> No URI present. Default controller set.
INFO - 2017-03-13 19:17:04 --> Router Class Initialized
INFO - 2017-03-13 19:17:04 --> Output Class Initialized
INFO - 2017-03-13 19:17:04 --> Security Class Initialized
DEBUG - 2017-03-13 19:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:17:04 --> Input Class Initialized
INFO - 2017-03-13 19:17:04 --> Language Class Initialized
INFO - 2017-03-13 19:17:04 --> Loader Class Initialized
INFO - 2017-03-13 19:17:04 --> Database Driver Class Initialized
INFO - 2017-03-13 19:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:17:04 --> Controller Class Initialized
INFO - 2017-03-13 19:17:04 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:17:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:17:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:17:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:17:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:17:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:17:04 --> Final output sent to browser
DEBUG - 2017-03-13 19:17:04 --> Total execution time: 0.0141
INFO - 2017-03-13 19:17:05 --> Config Class Initialized
INFO - 2017-03-13 19:17:05 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:17:05 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:17:05 --> Utf8 Class Initialized
INFO - 2017-03-13 19:17:05 --> URI Class Initialized
INFO - 2017-03-13 19:17:05 --> Router Class Initialized
INFO - 2017-03-13 19:17:05 --> Output Class Initialized
INFO - 2017-03-13 19:17:05 --> Security Class Initialized
DEBUG - 2017-03-13 19:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:17:05 --> Input Class Initialized
INFO - 2017-03-13 19:17:05 --> Language Class Initialized
INFO - 2017-03-13 19:17:05 --> Loader Class Initialized
INFO - 2017-03-13 19:17:05 --> Database Driver Class Initialized
INFO - 2017-03-13 19:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:17:05 --> Controller Class Initialized
INFO - 2017-03-13 19:17:05 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:17:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:17:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:17:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:17:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:17:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:17:05 --> Final output sent to browser
DEBUG - 2017-03-13 19:17:05 --> Total execution time: 0.0144
INFO - 2017-03-13 19:17:22 --> Config Class Initialized
INFO - 2017-03-13 19:17:22 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:17:22 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:17:22 --> Utf8 Class Initialized
INFO - 2017-03-13 19:17:22 --> URI Class Initialized
INFO - 2017-03-13 19:17:22 --> Router Class Initialized
INFO - 2017-03-13 19:17:22 --> Output Class Initialized
INFO - 2017-03-13 19:17:22 --> Security Class Initialized
DEBUG - 2017-03-13 19:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:17:22 --> Input Class Initialized
INFO - 2017-03-13 19:17:22 --> Language Class Initialized
INFO - 2017-03-13 19:17:22 --> Loader Class Initialized
INFO - 2017-03-13 19:17:22 --> Database Driver Class Initialized
INFO - 2017-03-13 19:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:17:22 --> Controller Class Initialized
INFO - 2017-03-13 19:17:22 --> Helper loaded: date_helper
DEBUG - 2017-03-13 19:17:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:17:22 --> Helper loaded: url_helper
INFO - 2017-03-13 19:17:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:17:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 19:17:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 19:17:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 19:17:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:17:22 --> Final output sent to browser
DEBUG - 2017-03-13 19:17:22 --> Total execution time: 0.0137
INFO - 2017-03-13 19:17:24 --> Config Class Initialized
INFO - 2017-03-13 19:17:24 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:17:24 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:17:24 --> Utf8 Class Initialized
INFO - 2017-03-13 19:17:24 --> URI Class Initialized
INFO - 2017-03-13 19:17:24 --> Router Class Initialized
INFO - 2017-03-13 19:17:24 --> Output Class Initialized
INFO - 2017-03-13 19:17:24 --> Security Class Initialized
DEBUG - 2017-03-13 19:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:17:24 --> Input Class Initialized
INFO - 2017-03-13 19:17:24 --> Language Class Initialized
INFO - 2017-03-13 19:17:24 --> Loader Class Initialized
INFO - 2017-03-13 19:17:24 --> Database Driver Class Initialized
INFO - 2017-03-13 19:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:17:24 --> Controller Class Initialized
INFO - 2017-03-13 19:17:24 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:17:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:17:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:17:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:17:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:17:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:17:24 --> Final output sent to browser
DEBUG - 2017-03-13 19:17:24 --> Total execution time: 0.0140
INFO - 2017-03-13 19:18:53 --> Config Class Initialized
INFO - 2017-03-13 19:18:53 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:18:53 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:18:53 --> Utf8 Class Initialized
INFO - 2017-03-13 19:18:53 --> URI Class Initialized
DEBUG - 2017-03-13 19:18:53 --> No URI present. Default controller set.
INFO - 2017-03-13 19:18:53 --> Router Class Initialized
INFO - 2017-03-13 19:18:53 --> Output Class Initialized
INFO - 2017-03-13 19:18:53 --> Security Class Initialized
DEBUG - 2017-03-13 19:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:18:53 --> Input Class Initialized
INFO - 2017-03-13 19:18:53 --> Language Class Initialized
INFO - 2017-03-13 19:18:53 --> Loader Class Initialized
INFO - 2017-03-13 19:18:53 --> Database Driver Class Initialized
INFO - 2017-03-13 19:18:53 --> Config Class Initialized
INFO - 2017-03-13 19:18:53 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:18:53 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:18:53 --> Utf8 Class Initialized
INFO - 2017-03-13 19:18:53 --> URI Class Initialized
INFO - 2017-03-13 19:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:18:53 --> Controller Class Initialized
INFO - 2017-03-13 19:18:53 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:18:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:18:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:18:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:18:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:18:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:18:53 --> Final output sent to browser
DEBUG - 2017-03-13 19:18:53 --> Total execution time: 0.0931
DEBUG - 2017-03-13 19:18:53 --> No URI present. Default controller set.
INFO - 2017-03-13 19:18:53 --> Router Class Initialized
INFO - 2017-03-13 19:18:53 --> Output Class Initialized
INFO - 2017-03-13 19:18:53 --> Security Class Initialized
DEBUG - 2017-03-13 19:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:18:53 --> Input Class Initialized
INFO - 2017-03-13 19:18:53 --> Language Class Initialized
INFO - 2017-03-13 19:18:53 --> Loader Class Initialized
INFO - 2017-03-13 19:18:53 --> Database Driver Class Initialized
INFO - 2017-03-13 19:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:18:54 --> Controller Class Initialized
INFO - 2017-03-13 19:18:54 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:18:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:18:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:18:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:18:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:18:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:18:54 --> Final output sent to browser
DEBUG - 2017-03-13 19:18:54 --> Total execution time: 0.0229
INFO - 2017-03-13 19:19:32 --> Config Class Initialized
INFO - 2017-03-13 19:19:32 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:19:32 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:19:32 --> Utf8 Class Initialized
INFO - 2017-03-13 19:19:32 --> URI Class Initialized
INFO - 2017-03-13 19:19:32 --> Router Class Initialized
INFO - 2017-03-13 19:19:32 --> Output Class Initialized
INFO - 2017-03-13 19:19:32 --> Security Class Initialized
DEBUG - 2017-03-13 19:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:19:32 --> Input Class Initialized
INFO - 2017-03-13 19:19:32 --> Language Class Initialized
INFO - 2017-03-13 19:19:32 --> Loader Class Initialized
INFO - 2017-03-13 19:19:32 --> Database Driver Class Initialized
INFO - 2017-03-13 19:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:19:32 --> Controller Class Initialized
INFO - 2017-03-13 19:19:32 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:19:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:19:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:19:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:19:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:19:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:19:32 --> Final output sent to browser
DEBUG - 2017-03-13 19:19:32 --> Total execution time: 0.0143
INFO - 2017-03-13 19:20:18 --> Config Class Initialized
INFO - 2017-03-13 19:20:18 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:20:18 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:20:18 --> Utf8 Class Initialized
INFO - 2017-03-13 19:20:18 --> URI Class Initialized
DEBUG - 2017-03-13 19:20:18 --> No URI present. Default controller set.
INFO - 2017-03-13 19:20:18 --> Router Class Initialized
INFO - 2017-03-13 19:20:18 --> Output Class Initialized
INFO - 2017-03-13 19:20:18 --> Security Class Initialized
DEBUG - 2017-03-13 19:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:20:18 --> Input Class Initialized
INFO - 2017-03-13 19:20:18 --> Language Class Initialized
INFO - 2017-03-13 19:20:18 --> Loader Class Initialized
INFO - 2017-03-13 19:20:18 --> Database Driver Class Initialized
INFO - 2017-03-13 19:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:20:18 --> Controller Class Initialized
INFO - 2017-03-13 19:20:18 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:20:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:20:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:20:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:20:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:20:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:20:18 --> Final output sent to browser
DEBUG - 2017-03-13 19:20:18 --> Total execution time: 0.0133
INFO - 2017-03-13 19:20:34 --> Config Class Initialized
INFO - 2017-03-13 19:20:34 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:20:34 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:20:34 --> Utf8 Class Initialized
INFO - 2017-03-13 19:20:34 --> URI Class Initialized
INFO - 2017-03-13 19:20:34 --> Router Class Initialized
INFO - 2017-03-13 19:20:34 --> Output Class Initialized
INFO - 2017-03-13 19:20:34 --> Security Class Initialized
DEBUG - 2017-03-13 19:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:20:34 --> Input Class Initialized
INFO - 2017-03-13 19:20:34 --> Language Class Initialized
INFO - 2017-03-13 19:20:34 --> Loader Class Initialized
INFO - 2017-03-13 19:20:34 --> Database Driver Class Initialized
INFO - 2017-03-13 19:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:20:34 --> Controller Class Initialized
INFO - 2017-03-13 19:20:34 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:20:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:20:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:20:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:20:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:20:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:20:34 --> Final output sent to browser
DEBUG - 2017-03-13 19:20:34 --> Total execution time: 0.0139
INFO - 2017-03-13 19:20:44 --> Config Class Initialized
INFO - 2017-03-13 19:20:44 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:20:44 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:20:44 --> Utf8 Class Initialized
INFO - 2017-03-13 19:20:44 --> URI Class Initialized
INFO - 2017-03-13 19:20:44 --> Router Class Initialized
INFO - 2017-03-13 19:20:44 --> Output Class Initialized
INFO - 2017-03-13 19:20:44 --> Security Class Initialized
DEBUG - 2017-03-13 19:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:20:44 --> Input Class Initialized
INFO - 2017-03-13 19:20:44 --> Language Class Initialized
INFO - 2017-03-13 19:20:44 --> Loader Class Initialized
INFO - 2017-03-13 19:20:44 --> Database Driver Class Initialized
INFO - 2017-03-13 19:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:20:44 --> Controller Class Initialized
INFO - 2017-03-13 19:20:44 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:20:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:20:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:20:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:20:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:20:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:20:44 --> Final output sent to browser
DEBUG - 2017-03-13 19:20:44 --> Total execution time: 0.0146
INFO - 2017-03-13 19:21:10 --> Config Class Initialized
INFO - 2017-03-13 19:21:10 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:21:10 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:21:10 --> Utf8 Class Initialized
INFO - 2017-03-13 19:21:10 --> URI Class Initialized
INFO - 2017-03-13 19:21:10 --> Router Class Initialized
INFO - 2017-03-13 19:21:10 --> Output Class Initialized
INFO - 2017-03-13 19:21:10 --> Security Class Initialized
DEBUG - 2017-03-13 19:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:21:10 --> Input Class Initialized
INFO - 2017-03-13 19:21:10 --> Language Class Initialized
INFO - 2017-03-13 19:21:10 --> Loader Class Initialized
INFO - 2017-03-13 19:21:10 --> Database Driver Class Initialized
INFO - 2017-03-13 19:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:21:10 --> Controller Class Initialized
INFO - 2017-03-13 19:21:10 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:21:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:21:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:21:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:21:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:21:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:21:10 --> Final output sent to browser
DEBUG - 2017-03-13 19:21:10 --> Total execution time: 0.0146
INFO - 2017-03-13 19:21:28 --> Config Class Initialized
INFO - 2017-03-13 19:21:28 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:21:28 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:21:28 --> Utf8 Class Initialized
INFO - 2017-03-13 19:21:28 --> URI Class Initialized
INFO - 2017-03-13 19:21:28 --> Router Class Initialized
INFO - 2017-03-13 19:21:28 --> Output Class Initialized
INFO - 2017-03-13 19:21:28 --> Security Class Initialized
DEBUG - 2017-03-13 19:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:21:28 --> Input Class Initialized
INFO - 2017-03-13 19:21:28 --> Language Class Initialized
INFO - 2017-03-13 19:21:28 --> Loader Class Initialized
INFO - 2017-03-13 19:21:28 --> Database Driver Class Initialized
INFO - 2017-03-13 19:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:21:28 --> Controller Class Initialized
INFO - 2017-03-13 19:21:28 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:21:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:21:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:21:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:21:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:21:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:21:28 --> Final output sent to browser
DEBUG - 2017-03-13 19:21:28 --> Total execution time: 0.0149
INFO - 2017-03-13 19:22:34 --> Config Class Initialized
INFO - 2017-03-13 19:22:34 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:22:34 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:22:34 --> Utf8 Class Initialized
INFO - 2017-03-13 19:22:34 --> URI Class Initialized
DEBUG - 2017-03-13 19:22:34 --> No URI present. Default controller set.
INFO - 2017-03-13 19:22:34 --> Router Class Initialized
INFO - 2017-03-13 19:22:34 --> Output Class Initialized
INFO - 2017-03-13 19:22:34 --> Security Class Initialized
DEBUG - 2017-03-13 19:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:22:34 --> Input Class Initialized
INFO - 2017-03-13 19:22:34 --> Language Class Initialized
INFO - 2017-03-13 19:22:34 --> Loader Class Initialized
INFO - 2017-03-13 19:22:34 --> Database Driver Class Initialized
INFO - 2017-03-13 19:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:22:34 --> Controller Class Initialized
INFO - 2017-03-13 19:22:34 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:22:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:22:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:22:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:22:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:22:34 --> Final output sent to browser
DEBUG - 2017-03-13 19:22:34 --> Total execution time: 0.0132
INFO - 2017-03-13 19:22:43 --> Config Class Initialized
INFO - 2017-03-13 19:22:43 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:22:43 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:22:43 --> Utf8 Class Initialized
INFO - 2017-03-13 19:22:43 --> URI Class Initialized
INFO - 2017-03-13 19:22:43 --> Router Class Initialized
INFO - 2017-03-13 19:22:43 --> Output Class Initialized
INFO - 2017-03-13 19:22:43 --> Security Class Initialized
DEBUG - 2017-03-13 19:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:22:43 --> Input Class Initialized
INFO - 2017-03-13 19:22:43 --> Language Class Initialized
INFO - 2017-03-13 19:22:43 --> Loader Class Initialized
INFO - 2017-03-13 19:22:43 --> Database Driver Class Initialized
INFO - 2017-03-13 19:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:22:43 --> Controller Class Initialized
INFO - 2017-03-13 19:22:43 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:22:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:22:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:22:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:22:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:22:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:22:43 --> Final output sent to browser
DEBUG - 2017-03-13 19:22:43 --> Total execution time: 0.0147
INFO - 2017-03-13 19:23:33 --> Config Class Initialized
INFO - 2017-03-13 19:23:33 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:23:33 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:23:33 --> Utf8 Class Initialized
INFO - 2017-03-13 19:23:33 --> URI Class Initialized
INFO - 2017-03-13 19:23:33 --> Router Class Initialized
INFO - 2017-03-13 19:23:33 --> Output Class Initialized
INFO - 2017-03-13 19:23:33 --> Security Class Initialized
DEBUG - 2017-03-13 19:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:23:33 --> Input Class Initialized
INFO - 2017-03-13 19:23:33 --> Language Class Initialized
INFO - 2017-03-13 19:23:33 --> Loader Class Initialized
INFO - 2017-03-13 19:23:33 --> Database Driver Class Initialized
INFO - 2017-03-13 19:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:23:33 --> Controller Class Initialized
INFO - 2017-03-13 19:23:33 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:23:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-13 19:23:34 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-13 19:23:34 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Alejandro Argüelles Perez')
INFO - 2017-03-13 19:23:34 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-13 19:23:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-13 19:23:34 --> Config Class Initialized
INFO - 2017-03-13 19:23:34 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:23:34 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:23:34 --> Utf8 Class Initialized
INFO - 2017-03-13 19:23:34 --> URI Class Initialized
INFO - 2017-03-13 19:23:34 --> Router Class Initialized
INFO - 2017-03-13 19:23:34 --> Output Class Initialized
INFO - 2017-03-13 19:23:34 --> Security Class Initialized
DEBUG - 2017-03-13 19:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:23:34 --> Input Class Initialized
INFO - 2017-03-13 19:23:34 --> Language Class Initialized
INFO - 2017-03-13 19:23:34 --> Loader Class Initialized
INFO - 2017-03-13 19:23:34 --> Database Driver Class Initialized
INFO - 2017-03-13 19:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:23:34 --> Controller Class Initialized
INFO - 2017-03-13 19:23:34 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:23:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:23:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:23:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:23:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:23:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:23:34 --> Final output sent to browser
DEBUG - 2017-03-13 19:23:34 --> Total execution time: 0.0133
INFO - 2017-03-13 19:23:55 --> Config Class Initialized
INFO - 2017-03-13 19:23:55 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:23:55 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:23:55 --> Utf8 Class Initialized
INFO - 2017-03-13 19:23:55 --> URI Class Initialized
INFO - 2017-03-13 19:23:55 --> Router Class Initialized
INFO - 2017-03-13 19:23:55 --> Output Class Initialized
INFO - 2017-03-13 19:23:55 --> Security Class Initialized
DEBUG - 2017-03-13 19:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:23:55 --> Input Class Initialized
INFO - 2017-03-13 19:23:55 --> Language Class Initialized
INFO - 2017-03-13 19:23:55 --> Loader Class Initialized
INFO - 2017-03-13 19:23:55 --> Database Driver Class Initialized
INFO - 2017-03-13 19:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:23:55 --> Controller Class Initialized
INFO - 2017-03-13 19:23:55 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:23:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-13 19:23:56 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-13 19:23:56 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Alejandro Argüelles Perez')
INFO - 2017-03-13 19:23:56 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-13 19:23:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-13 19:23:56 --> Config Class Initialized
INFO - 2017-03-13 19:23:56 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:23:56 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:23:56 --> Utf8 Class Initialized
INFO - 2017-03-13 19:23:56 --> URI Class Initialized
INFO - 2017-03-13 19:23:56 --> Router Class Initialized
INFO - 2017-03-13 19:23:56 --> Output Class Initialized
INFO - 2017-03-13 19:23:56 --> Security Class Initialized
DEBUG - 2017-03-13 19:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:23:56 --> Input Class Initialized
INFO - 2017-03-13 19:23:56 --> Language Class Initialized
INFO - 2017-03-13 19:23:56 --> Loader Class Initialized
INFO - 2017-03-13 19:23:56 --> Database Driver Class Initialized
INFO - 2017-03-13 19:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:23:56 --> Controller Class Initialized
INFO - 2017-03-13 19:23:56 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:23:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:23:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:23:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:23:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:23:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:23:56 --> Final output sent to browser
DEBUG - 2017-03-13 19:23:56 --> Total execution time: 0.0132
INFO - 2017-03-13 19:27:40 --> Config Class Initialized
INFO - 2017-03-13 19:27:40 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:27:40 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:27:40 --> Utf8 Class Initialized
INFO - 2017-03-13 19:27:40 --> URI Class Initialized
DEBUG - 2017-03-13 19:27:40 --> No URI present. Default controller set.
INFO - 2017-03-13 19:27:40 --> Router Class Initialized
INFO - 2017-03-13 19:27:40 --> Output Class Initialized
INFO - 2017-03-13 19:27:40 --> Security Class Initialized
DEBUG - 2017-03-13 19:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:27:40 --> Input Class Initialized
INFO - 2017-03-13 19:27:40 --> Language Class Initialized
INFO - 2017-03-13 19:27:40 --> Loader Class Initialized
INFO - 2017-03-13 19:27:40 --> Database Driver Class Initialized
INFO - 2017-03-13 19:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:27:40 --> Controller Class Initialized
INFO - 2017-03-13 19:27:40 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:27:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:27:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:27:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:27:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:27:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:27:40 --> Final output sent to browser
DEBUG - 2017-03-13 19:27:40 --> Total execution time: 0.0150
INFO - 2017-03-13 19:28:56 --> Config Class Initialized
INFO - 2017-03-13 19:28:56 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:28:56 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:28:56 --> Utf8 Class Initialized
INFO - 2017-03-13 19:28:56 --> URI Class Initialized
INFO - 2017-03-13 19:28:56 --> Router Class Initialized
INFO - 2017-03-13 19:28:56 --> Output Class Initialized
INFO - 2017-03-13 19:28:56 --> Security Class Initialized
DEBUG - 2017-03-13 19:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:28:56 --> Input Class Initialized
INFO - 2017-03-13 19:28:56 --> Language Class Initialized
INFO - 2017-03-13 19:28:56 --> Loader Class Initialized
INFO - 2017-03-13 19:28:56 --> Database Driver Class Initialized
INFO - 2017-03-13 19:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:28:56 --> Controller Class Initialized
INFO - 2017-03-13 19:28:56 --> Helper loaded: date_helper
DEBUG - 2017-03-13 19:28:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:28:56 --> Helper loaded: url_helper
INFO - 2017-03-13 19:28:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:28:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 19:28:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 19:28:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 19:28:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:28:56 --> Final output sent to browser
DEBUG - 2017-03-13 19:28:56 --> Total execution time: 0.0133
INFO - 2017-03-13 19:30:17 --> Config Class Initialized
INFO - 2017-03-13 19:30:17 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:30:17 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:30:17 --> Utf8 Class Initialized
INFO - 2017-03-13 19:30:17 --> URI Class Initialized
DEBUG - 2017-03-13 19:30:17 --> No URI present. Default controller set.
INFO - 2017-03-13 19:30:17 --> Router Class Initialized
INFO - 2017-03-13 19:30:17 --> Output Class Initialized
INFO - 2017-03-13 19:30:17 --> Security Class Initialized
DEBUG - 2017-03-13 19:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:30:17 --> Input Class Initialized
INFO - 2017-03-13 19:30:17 --> Language Class Initialized
INFO - 2017-03-13 19:30:17 --> Loader Class Initialized
INFO - 2017-03-13 19:30:17 --> Database Driver Class Initialized
INFO - 2017-03-13 19:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:30:17 --> Controller Class Initialized
INFO - 2017-03-13 19:30:17 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:30:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:30:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:30:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:30:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:30:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:30:17 --> Final output sent to browser
DEBUG - 2017-03-13 19:30:17 --> Total execution time: 0.0139
INFO - 2017-03-13 19:30:21 --> Config Class Initialized
INFO - 2017-03-13 19:30:21 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:30:21 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:30:21 --> Utf8 Class Initialized
INFO - 2017-03-13 19:30:21 --> URI Class Initialized
INFO - 2017-03-13 19:30:21 --> Router Class Initialized
INFO - 2017-03-13 19:30:21 --> Output Class Initialized
INFO - 2017-03-13 19:30:21 --> Security Class Initialized
DEBUG - 2017-03-13 19:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:30:21 --> Input Class Initialized
INFO - 2017-03-13 19:30:21 --> Language Class Initialized
INFO - 2017-03-13 19:30:21 --> Loader Class Initialized
INFO - 2017-03-13 19:30:21 --> Database Driver Class Initialized
INFO - 2017-03-13 19:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:30:21 --> Controller Class Initialized
INFO - 2017-03-13 19:30:21 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:30:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:30:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:30:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:30:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:30:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:30:21 --> Final output sent to browser
DEBUG - 2017-03-13 19:30:21 --> Total execution time: 0.0133
INFO - 2017-03-13 19:30:30 --> Config Class Initialized
INFO - 2017-03-13 19:30:30 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:30:30 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:30:30 --> Utf8 Class Initialized
INFO - 2017-03-13 19:30:30 --> URI Class Initialized
INFO - 2017-03-13 19:30:30 --> Router Class Initialized
INFO - 2017-03-13 19:30:30 --> Output Class Initialized
INFO - 2017-03-13 19:30:30 --> Security Class Initialized
DEBUG - 2017-03-13 19:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:30:30 --> Input Class Initialized
INFO - 2017-03-13 19:30:30 --> Language Class Initialized
INFO - 2017-03-13 19:30:30 --> Loader Class Initialized
INFO - 2017-03-13 19:30:30 --> Database Driver Class Initialized
INFO - 2017-03-13 19:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:30:30 --> Controller Class Initialized
INFO - 2017-03-13 19:30:30 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:30:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:30:32 --> Config Class Initialized
INFO - 2017-03-13 19:30:32 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:30:32 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:30:32 --> Utf8 Class Initialized
INFO - 2017-03-13 19:30:32 --> URI Class Initialized
INFO - 2017-03-13 19:30:32 --> Router Class Initialized
INFO - 2017-03-13 19:30:32 --> Output Class Initialized
INFO - 2017-03-13 19:30:32 --> Security Class Initialized
DEBUG - 2017-03-13 19:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:30:32 --> Input Class Initialized
INFO - 2017-03-13 19:30:32 --> Language Class Initialized
INFO - 2017-03-13 19:30:32 --> Loader Class Initialized
INFO - 2017-03-13 19:30:32 --> Database Driver Class Initialized
INFO - 2017-03-13 19:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:30:32 --> Controller Class Initialized
INFO - 2017-03-13 19:30:32 --> Helper loaded: date_helper
DEBUG - 2017-03-13 19:30:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:30:32 --> Helper loaded: url_helper
INFO - 2017-03-13 19:30:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:30:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 19:30:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 19:30:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 19:30:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:30:32 --> Final output sent to browser
DEBUG - 2017-03-13 19:30:32 --> Total execution time: 0.0132
INFO - 2017-03-13 19:30:33 --> Config Class Initialized
INFO - 2017-03-13 19:30:33 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:30:33 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:30:33 --> Utf8 Class Initialized
INFO - 2017-03-13 19:30:33 --> URI Class Initialized
INFO - 2017-03-13 19:30:33 --> Router Class Initialized
INFO - 2017-03-13 19:30:33 --> Output Class Initialized
INFO - 2017-03-13 19:30:33 --> Security Class Initialized
DEBUG - 2017-03-13 19:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:30:33 --> Input Class Initialized
INFO - 2017-03-13 19:30:33 --> Language Class Initialized
INFO - 2017-03-13 19:30:33 --> Loader Class Initialized
INFO - 2017-03-13 19:30:33 --> Database Driver Class Initialized
INFO - 2017-03-13 19:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:30:33 --> Controller Class Initialized
INFO - 2017-03-13 19:30:33 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:30:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:30:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:30:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:30:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:30:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:30:33 --> Final output sent to browser
DEBUG - 2017-03-13 19:30:33 --> Total execution time: 0.0134
INFO - 2017-03-13 19:30:36 --> Config Class Initialized
INFO - 2017-03-13 19:30:36 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:30:36 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:30:36 --> Utf8 Class Initialized
INFO - 2017-03-13 19:30:36 --> URI Class Initialized
DEBUG - 2017-03-13 19:30:36 --> No URI present. Default controller set.
INFO - 2017-03-13 19:30:36 --> Router Class Initialized
INFO - 2017-03-13 19:30:36 --> Output Class Initialized
INFO - 2017-03-13 19:30:36 --> Security Class Initialized
DEBUG - 2017-03-13 19:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:30:36 --> Input Class Initialized
INFO - 2017-03-13 19:30:36 --> Language Class Initialized
INFO - 2017-03-13 19:30:36 --> Loader Class Initialized
INFO - 2017-03-13 19:30:36 --> Database Driver Class Initialized
INFO - 2017-03-13 19:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:30:36 --> Controller Class Initialized
INFO - 2017-03-13 19:30:36 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:30:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:30:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:30:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:30:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:30:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:30:36 --> Final output sent to browser
DEBUG - 2017-03-13 19:30:36 --> Total execution time: 0.0134
INFO - 2017-03-13 19:30:40 --> Config Class Initialized
INFO - 2017-03-13 19:30:40 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:30:40 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:30:40 --> Utf8 Class Initialized
INFO - 2017-03-13 19:30:40 --> URI Class Initialized
INFO - 2017-03-13 19:30:40 --> Router Class Initialized
INFO - 2017-03-13 19:30:40 --> Output Class Initialized
INFO - 2017-03-13 19:30:40 --> Security Class Initialized
DEBUG - 2017-03-13 19:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:30:40 --> Input Class Initialized
INFO - 2017-03-13 19:30:40 --> Language Class Initialized
INFO - 2017-03-13 19:30:40 --> Loader Class Initialized
INFO - 2017-03-13 19:30:40 --> Database Driver Class Initialized
INFO - 2017-03-13 19:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:30:40 --> Controller Class Initialized
INFO - 2017-03-13 19:30:40 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:30:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:30:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:30:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:30:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:30:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:30:40 --> Final output sent to browser
DEBUG - 2017-03-13 19:30:40 --> Total execution time: 0.0509
INFO - 2017-03-13 19:30:49 --> Config Class Initialized
INFO - 2017-03-13 19:30:49 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:30:49 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:30:49 --> Utf8 Class Initialized
INFO - 2017-03-13 19:30:49 --> URI Class Initialized
INFO - 2017-03-13 19:30:49 --> Router Class Initialized
INFO - 2017-03-13 19:30:49 --> Output Class Initialized
INFO - 2017-03-13 19:30:49 --> Security Class Initialized
DEBUG - 2017-03-13 19:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:30:49 --> Input Class Initialized
INFO - 2017-03-13 19:30:49 --> Language Class Initialized
INFO - 2017-03-13 19:30:49 --> Loader Class Initialized
INFO - 2017-03-13 19:30:49 --> Database Driver Class Initialized
INFO - 2017-03-13 19:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:30:49 --> Controller Class Initialized
INFO - 2017-03-13 19:30:49 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:30:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:30:50 --> Config Class Initialized
INFO - 2017-03-13 19:30:50 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:30:50 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:30:50 --> Utf8 Class Initialized
INFO - 2017-03-13 19:30:50 --> URI Class Initialized
INFO - 2017-03-13 19:30:50 --> Router Class Initialized
INFO - 2017-03-13 19:30:50 --> Output Class Initialized
INFO - 2017-03-13 19:30:50 --> Security Class Initialized
DEBUG - 2017-03-13 19:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:30:50 --> Input Class Initialized
INFO - 2017-03-13 19:30:50 --> Language Class Initialized
INFO - 2017-03-13 19:30:50 --> Loader Class Initialized
INFO - 2017-03-13 19:30:50 --> Database Driver Class Initialized
INFO - 2017-03-13 19:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:30:50 --> Controller Class Initialized
INFO - 2017-03-13 19:30:50 --> Helper loaded: date_helper
DEBUG - 2017-03-13 19:30:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:30:50 --> Helper loaded: url_helper
INFO - 2017-03-13 19:30:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:30:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 19:30:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 19:30:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 19:30:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:30:50 --> Final output sent to browser
DEBUG - 2017-03-13 19:30:50 --> Total execution time: 0.0140
INFO - 2017-03-13 19:30:50 --> Config Class Initialized
INFO - 2017-03-13 19:30:50 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:30:50 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:30:50 --> Utf8 Class Initialized
INFO - 2017-03-13 19:30:50 --> URI Class Initialized
INFO - 2017-03-13 19:30:50 --> Router Class Initialized
INFO - 2017-03-13 19:30:50 --> Output Class Initialized
INFO - 2017-03-13 19:30:50 --> Security Class Initialized
DEBUG - 2017-03-13 19:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:30:50 --> Input Class Initialized
INFO - 2017-03-13 19:30:50 --> Language Class Initialized
INFO - 2017-03-13 19:30:50 --> Loader Class Initialized
INFO - 2017-03-13 19:30:50 --> Database Driver Class Initialized
INFO - 2017-03-13 19:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:30:50 --> Controller Class Initialized
INFO - 2017-03-13 19:30:50 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:30:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:30:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:30:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:30:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:30:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:30:50 --> Final output sent to browser
DEBUG - 2017-03-13 19:30:50 --> Total execution time: 0.0131
INFO - 2017-03-13 19:31:03 --> Config Class Initialized
INFO - 2017-03-13 19:31:03 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:31:03 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:31:03 --> Utf8 Class Initialized
INFO - 2017-03-13 19:31:03 --> URI Class Initialized
DEBUG - 2017-03-13 19:31:03 --> No URI present. Default controller set.
INFO - 2017-03-13 19:31:03 --> Router Class Initialized
INFO - 2017-03-13 19:31:03 --> Output Class Initialized
INFO - 2017-03-13 19:31:03 --> Security Class Initialized
DEBUG - 2017-03-13 19:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:31:03 --> Input Class Initialized
INFO - 2017-03-13 19:31:03 --> Language Class Initialized
INFO - 2017-03-13 19:31:03 --> Loader Class Initialized
INFO - 2017-03-13 19:31:03 --> Database Driver Class Initialized
INFO - 2017-03-13 19:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:31:03 --> Controller Class Initialized
INFO - 2017-03-13 19:31:03 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:31:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:31:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:31:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:31:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:31:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:31:03 --> Final output sent to browser
DEBUG - 2017-03-13 19:31:03 --> Total execution time: 0.0155
INFO - 2017-03-13 19:31:04 --> Config Class Initialized
INFO - 2017-03-13 19:31:04 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:31:04 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:31:04 --> Utf8 Class Initialized
INFO - 2017-03-13 19:31:04 --> URI Class Initialized
INFO - 2017-03-13 19:31:04 --> Router Class Initialized
INFO - 2017-03-13 19:31:04 --> Output Class Initialized
INFO - 2017-03-13 19:31:04 --> Security Class Initialized
DEBUG - 2017-03-13 19:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:31:04 --> Input Class Initialized
INFO - 2017-03-13 19:31:04 --> Language Class Initialized
INFO - 2017-03-13 19:31:04 --> Loader Class Initialized
INFO - 2017-03-13 19:31:04 --> Database Driver Class Initialized
INFO - 2017-03-13 19:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:31:04 --> Controller Class Initialized
INFO - 2017-03-13 19:31:04 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:31:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:31:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:31:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:31:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:31:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:31:04 --> Final output sent to browser
DEBUG - 2017-03-13 19:31:04 --> Total execution time: 0.0166
INFO - 2017-03-13 19:31:11 --> Config Class Initialized
INFO - 2017-03-13 19:31:11 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:31:11 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:31:11 --> Utf8 Class Initialized
INFO - 2017-03-13 19:31:11 --> URI Class Initialized
INFO - 2017-03-13 19:31:11 --> Router Class Initialized
INFO - 2017-03-13 19:31:11 --> Output Class Initialized
INFO - 2017-03-13 19:31:11 --> Security Class Initialized
DEBUG - 2017-03-13 19:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:31:11 --> Input Class Initialized
INFO - 2017-03-13 19:31:11 --> Language Class Initialized
INFO - 2017-03-13 19:31:11 --> Loader Class Initialized
INFO - 2017-03-13 19:31:11 --> Database Driver Class Initialized
INFO - 2017-03-13 19:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:31:11 --> Controller Class Initialized
INFO - 2017-03-13 19:31:11 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:31:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:31:11 --> Config Class Initialized
INFO - 2017-03-13 19:31:11 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:31:11 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:31:11 --> Utf8 Class Initialized
INFO - 2017-03-13 19:31:11 --> URI Class Initialized
INFO - 2017-03-13 19:31:11 --> Router Class Initialized
INFO - 2017-03-13 19:31:11 --> Output Class Initialized
INFO - 2017-03-13 19:31:11 --> Security Class Initialized
DEBUG - 2017-03-13 19:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:31:11 --> Input Class Initialized
INFO - 2017-03-13 19:31:11 --> Language Class Initialized
INFO - 2017-03-13 19:31:11 --> Loader Class Initialized
INFO - 2017-03-13 19:31:11 --> Database Driver Class Initialized
INFO - 2017-03-13 19:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:31:11 --> Controller Class Initialized
INFO - 2017-03-13 19:31:11 --> Helper loaded: date_helper
DEBUG - 2017-03-13 19:31:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:31:11 --> Helper loaded: url_helper
INFO - 2017-03-13 19:31:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:31:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 19:31:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 19:31:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 19:31:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:31:11 --> Final output sent to browser
DEBUG - 2017-03-13 19:31:11 --> Total execution time: 0.0150
INFO - 2017-03-13 19:31:12 --> Config Class Initialized
INFO - 2017-03-13 19:31:12 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:31:12 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:31:12 --> Utf8 Class Initialized
INFO - 2017-03-13 19:31:12 --> URI Class Initialized
INFO - 2017-03-13 19:31:12 --> Router Class Initialized
INFO - 2017-03-13 19:31:12 --> Output Class Initialized
INFO - 2017-03-13 19:31:12 --> Security Class Initialized
DEBUG - 2017-03-13 19:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:31:12 --> Input Class Initialized
INFO - 2017-03-13 19:31:12 --> Language Class Initialized
INFO - 2017-03-13 19:31:12 --> Loader Class Initialized
INFO - 2017-03-13 19:31:12 --> Database Driver Class Initialized
INFO - 2017-03-13 19:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:31:12 --> Controller Class Initialized
INFO - 2017-03-13 19:31:12 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:31:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:31:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:31:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:31:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:31:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:31:12 --> Final output sent to browser
DEBUG - 2017-03-13 19:31:12 --> Total execution time: 0.0168
INFO - 2017-03-13 19:32:39 --> Config Class Initialized
INFO - 2017-03-13 19:32:39 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:32:39 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:32:39 --> Utf8 Class Initialized
INFO - 2017-03-13 19:32:39 --> URI Class Initialized
DEBUG - 2017-03-13 19:32:39 --> No URI present. Default controller set.
INFO - 2017-03-13 19:32:39 --> Router Class Initialized
INFO - 2017-03-13 19:32:39 --> Output Class Initialized
INFO - 2017-03-13 19:32:39 --> Security Class Initialized
DEBUG - 2017-03-13 19:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:32:39 --> Input Class Initialized
INFO - 2017-03-13 19:32:39 --> Language Class Initialized
INFO - 2017-03-13 19:32:39 --> Loader Class Initialized
INFO - 2017-03-13 19:32:39 --> Database Driver Class Initialized
INFO - 2017-03-13 19:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:32:39 --> Controller Class Initialized
INFO - 2017-03-13 19:32:39 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:32:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:32:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:32:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:32:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:32:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:32:39 --> Final output sent to browser
DEBUG - 2017-03-13 19:32:39 --> Total execution time: 0.0135
INFO - 2017-03-13 19:32:45 --> Config Class Initialized
INFO - 2017-03-13 19:32:45 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:32:45 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:32:45 --> Utf8 Class Initialized
INFO - 2017-03-13 19:32:45 --> URI Class Initialized
INFO - 2017-03-13 19:32:45 --> Router Class Initialized
INFO - 2017-03-13 19:32:45 --> Output Class Initialized
INFO - 2017-03-13 19:32:45 --> Security Class Initialized
DEBUG - 2017-03-13 19:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:32:45 --> Input Class Initialized
INFO - 2017-03-13 19:32:45 --> Language Class Initialized
INFO - 2017-03-13 19:32:45 --> Loader Class Initialized
INFO - 2017-03-13 19:32:45 --> Database Driver Class Initialized
INFO - 2017-03-13 19:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:32:45 --> Controller Class Initialized
INFO - 2017-03-13 19:32:45 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:32:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:32:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:32:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:32:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:32:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:32:45 --> Final output sent to browser
DEBUG - 2017-03-13 19:32:45 --> Total execution time: 0.0141
INFO - 2017-03-13 19:37:38 --> Config Class Initialized
INFO - 2017-03-13 19:37:38 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:37:39 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:37:39 --> Utf8 Class Initialized
INFO - 2017-03-13 19:37:39 --> URI Class Initialized
DEBUG - 2017-03-13 19:37:39 --> No URI present. Default controller set.
INFO - 2017-03-13 19:37:39 --> Router Class Initialized
INFO - 2017-03-13 19:37:39 --> Output Class Initialized
INFO - 2017-03-13 19:37:39 --> Security Class Initialized
DEBUG - 2017-03-13 19:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:37:39 --> Input Class Initialized
INFO - 2017-03-13 19:37:39 --> Language Class Initialized
INFO - 2017-03-13 19:37:39 --> Loader Class Initialized
INFO - 2017-03-13 19:37:39 --> Database Driver Class Initialized
INFO - 2017-03-13 19:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:37:40 --> Controller Class Initialized
INFO - 2017-03-13 19:37:40 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:37:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:37:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:37:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:37:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:37:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:37:40 --> Final output sent to browser
DEBUG - 2017-03-13 19:37:40 --> Total execution time: 2.0204
INFO - 2017-03-13 19:37:40 --> Config Class Initialized
INFO - 2017-03-13 19:37:40 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:37:40 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:37:40 --> Utf8 Class Initialized
INFO - 2017-03-13 19:37:40 --> URI Class Initialized
INFO - 2017-03-13 19:37:40 --> Router Class Initialized
INFO - 2017-03-13 19:37:40 --> Output Class Initialized
INFO - 2017-03-13 19:37:40 --> Security Class Initialized
DEBUG - 2017-03-13 19:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:37:40 --> Input Class Initialized
INFO - 2017-03-13 19:37:40 --> Language Class Initialized
INFO - 2017-03-13 19:37:40 --> Loader Class Initialized
INFO - 2017-03-13 19:37:40 --> Database Driver Class Initialized
INFO - 2017-03-13 19:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:37:40 --> Controller Class Initialized
INFO - 2017-03-13 19:37:40 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:37:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:37:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:37:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:37:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:37:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:37:40 --> Final output sent to browser
DEBUG - 2017-03-13 19:37:40 --> Total execution time: 0.0313
INFO - 2017-03-13 19:38:29 --> Config Class Initialized
INFO - 2017-03-13 19:38:29 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:38:29 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:38:29 --> Utf8 Class Initialized
INFO - 2017-03-13 19:38:29 --> URI Class Initialized
INFO - 2017-03-13 19:38:29 --> Router Class Initialized
INFO - 2017-03-13 19:38:29 --> Output Class Initialized
INFO - 2017-03-13 19:38:29 --> Security Class Initialized
DEBUG - 2017-03-13 19:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:38:29 --> Input Class Initialized
INFO - 2017-03-13 19:38:29 --> Language Class Initialized
INFO - 2017-03-13 19:38:29 --> Loader Class Initialized
INFO - 2017-03-13 19:38:30 --> Database Driver Class Initialized
INFO - 2017-03-13 19:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:38:30 --> Controller Class Initialized
INFO - 2017-03-13 19:38:30 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:38:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:38:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:38:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:38:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:38:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:38:30 --> Final output sent to browser
DEBUG - 2017-03-13 19:38:30 --> Total execution time: 1.2283
INFO - 2017-03-13 19:38:57 --> Config Class Initialized
INFO - 2017-03-13 19:38:57 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:38:57 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:38:57 --> Utf8 Class Initialized
INFO - 2017-03-13 19:38:57 --> URI Class Initialized
INFO - 2017-03-13 19:38:57 --> Router Class Initialized
INFO - 2017-03-13 19:38:57 --> Output Class Initialized
INFO - 2017-03-13 19:38:57 --> Security Class Initialized
DEBUG - 2017-03-13 19:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:38:57 --> Input Class Initialized
INFO - 2017-03-13 19:38:57 --> Language Class Initialized
INFO - 2017-03-13 19:38:57 --> Loader Class Initialized
INFO - 2017-03-13 19:38:57 --> Database Driver Class Initialized
INFO - 2017-03-13 19:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:38:57 --> Controller Class Initialized
INFO - 2017-03-13 19:38:57 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:38:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:38:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:38:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:38:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:38:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:38:57 --> Final output sent to browser
DEBUG - 2017-03-13 19:38:57 --> Total execution time: 0.0137
INFO - 2017-03-13 19:38:59 --> Config Class Initialized
INFO - 2017-03-13 19:38:59 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:38:59 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:38:59 --> Utf8 Class Initialized
INFO - 2017-03-13 19:38:59 --> URI Class Initialized
INFO - 2017-03-13 19:38:59 --> Router Class Initialized
INFO - 2017-03-13 19:38:59 --> Output Class Initialized
INFO - 2017-03-13 19:38:59 --> Security Class Initialized
DEBUG - 2017-03-13 19:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:38:59 --> Input Class Initialized
INFO - 2017-03-13 19:38:59 --> Language Class Initialized
INFO - 2017-03-13 19:38:59 --> Loader Class Initialized
INFO - 2017-03-13 19:38:59 --> Database Driver Class Initialized
INFO - 2017-03-13 19:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:38:59 --> Controller Class Initialized
INFO - 2017-03-13 19:38:59 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:38:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:38:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:38:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:38:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:38:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:38:59 --> Final output sent to browser
DEBUG - 2017-03-13 19:38:59 --> Total execution time: 0.0149
INFO - 2017-03-13 19:42:38 --> Config Class Initialized
INFO - 2017-03-13 19:42:38 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:42:39 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:42:39 --> Utf8 Class Initialized
INFO - 2017-03-13 19:42:39 --> URI Class Initialized
INFO - 2017-03-13 19:42:39 --> Router Class Initialized
INFO - 2017-03-13 19:42:39 --> Output Class Initialized
INFO - 2017-03-13 19:42:39 --> Security Class Initialized
DEBUG - 2017-03-13 19:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:42:39 --> Input Class Initialized
INFO - 2017-03-13 19:42:39 --> Language Class Initialized
INFO - 2017-03-13 19:42:39 --> Loader Class Initialized
INFO - 2017-03-13 19:42:39 --> Database Driver Class Initialized
INFO - 2017-03-13 19:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:42:40 --> Controller Class Initialized
INFO - 2017-03-13 19:42:40 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:42:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:42:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:42:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:42:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:42:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:42:40 --> Final output sent to browser
DEBUG - 2017-03-13 19:42:40 --> Total execution time: 2.0043
INFO - 2017-03-13 19:43:12 --> Config Class Initialized
INFO - 2017-03-13 19:43:12 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:43:12 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:43:12 --> Utf8 Class Initialized
INFO - 2017-03-13 19:43:12 --> URI Class Initialized
INFO - 2017-03-13 19:43:12 --> Router Class Initialized
INFO - 2017-03-13 19:43:12 --> Output Class Initialized
INFO - 2017-03-13 19:43:12 --> Security Class Initialized
DEBUG - 2017-03-13 19:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:43:12 --> Input Class Initialized
INFO - 2017-03-13 19:43:12 --> Language Class Initialized
INFO - 2017-03-13 19:43:12 --> Loader Class Initialized
INFO - 2017-03-13 19:43:12 --> Database Driver Class Initialized
INFO - 2017-03-13 19:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:43:12 --> Controller Class Initialized
INFO - 2017-03-13 19:43:12 --> Helper loaded: url_helper
DEBUG - 2017-03-13 19:43:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 19:43:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 19:43:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 19:43:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 19:43:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 19:43:12 --> Final output sent to browser
DEBUG - 2017-03-13 19:43:12 --> Total execution time: 0.0134
INFO - 2017-03-13 20:05:11 --> Config Class Initialized
INFO - 2017-03-13 20:05:11 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:05:12 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:05:12 --> Utf8 Class Initialized
INFO - 2017-03-13 20:05:12 --> URI Class Initialized
DEBUG - 2017-03-13 20:05:12 --> No URI present. Default controller set.
INFO - 2017-03-13 20:05:12 --> Router Class Initialized
INFO - 2017-03-13 20:05:12 --> Output Class Initialized
INFO - 2017-03-13 20:05:12 --> Security Class Initialized
DEBUG - 2017-03-13 20:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:05:12 --> Input Class Initialized
INFO - 2017-03-13 20:05:12 --> Language Class Initialized
INFO - 2017-03-13 20:05:12 --> Loader Class Initialized
INFO - 2017-03-13 20:05:12 --> Database Driver Class Initialized
INFO - 2017-03-13 20:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:05:13 --> Controller Class Initialized
INFO - 2017-03-13 20:05:13 --> Helper loaded: url_helper
DEBUG - 2017-03-13 20:05:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 20:05:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 20:05:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 20:05:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 20:05:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 20:05:13 --> Final output sent to browser
DEBUG - 2017-03-13 20:05:13 --> Total execution time: 2.0458
INFO - 2017-03-13 20:05:35 --> Config Class Initialized
INFO - 2017-03-13 20:05:35 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:05:35 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:05:35 --> Utf8 Class Initialized
INFO - 2017-03-13 20:05:35 --> URI Class Initialized
INFO - 2017-03-13 20:05:35 --> Router Class Initialized
INFO - 2017-03-13 20:05:35 --> Output Class Initialized
INFO - 2017-03-13 20:05:35 --> Security Class Initialized
DEBUG - 2017-03-13 20:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:05:35 --> Input Class Initialized
INFO - 2017-03-13 20:05:35 --> Language Class Initialized
INFO - 2017-03-13 20:05:35 --> Loader Class Initialized
INFO - 2017-03-13 20:05:35 --> Database Driver Class Initialized
INFO - 2017-03-13 20:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:05:35 --> Controller Class Initialized
INFO - 2017-03-13 20:05:35 --> Helper loaded: url_helper
DEBUG - 2017-03-13 20:05:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 20:05:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-13 20:05:36 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-13 20:05:36 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-13 20:05:36 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-13 20:05:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 20:05:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 20:05:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 20:05:36 --> Final output sent to browser
DEBUG - 2017-03-13 20:05:36 --> Total execution time: 0.6445
INFO - 2017-03-13 20:06:21 --> Config Class Initialized
INFO - 2017-03-13 20:06:21 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:06:21 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:06:21 --> Utf8 Class Initialized
INFO - 2017-03-13 20:06:21 --> URI Class Initialized
INFO - 2017-03-13 20:06:21 --> Router Class Initialized
INFO - 2017-03-13 20:06:21 --> Output Class Initialized
INFO - 2017-03-13 20:06:21 --> Security Class Initialized
DEBUG - 2017-03-13 20:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:06:21 --> Input Class Initialized
INFO - 2017-03-13 20:06:21 --> Language Class Initialized
INFO - 2017-03-13 20:06:21 --> Loader Class Initialized
INFO - 2017-03-13 20:06:21 --> Database Driver Class Initialized
INFO - 2017-03-13 20:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:06:21 --> Controller Class Initialized
INFO - 2017-03-13 20:06:21 --> Helper loaded: url_helper
DEBUG - 2017-03-13 20:06:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 20:06:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-13 20:06:21 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-13 20:06:21 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-13 20:06:21 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-13 20:06:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 20:06:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 20:06:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 20:06:21 --> Final output sent to browser
DEBUG - 2017-03-13 20:06:21 --> Total execution time: 0.0437
INFO - 2017-03-13 20:09:15 --> Config Class Initialized
INFO - 2017-03-13 20:09:15 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:09:16 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:09:16 --> Utf8 Class Initialized
INFO - 2017-03-13 20:09:16 --> URI Class Initialized
DEBUG - 2017-03-13 20:09:16 --> No URI present. Default controller set.
INFO - 2017-03-13 20:09:16 --> Router Class Initialized
INFO - 2017-03-13 20:09:16 --> Output Class Initialized
INFO - 2017-03-13 20:09:16 --> Security Class Initialized
DEBUG - 2017-03-13 20:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:09:16 --> Input Class Initialized
INFO - 2017-03-13 20:09:16 --> Language Class Initialized
INFO - 2017-03-13 20:09:16 --> Loader Class Initialized
INFO - 2017-03-13 20:09:16 --> Database Driver Class Initialized
INFO - 2017-03-13 20:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:09:17 --> Controller Class Initialized
INFO - 2017-03-13 20:09:17 --> Helper loaded: url_helper
DEBUG - 2017-03-13 20:09:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 20:09:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 20:09:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 20:09:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 20:09:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 20:09:17 --> Final output sent to browser
DEBUG - 2017-03-13 20:09:17 --> Total execution time: 1.7587
INFO - 2017-03-13 20:11:14 --> Config Class Initialized
INFO - 2017-03-13 20:11:14 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:11:14 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:11:14 --> Utf8 Class Initialized
INFO - 2017-03-13 20:11:14 --> URI Class Initialized
INFO - 2017-03-13 20:11:14 --> Router Class Initialized
INFO - 2017-03-13 20:11:14 --> Output Class Initialized
INFO - 2017-03-13 20:11:14 --> Security Class Initialized
DEBUG - 2017-03-13 20:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:11:15 --> Input Class Initialized
INFO - 2017-03-13 20:11:15 --> Language Class Initialized
INFO - 2017-03-13 20:11:15 --> Loader Class Initialized
INFO - 2017-03-13 20:11:15 --> Database Driver Class Initialized
INFO - 2017-03-13 20:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:11:15 --> Controller Class Initialized
INFO - 2017-03-13 20:11:15 --> Helper loaded: url_helper
DEBUG - 2017-03-13 20:11:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 20:11:17 --> Config Class Initialized
INFO - 2017-03-13 20:11:17 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:11:17 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:11:17 --> Utf8 Class Initialized
INFO - 2017-03-13 20:11:17 --> URI Class Initialized
INFO - 2017-03-13 20:11:17 --> Router Class Initialized
INFO - 2017-03-13 20:11:17 --> Output Class Initialized
INFO - 2017-03-13 20:11:17 --> Security Class Initialized
DEBUG - 2017-03-13 20:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:11:17 --> Input Class Initialized
INFO - 2017-03-13 20:11:17 --> Language Class Initialized
INFO - 2017-03-13 20:11:17 --> Loader Class Initialized
INFO - 2017-03-13 20:11:17 --> Database Driver Class Initialized
INFO - 2017-03-13 20:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:11:17 --> Controller Class Initialized
INFO - 2017-03-13 20:11:17 --> Helper loaded: date_helper
DEBUG - 2017-03-13 20:11:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 20:11:17 --> Helper loaded: url_helper
INFO - 2017-03-13 20:11:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 20:11:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 20:11:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 20:11:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 20:11:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 20:11:17 --> Final output sent to browser
DEBUG - 2017-03-13 20:11:17 --> Total execution time: 0.1094
INFO - 2017-03-13 20:27:35 --> Config Class Initialized
INFO - 2017-03-13 20:27:35 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:27:35 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:27:35 --> Utf8 Class Initialized
INFO - 2017-03-13 20:27:35 --> URI Class Initialized
DEBUG - 2017-03-13 20:27:35 --> No URI present. Default controller set.
INFO - 2017-03-13 20:27:35 --> Router Class Initialized
INFO - 2017-03-13 20:27:35 --> Output Class Initialized
INFO - 2017-03-13 20:27:35 --> Security Class Initialized
DEBUG - 2017-03-13 20:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:27:36 --> Input Class Initialized
INFO - 2017-03-13 20:27:36 --> Language Class Initialized
INFO - 2017-03-13 20:27:36 --> Loader Class Initialized
INFO - 2017-03-13 20:27:36 --> Database Driver Class Initialized
INFO - 2017-03-13 20:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:27:36 --> Controller Class Initialized
INFO - 2017-03-13 20:27:36 --> Helper loaded: url_helper
DEBUG - 2017-03-13 20:27:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 20:27:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 20:27:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 20:27:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 20:27:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 20:27:37 --> Final output sent to browser
DEBUG - 2017-03-13 20:27:37 --> Total execution time: 1.8293
INFO - 2017-03-13 20:30:36 --> Config Class Initialized
INFO - 2017-03-13 20:30:36 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:30:37 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:30:37 --> Utf8 Class Initialized
INFO - 2017-03-13 20:30:37 --> URI Class Initialized
DEBUG - 2017-03-13 20:30:37 --> No URI present. Default controller set.
INFO - 2017-03-13 20:30:37 --> Router Class Initialized
INFO - 2017-03-13 20:30:37 --> Output Class Initialized
INFO - 2017-03-13 20:30:37 --> Security Class Initialized
DEBUG - 2017-03-13 20:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:30:37 --> Input Class Initialized
INFO - 2017-03-13 20:30:37 --> Language Class Initialized
INFO - 2017-03-13 20:30:37 --> Loader Class Initialized
INFO - 2017-03-13 20:30:37 --> Database Driver Class Initialized
INFO - 2017-03-13 20:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:30:38 --> Controller Class Initialized
INFO - 2017-03-13 20:30:38 --> Helper loaded: url_helper
DEBUG - 2017-03-13 20:30:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 20:30:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 20:30:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 20:30:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 20:30:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 20:30:38 --> Final output sent to browser
DEBUG - 2017-03-13 20:30:38 --> Total execution time: 1.7710
INFO - 2017-03-13 20:30:41 --> Config Class Initialized
INFO - 2017-03-13 20:30:41 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:30:41 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:30:41 --> Utf8 Class Initialized
INFO - 2017-03-13 20:30:41 --> URI Class Initialized
INFO - 2017-03-13 20:30:41 --> Router Class Initialized
INFO - 2017-03-13 20:30:41 --> Output Class Initialized
INFO - 2017-03-13 20:30:41 --> Security Class Initialized
DEBUG - 2017-03-13 20:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:30:41 --> Input Class Initialized
INFO - 2017-03-13 20:30:41 --> Language Class Initialized
INFO - 2017-03-13 20:30:41 --> Loader Class Initialized
INFO - 2017-03-13 20:30:41 --> Database Driver Class Initialized
INFO - 2017-03-13 20:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:30:41 --> Controller Class Initialized
INFO - 2017-03-13 20:30:41 --> Helper loaded: url_helper
DEBUG - 2017-03-13 20:30:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 20:30:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 20:30:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 20:30:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 20:30:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 20:30:41 --> Final output sent to browser
DEBUG - 2017-03-13 20:30:41 --> Total execution time: 0.0320
INFO - 2017-03-13 20:31:33 --> Config Class Initialized
INFO - 2017-03-13 20:31:33 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:31:33 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:31:33 --> Utf8 Class Initialized
INFO - 2017-03-13 20:31:33 --> URI Class Initialized
INFO - 2017-03-13 20:31:33 --> Router Class Initialized
INFO - 2017-03-13 20:31:33 --> Output Class Initialized
INFO - 2017-03-13 20:31:33 --> Security Class Initialized
DEBUG - 2017-03-13 20:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:31:33 --> Input Class Initialized
INFO - 2017-03-13 20:31:33 --> Language Class Initialized
INFO - 2017-03-13 20:31:33 --> Loader Class Initialized
INFO - 2017-03-13 20:31:33 --> Database Driver Class Initialized
INFO - 2017-03-13 20:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:31:34 --> Controller Class Initialized
INFO - 2017-03-13 20:31:34 --> Helper loaded: url_helper
DEBUG - 2017-03-13 20:31:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 20:31:34 --> Config Class Initialized
INFO - 2017-03-13 20:31:34 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:31:34 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:31:34 --> Utf8 Class Initialized
INFO - 2017-03-13 20:31:34 --> URI Class Initialized
INFO - 2017-03-13 20:31:34 --> Router Class Initialized
INFO - 2017-03-13 20:31:34 --> Output Class Initialized
INFO - 2017-03-13 20:31:34 --> Security Class Initialized
DEBUG - 2017-03-13 20:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:31:34 --> Input Class Initialized
INFO - 2017-03-13 20:31:34 --> Language Class Initialized
INFO - 2017-03-13 20:31:34 --> Loader Class Initialized
INFO - 2017-03-13 20:31:34 --> Database Driver Class Initialized
INFO - 2017-03-13 20:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:31:34 --> Controller Class Initialized
INFO - 2017-03-13 20:31:34 --> Helper loaded: date_helper
DEBUG - 2017-03-13 20:31:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 20:31:34 --> Helper loaded: url_helper
INFO - 2017-03-13 20:31:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 20:31:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 20:31:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 20:31:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 20:31:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 20:31:34 --> Final output sent to browser
DEBUG - 2017-03-13 20:31:34 --> Total execution time: 0.1203
INFO - 2017-03-13 20:31:36 --> Config Class Initialized
INFO - 2017-03-13 20:31:36 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:31:36 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:31:36 --> Utf8 Class Initialized
INFO - 2017-03-13 20:31:36 --> URI Class Initialized
INFO - 2017-03-13 20:31:36 --> Router Class Initialized
INFO - 2017-03-13 20:31:36 --> Output Class Initialized
INFO - 2017-03-13 20:31:36 --> Security Class Initialized
DEBUG - 2017-03-13 20:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:31:36 --> Input Class Initialized
INFO - 2017-03-13 20:31:36 --> Language Class Initialized
INFO - 2017-03-13 20:31:36 --> Loader Class Initialized
INFO - 2017-03-13 20:31:36 --> Database Driver Class Initialized
INFO - 2017-03-13 20:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:31:36 --> Controller Class Initialized
INFO - 2017-03-13 20:31:36 --> Helper loaded: url_helper
DEBUG - 2017-03-13 20:31:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 20:31:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 20:31:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 20:31:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 20:31:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 20:31:36 --> Final output sent to browser
DEBUG - 2017-03-13 20:31:36 --> Total execution time: 0.0454
INFO - 2017-03-13 20:31:55 --> Config Class Initialized
INFO - 2017-03-13 20:31:55 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:31:55 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:31:55 --> Utf8 Class Initialized
INFO - 2017-03-13 20:31:55 --> URI Class Initialized
DEBUG - 2017-03-13 20:31:55 --> No URI present. Default controller set.
INFO - 2017-03-13 20:31:55 --> Router Class Initialized
INFO - 2017-03-13 20:31:55 --> Output Class Initialized
INFO - 2017-03-13 20:31:55 --> Security Class Initialized
DEBUG - 2017-03-13 20:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:31:55 --> Input Class Initialized
INFO - 2017-03-13 20:31:55 --> Language Class Initialized
INFO - 2017-03-13 20:31:55 --> Loader Class Initialized
INFO - 2017-03-13 20:31:55 --> Database Driver Class Initialized
INFO - 2017-03-13 20:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:31:55 --> Controller Class Initialized
INFO - 2017-03-13 20:31:55 --> Helper loaded: url_helper
DEBUG - 2017-03-13 20:31:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 20:31:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 20:31:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 20:31:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 20:31:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 20:31:55 --> Final output sent to browser
DEBUG - 2017-03-13 20:31:55 --> Total execution time: 0.0139
INFO - 2017-03-13 20:31:57 --> Config Class Initialized
INFO - 2017-03-13 20:31:57 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:31:57 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:31:57 --> Utf8 Class Initialized
INFO - 2017-03-13 20:31:57 --> URI Class Initialized
INFO - 2017-03-13 20:31:57 --> Router Class Initialized
INFO - 2017-03-13 20:31:57 --> Output Class Initialized
INFO - 2017-03-13 20:31:57 --> Security Class Initialized
DEBUG - 2017-03-13 20:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:31:57 --> Input Class Initialized
INFO - 2017-03-13 20:31:57 --> Language Class Initialized
INFO - 2017-03-13 20:31:57 --> Loader Class Initialized
INFO - 2017-03-13 20:31:57 --> Database Driver Class Initialized
INFO - 2017-03-13 20:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:31:57 --> Controller Class Initialized
INFO - 2017-03-13 20:31:57 --> Helper loaded: url_helper
DEBUG - 2017-03-13 20:31:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 20:31:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 20:31:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 20:31:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 20:31:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 20:31:57 --> Final output sent to browser
DEBUG - 2017-03-13 20:31:57 --> Total execution time: 0.0132
INFO - 2017-03-13 20:32:12 --> Config Class Initialized
INFO - 2017-03-13 20:32:12 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:32:12 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:32:12 --> Utf8 Class Initialized
INFO - 2017-03-13 20:32:12 --> URI Class Initialized
INFO - 2017-03-13 20:32:12 --> Router Class Initialized
INFO - 2017-03-13 20:32:12 --> Output Class Initialized
INFO - 2017-03-13 20:32:12 --> Security Class Initialized
DEBUG - 2017-03-13 20:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:32:12 --> Input Class Initialized
INFO - 2017-03-13 20:32:12 --> Language Class Initialized
INFO - 2017-03-13 20:32:12 --> Loader Class Initialized
INFO - 2017-03-13 20:32:12 --> Database Driver Class Initialized
INFO - 2017-03-13 20:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:32:12 --> Controller Class Initialized
INFO - 2017-03-13 20:32:12 --> Helper loaded: url_helper
DEBUG - 2017-03-13 20:32:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 20:32:12 --> Config Class Initialized
INFO - 2017-03-13 20:32:12 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:32:12 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:32:12 --> Utf8 Class Initialized
INFO - 2017-03-13 20:32:12 --> URI Class Initialized
INFO - 2017-03-13 20:32:12 --> Router Class Initialized
INFO - 2017-03-13 20:32:12 --> Output Class Initialized
INFO - 2017-03-13 20:32:12 --> Security Class Initialized
DEBUG - 2017-03-13 20:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:32:12 --> Input Class Initialized
INFO - 2017-03-13 20:32:12 --> Language Class Initialized
INFO - 2017-03-13 20:32:12 --> Loader Class Initialized
INFO - 2017-03-13 20:32:12 --> Database Driver Class Initialized
INFO - 2017-03-13 20:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:32:12 --> Controller Class Initialized
INFO - 2017-03-13 20:32:12 --> Helper loaded: date_helper
DEBUG - 2017-03-13 20:32:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 20:32:12 --> Helper loaded: url_helper
INFO - 2017-03-13 20:32:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 20:32:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 20:32:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 20:32:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 20:32:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 20:32:12 --> Final output sent to browser
DEBUG - 2017-03-13 20:32:12 --> Total execution time: 0.0136
INFO - 2017-03-13 20:32:13 --> Config Class Initialized
INFO - 2017-03-13 20:32:13 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:32:13 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:32:13 --> Utf8 Class Initialized
INFO - 2017-03-13 20:32:13 --> URI Class Initialized
INFO - 2017-03-13 20:32:13 --> Router Class Initialized
INFO - 2017-03-13 20:32:13 --> Output Class Initialized
INFO - 2017-03-13 20:32:13 --> Security Class Initialized
DEBUG - 2017-03-13 20:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:32:13 --> Input Class Initialized
INFO - 2017-03-13 20:32:13 --> Language Class Initialized
INFO - 2017-03-13 20:32:13 --> Loader Class Initialized
INFO - 2017-03-13 20:32:13 --> Database Driver Class Initialized
INFO - 2017-03-13 20:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:32:13 --> Controller Class Initialized
INFO - 2017-03-13 20:32:13 --> Helper loaded: url_helper
DEBUG - 2017-03-13 20:32:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 20:32:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 20:32:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 20:32:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 20:32:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 20:32:13 --> Final output sent to browser
DEBUG - 2017-03-13 20:32:13 --> Total execution time: 0.0142
INFO - 2017-03-13 20:41:14 --> Config Class Initialized
INFO - 2017-03-13 20:41:14 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:41:14 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:41:14 --> Utf8 Class Initialized
INFO - 2017-03-13 20:41:14 --> URI Class Initialized
DEBUG - 2017-03-13 20:41:14 --> No URI present. Default controller set.
INFO - 2017-03-13 20:41:14 --> Router Class Initialized
INFO - 2017-03-13 20:41:14 --> Output Class Initialized
INFO - 2017-03-13 20:41:14 --> Security Class Initialized
DEBUG - 2017-03-13 20:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:41:14 --> Input Class Initialized
INFO - 2017-03-13 20:41:14 --> Language Class Initialized
INFO - 2017-03-13 20:41:15 --> Loader Class Initialized
INFO - 2017-03-13 20:41:15 --> Database Driver Class Initialized
INFO - 2017-03-13 20:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:41:16 --> Controller Class Initialized
INFO - 2017-03-13 20:41:16 --> Helper loaded: url_helper
DEBUG - 2017-03-13 20:41:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 20:41:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 20:41:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 20:41:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 20:41:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 20:41:16 --> Final output sent to browser
DEBUG - 2017-03-13 20:41:16 --> Total execution time: 1.8179
INFO - 2017-03-13 20:41:23 --> Config Class Initialized
INFO - 2017-03-13 20:41:23 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:41:23 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:41:23 --> Utf8 Class Initialized
INFO - 2017-03-13 20:41:23 --> URI Class Initialized
INFO - 2017-03-13 20:41:23 --> Router Class Initialized
INFO - 2017-03-13 20:41:23 --> Output Class Initialized
INFO - 2017-03-13 20:41:23 --> Security Class Initialized
DEBUG - 2017-03-13 20:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:41:23 --> Input Class Initialized
INFO - 2017-03-13 20:41:23 --> Language Class Initialized
INFO - 2017-03-13 20:41:23 --> Loader Class Initialized
INFO - 2017-03-13 20:41:23 --> Database Driver Class Initialized
INFO - 2017-03-13 20:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:41:23 --> Controller Class Initialized
INFO - 2017-03-13 20:41:23 --> Helper loaded: url_helper
DEBUG - 2017-03-13 20:41:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 20:41:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 20:41:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 20:41:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 20:41:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 20:41:23 --> Final output sent to browser
DEBUG - 2017-03-13 20:41:23 --> Total execution time: 0.0159
INFO - 2017-03-13 20:42:01 --> Config Class Initialized
INFO - 2017-03-13 20:42:01 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:42:01 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:42:01 --> Utf8 Class Initialized
INFO - 2017-03-13 20:42:01 --> URI Class Initialized
INFO - 2017-03-13 20:42:01 --> Router Class Initialized
INFO - 2017-03-13 20:42:01 --> Output Class Initialized
INFO - 2017-03-13 20:42:01 --> Security Class Initialized
DEBUG - 2017-03-13 20:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:42:01 --> Input Class Initialized
INFO - 2017-03-13 20:42:01 --> Language Class Initialized
INFO - 2017-03-13 20:42:01 --> Loader Class Initialized
INFO - 2017-03-13 20:42:02 --> Database Driver Class Initialized
INFO - 2017-03-13 20:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:42:02 --> Controller Class Initialized
INFO - 2017-03-13 20:42:02 --> Helper loaded: url_helper
DEBUG - 2017-03-13 20:42:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 20:42:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-13 20:42:03 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-13 20:42:03 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-13 20:42:03 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-13 20:42:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 20:42:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 20:42:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 20:42:03 --> Final output sent to browser
DEBUG - 2017-03-13 20:42:03 --> Total execution time: 2.0748
INFO - 2017-03-13 20:42:08 --> Config Class Initialized
INFO - 2017-03-13 20:42:08 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:42:08 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:42:08 --> Utf8 Class Initialized
INFO - 2017-03-13 20:42:08 --> URI Class Initialized
INFO - 2017-03-13 20:42:08 --> Router Class Initialized
INFO - 2017-03-13 20:42:08 --> Output Class Initialized
INFO - 2017-03-13 20:42:08 --> Security Class Initialized
DEBUG - 2017-03-13 20:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:42:08 --> Input Class Initialized
INFO - 2017-03-13 20:42:08 --> Language Class Initialized
INFO - 2017-03-13 20:42:08 --> Loader Class Initialized
INFO - 2017-03-13 20:42:08 --> Database Driver Class Initialized
INFO - 2017-03-13 20:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:42:08 --> Controller Class Initialized
INFO - 2017-03-13 20:42:08 --> Helper loaded: url_helper
DEBUG - 2017-03-13 20:42:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 20:42:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 20:42:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 20:42:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 20:42:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 20:42:08 --> Final output sent to browser
DEBUG - 2017-03-13 20:42:08 --> Total execution time: 0.0134
INFO - 2017-03-13 20:42:40 --> Config Class Initialized
INFO - 2017-03-13 20:42:40 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:42:40 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:42:40 --> Utf8 Class Initialized
INFO - 2017-03-13 20:42:40 --> URI Class Initialized
DEBUG - 2017-03-13 20:42:40 --> No URI present. Default controller set.
INFO - 2017-03-13 20:42:40 --> Router Class Initialized
INFO - 2017-03-13 20:42:40 --> Output Class Initialized
INFO - 2017-03-13 20:42:40 --> Security Class Initialized
DEBUG - 2017-03-13 20:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:42:40 --> Input Class Initialized
INFO - 2017-03-13 20:42:40 --> Language Class Initialized
INFO - 2017-03-13 20:42:40 --> Loader Class Initialized
INFO - 2017-03-13 20:42:40 --> Database Driver Class Initialized
INFO - 2017-03-13 20:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:42:41 --> Controller Class Initialized
INFO - 2017-03-13 20:42:41 --> Helper loaded: url_helper
DEBUG - 2017-03-13 20:42:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 20:42:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 20:42:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 20:42:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 20:42:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 20:42:41 --> Final output sent to browser
DEBUG - 2017-03-13 20:42:41 --> Total execution time: 0.6486
INFO - 2017-03-13 20:54:31 --> Config Class Initialized
INFO - 2017-03-13 20:54:31 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:54:31 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:54:31 --> Utf8 Class Initialized
INFO - 2017-03-13 20:54:31 --> URI Class Initialized
DEBUG - 2017-03-13 20:54:31 --> No URI present. Default controller set.
INFO - 2017-03-13 20:54:31 --> Router Class Initialized
INFO - 2017-03-13 20:54:31 --> Output Class Initialized
INFO - 2017-03-13 20:54:31 --> Security Class Initialized
DEBUG - 2017-03-13 20:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:54:31 --> Input Class Initialized
INFO - 2017-03-13 20:54:31 --> Language Class Initialized
INFO - 2017-03-13 20:54:31 --> Loader Class Initialized
INFO - 2017-03-13 20:54:32 --> Database Driver Class Initialized
INFO - 2017-03-13 20:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:54:32 --> Controller Class Initialized
INFO - 2017-03-13 20:54:32 --> Helper loaded: url_helper
DEBUG - 2017-03-13 20:54:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 20:54:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 20:54:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 20:54:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 20:54:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 20:54:33 --> Final output sent to browser
DEBUG - 2017-03-13 20:54:33 --> Total execution time: 1.7860
INFO - 2017-03-13 20:54:37 --> Config Class Initialized
INFO - 2017-03-13 20:54:37 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:54:37 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:54:37 --> Utf8 Class Initialized
INFO - 2017-03-13 20:54:37 --> URI Class Initialized
INFO - 2017-03-13 20:54:37 --> Router Class Initialized
INFO - 2017-03-13 20:54:37 --> Output Class Initialized
INFO - 2017-03-13 20:54:37 --> Security Class Initialized
DEBUG - 2017-03-13 20:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:54:37 --> Input Class Initialized
INFO - 2017-03-13 20:54:37 --> Language Class Initialized
INFO - 2017-03-13 20:54:37 --> Loader Class Initialized
INFO - 2017-03-13 20:54:37 --> Database Driver Class Initialized
INFO - 2017-03-13 20:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:54:37 --> Controller Class Initialized
INFO - 2017-03-13 20:54:37 --> Helper loaded: url_helper
DEBUG - 2017-03-13 20:54:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 20:54:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 20:54:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 20:54:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 20:54:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 20:54:37 --> Final output sent to browser
DEBUG - 2017-03-13 20:54:37 --> Total execution time: 0.0147
INFO - 2017-03-13 20:54:50 --> Config Class Initialized
INFO - 2017-03-13 20:54:50 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:54:50 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:54:50 --> Utf8 Class Initialized
INFO - 2017-03-13 20:54:50 --> URI Class Initialized
INFO - 2017-03-13 20:54:50 --> Router Class Initialized
INFO - 2017-03-13 20:54:50 --> Output Class Initialized
INFO - 2017-03-13 20:54:50 --> Security Class Initialized
DEBUG - 2017-03-13 20:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:54:50 --> Input Class Initialized
INFO - 2017-03-13 20:54:50 --> Language Class Initialized
INFO - 2017-03-13 20:54:50 --> Loader Class Initialized
INFO - 2017-03-13 20:54:50 --> Database Driver Class Initialized
INFO - 2017-03-13 20:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:54:50 --> Controller Class Initialized
INFO - 2017-03-13 20:54:50 --> Helper loaded: url_helper
DEBUG - 2017-03-13 20:54:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 20:54:52 --> Config Class Initialized
INFO - 2017-03-13 20:54:52 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:54:52 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:54:52 --> Utf8 Class Initialized
INFO - 2017-03-13 20:54:52 --> URI Class Initialized
INFO - 2017-03-13 20:54:52 --> Router Class Initialized
INFO - 2017-03-13 20:54:52 --> Output Class Initialized
INFO - 2017-03-13 20:54:52 --> Security Class Initialized
DEBUG - 2017-03-13 20:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:54:52 --> Input Class Initialized
INFO - 2017-03-13 20:54:52 --> Language Class Initialized
INFO - 2017-03-13 20:54:52 --> Loader Class Initialized
INFO - 2017-03-13 20:54:52 --> Database Driver Class Initialized
INFO - 2017-03-13 20:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:54:52 --> Controller Class Initialized
INFO - 2017-03-13 20:54:52 --> Helper loaded: date_helper
DEBUG - 2017-03-13 20:54:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 20:54:53 --> Helper loaded: url_helper
INFO - 2017-03-13 20:54:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 20:54:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-13 20:54:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-13 20:54:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-13 20:54:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 20:54:53 --> Final output sent to browser
DEBUG - 2017-03-13 20:54:53 --> Total execution time: 0.0990
INFO - 2017-03-13 20:54:54 --> Config Class Initialized
INFO - 2017-03-13 20:54:54 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:54:54 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:54:54 --> Utf8 Class Initialized
INFO - 2017-03-13 20:54:54 --> URI Class Initialized
INFO - 2017-03-13 20:54:54 --> Router Class Initialized
INFO - 2017-03-13 20:54:54 --> Output Class Initialized
INFO - 2017-03-13 20:54:54 --> Security Class Initialized
DEBUG - 2017-03-13 20:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:54:54 --> Input Class Initialized
INFO - 2017-03-13 20:54:54 --> Language Class Initialized
INFO - 2017-03-13 20:54:54 --> Loader Class Initialized
INFO - 2017-03-13 20:54:54 --> Database Driver Class Initialized
INFO - 2017-03-13 20:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:54:54 --> Controller Class Initialized
INFO - 2017-03-13 20:54:54 --> Helper loaded: url_helper
DEBUG - 2017-03-13 20:54:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 20:54:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 20:54:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 20:54:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 20:54:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 20:54:54 --> Final output sent to browser
DEBUG - 2017-03-13 20:54:54 --> Total execution time: 0.0141
INFO - 2017-03-13 22:15:22 --> Config Class Initialized
INFO - 2017-03-13 22:15:22 --> Hooks Class Initialized
DEBUG - 2017-03-13 22:15:22 --> UTF-8 Support Enabled
INFO - 2017-03-13 22:15:22 --> Utf8 Class Initialized
INFO - 2017-03-13 22:15:22 --> URI Class Initialized
DEBUG - 2017-03-13 22:15:23 --> No URI present. Default controller set.
INFO - 2017-03-13 22:15:23 --> Router Class Initialized
INFO - 2017-03-13 22:15:23 --> Output Class Initialized
INFO - 2017-03-13 22:15:23 --> Security Class Initialized
DEBUG - 2017-03-13 22:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 22:15:23 --> Input Class Initialized
INFO - 2017-03-13 22:15:23 --> Language Class Initialized
INFO - 2017-03-13 22:15:23 --> Loader Class Initialized
INFO - 2017-03-13 22:15:23 --> Database Driver Class Initialized
INFO - 2017-03-13 22:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 22:15:24 --> Controller Class Initialized
INFO - 2017-03-13 22:15:24 --> Helper loaded: url_helper
DEBUG - 2017-03-13 22:15:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 22:15:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 22:15:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 22:15:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 22:15:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 22:15:24 --> Final output sent to browser
DEBUG - 2017-03-13 22:15:24 --> Total execution time: 2.0607
INFO - 2017-03-13 23:12:30 --> Config Class Initialized
INFO - 2017-03-13 23:12:30 --> Hooks Class Initialized
DEBUG - 2017-03-13 23:12:30 --> UTF-8 Support Enabled
INFO - 2017-03-13 23:12:30 --> Utf8 Class Initialized
INFO - 2017-03-13 23:12:30 --> URI Class Initialized
DEBUG - 2017-03-13 23:12:30 --> No URI present. Default controller set.
INFO - 2017-03-13 23:12:30 --> Router Class Initialized
INFO - 2017-03-13 23:12:31 --> Output Class Initialized
INFO - 2017-03-13 23:12:31 --> Security Class Initialized
DEBUG - 2017-03-13 23:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 23:12:31 --> Input Class Initialized
INFO - 2017-03-13 23:12:31 --> Language Class Initialized
INFO - 2017-03-13 23:12:31 --> Loader Class Initialized
INFO - 2017-03-13 23:12:31 --> Database Driver Class Initialized
INFO - 2017-03-13 23:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 23:12:31 --> Controller Class Initialized
INFO - 2017-03-13 23:12:31 --> Helper loaded: url_helper
DEBUG - 2017-03-13 23:12:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 23:12:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-13 23:12:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-13 23:12:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-13 23:12:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-13 23:12:32 --> Final output sent to browser
DEBUG - 2017-03-13 23:12:32 --> Total execution time: 1.7594

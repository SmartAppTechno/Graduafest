<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-21 02:56:08 --> Config Class Initialized
INFO - 2017-02-21 02:56:08 --> Hooks Class Initialized
DEBUG - 2017-02-21 02:56:08 --> UTF-8 Support Enabled
INFO - 2017-02-21 02:56:08 --> Utf8 Class Initialized
INFO - 2017-02-21 02:56:08 --> URI Class Initialized
DEBUG - 2017-02-21 02:56:08 --> No URI present. Default controller set.
INFO - 2017-02-21 02:56:08 --> Router Class Initialized
INFO - 2017-02-21 02:56:08 --> Output Class Initialized
INFO - 2017-02-21 02:56:08 --> Security Class Initialized
DEBUG - 2017-02-21 02:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 02:56:08 --> Input Class Initialized
INFO - 2017-02-21 02:56:08 --> Language Class Initialized
INFO - 2017-02-21 02:56:08 --> Loader Class Initialized
INFO - 2017-02-21 02:56:08 --> Database Driver Class Initialized
INFO - 2017-02-21 02:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 02:56:08 --> Controller Class Initialized
INFO - 2017-02-21 02:56:08 --> Helper loaded: url_helper
DEBUG - 2017-02-21 02:56:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-21 02:56:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-21 02:56:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-21 02:56:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-21 02:56:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-21 02:56:08 --> Final output sent to browser
DEBUG - 2017-02-21 02:56:08 --> Total execution time: 0.3029
INFO - 2017-02-21 02:56:10 --> Config Class Initialized
INFO - 2017-02-21 02:56:10 --> Hooks Class Initialized
DEBUG - 2017-02-21 02:56:10 --> UTF-8 Support Enabled
INFO - 2017-02-21 02:56:10 --> Utf8 Class Initialized
INFO - 2017-02-21 02:56:10 --> URI Class Initialized
INFO - 2017-02-21 02:56:10 --> Router Class Initialized
INFO - 2017-02-21 02:56:10 --> Output Class Initialized
INFO - 2017-02-21 02:56:10 --> Security Class Initialized
DEBUG - 2017-02-21 02:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 02:56:10 --> Input Class Initialized
INFO - 2017-02-21 02:56:10 --> Language Class Initialized
INFO - 2017-02-21 02:56:10 --> Loader Class Initialized
INFO - 2017-02-21 02:56:10 --> Database Driver Class Initialized
INFO - 2017-02-21 02:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 02:56:10 --> Controller Class Initialized
INFO - 2017-02-21 02:56:10 --> Helper loaded: url_helper
DEBUG - 2017-02-21 02:56:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-21 02:56:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-21 02:56:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-21 02:56:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-21 02:56:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-21 02:56:10 --> Final output sent to browser
DEBUG - 2017-02-21 02:56:10 --> Total execution time: 0.0681
INFO - 2017-02-21 02:57:15 --> Config Class Initialized
INFO - 2017-02-21 02:57:15 --> Hooks Class Initialized
DEBUG - 2017-02-21 02:57:15 --> UTF-8 Support Enabled
INFO - 2017-02-21 02:57:15 --> Utf8 Class Initialized
INFO - 2017-02-21 02:57:15 --> URI Class Initialized
INFO - 2017-02-21 02:57:15 --> Router Class Initialized
INFO - 2017-02-21 02:57:15 --> Output Class Initialized
INFO - 2017-02-21 02:57:15 --> Security Class Initialized
DEBUG - 2017-02-21 02:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 02:57:15 --> Input Class Initialized
INFO - 2017-02-21 02:57:15 --> Language Class Initialized
INFO - 2017-02-21 02:57:15 --> Loader Class Initialized
INFO - 2017-02-21 02:57:15 --> Database Driver Class Initialized
INFO - 2017-02-21 02:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 02:57:15 --> Controller Class Initialized
INFO - 2017-02-21 02:57:15 --> Helper loaded: url_helper
DEBUG - 2017-02-21 02:57:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-21 02:57:17 --> Config Class Initialized
INFO - 2017-02-21 02:57:17 --> Hooks Class Initialized
DEBUG - 2017-02-21 02:57:17 --> UTF-8 Support Enabled
INFO - 2017-02-21 02:57:17 --> Utf8 Class Initialized
INFO - 2017-02-21 02:57:17 --> URI Class Initialized
INFO - 2017-02-21 02:57:17 --> Router Class Initialized
INFO - 2017-02-21 02:57:17 --> Output Class Initialized
INFO - 2017-02-21 02:57:17 --> Security Class Initialized
DEBUG - 2017-02-21 02:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 02:57:17 --> Input Class Initialized
INFO - 2017-02-21 02:57:17 --> Language Class Initialized
INFO - 2017-02-21 02:57:17 --> Loader Class Initialized
INFO - 2017-02-21 02:57:17 --> Database Driver Class Initialized
INFO - 2017-02-21 02:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 02:57:17 --> Controller Class Initialized
INFO - 2017-02-21 02:57:17 --> Helper loaded: date_helper
DEBUG - 2017-02-21 02:57:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-21 02:57:17 --> Helper loaded: url_helper
INFO - 2017-02-21 02:57:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-21 02:57:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-21 02:57:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-21 02:57:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-21 02:57:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-21 02:57:17 --> Final output sent to browser
DEBUG - 2017-02-21 02:57:17 --> Total execution time: 0.0487
INFO - 2017-02-21 02:57:18 --> Config Class Initialized
INFO - 2017-02-21 02:57:18 --> Hooks Class Initialized
DEBUG - 2017-02-21 02:57:18 --> UTF-8 Support Enabled
INFO - 2017-02-21 02:57:18 --> Utf8 Class Initialized
INFO - 2017-02-21 02:57:18 --> URI Class Initialized
INFO - 2017-02-21 02:57:18 --> Router Class Initialized
INFO - 2017-02-21 02:57:18 --> Output Class Initialized
INFO - 2017-02-21 02:57:18 --> Security Class Initialized
DEBUG - 2017-02-21 02:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 02:57:18 --> Input Class Initialized
INFO - 2017-02-21 02:57:18 --> Language Class Initialized
INFO - 2017-02-21 02:57:18 --> Loader Class Initialized
INFO - 2017-02-21 02:57:18 --> Database Driver Class Initialized
INFO - 2017-02-21 02:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 02:57:18 --> Controller Class Initialized
INFO - 2017-02-21 02:57:18 --> Helper loaded: url_helper
DEBUG - 2017-02-21 02:57:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-21 02:57:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-21 02:57:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-21 02:57:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-21 02:57:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-21 02:57:18 --> Final output sent to browser
DEBUG - 2017-02-21 02:57:18 --> Total execution time: 0.0238
INFO - 2017-02-21 02:57:27 --> Config Class Initialized
INFO - 2017-02-21 02:57:27 --> Hooks Class Initialized
DEBUG - 2017-02-21 02:57:27 --> UTF-8 Support Enabled
INFO - 2017-02-21 02:57:27 --> Utf8 Class Initialized
INFO - 2017-02-21 02:57:27 --> URI Class Initialized
INFO - 2017-02-21 02:57:27 --> Router Class Initialized
INFO - 2017-02-21 02:57:27 --> Output Class Initialized
INFO - 2017-02-21 02:57:27 --> Security Class Initialized
DEBUG - 2017-02-21 02:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 02:57:27 --> Input Class Initialized
INFO - 2017-02-21 02:57:27 --> Language Class Initialized
INFO - 2017-02-21 02:57:27 --> Loader Class Initialized
INFO - 2017-02-21 02:57:27 --> Database Driver Class Initialized
INFO - 2017-02-21 02:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 02:57:27 --> Controller Class Initialized
INFO - 2017-02-21 02:57:27 --> Helper loaded: url_helper
DEBUG - 2017-02-21 02:57:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-21 02:57:27 --> Config Class Initialized
INFO - 2017-02-21 02:57:27 --> Hooks Class Initialized
DEBUG - 2017-02-21 02:57:27 --> UTF-8 Support Enabled
INFO - 2017-02-21 02:57:27 --> Utf8 Class Initialized
INFO - 2017-02-21 02:57:27 --> URI Class Initialized
INFO - 2017-02-21 02:57:27 --> Router Class Initialized
INFO - 2017-02-21 02:57:27 --> Output Class Initialized
INFO - 2017-02-21 02:57:27 --> Security Class Initialized
DEBUG - 2017-02-21 02:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 02:57:27 --> Input Class Initialized
INFO - 2017-02-21 02:57:27 --> Language Class Initialized
INFO - 2017-02-21 02:57:27 --> Loader Class Initialized
INFO - 2017-02-21 02:57:27 --> Database Driver Class Initialized
INFO - 2017-02-21 02:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 02:57:27 --> Controller Class Initialized
INFO - 2017-02-21 02:57:27 --> Helper loaded: date_helper
DEBUG - 2017-02-21 02:57:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-21 02:57:27 --> Helper loaded: url_helper
INFO - 2017-02-21 02:57:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-21 02:57:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-21 02:57:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-21 02:57:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-21 02:57:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-21 02:57:27 --> Final output sent to browser
DEBUG - 2017-02-21 02:57:27 --> Total execution time: 0.0159
INFO - 2017-02-21 02:57:28 --> Config Class Initialized
INFO - 2017-02-21 02:57:28 --> Hooks Class Initialized
DEBUG - 2017-02-21 02:57:28 --> UTF-8 Support Enabled
INFO - 2017-02-21 02:57:28 --> Utf8 Class Initialized
INFO - 2017-02-21 02:57:28 --> URI Class Initialized
INFO - 2017-02-21 02:57:28 --> Router Class Initialized
INFO - 2017-02-21 02:57:28 --> Output Class Initialized
INFO - 2017-02-21 02:57:28 --> Security Class Initialized
DEBUG - 2017-02-21 02:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 02:57:28 --> Input Class Initialized
INFO - 2017-02-21 02:57:28 --> Language Class Initialized
INFO - 2017-02-21 02:57:28 --> Loader Class Initialized
INFO - 2017-02-21 02:57:28 --> Database Driver Class Initialized
INFO - 2017-02-21 02:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 02:57:28 --> Controller Class Initialized
INFO - 2017-02-21 02:57:28 --> Helper loaded: url_helper
DEBUG - 2017-02-21 02:57:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-21 02:57:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-21 02:57:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-21 02:57:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-21 02:57:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-21 02:57:28 --> Final output sent to browser
DEBUG - 2017-02-21 02:57:28 --> Total execution time: 0.0154
INFO - 2017-02-21 02:57:30 --> Config Class Initialized
INFO - 2017-02-21 02:57:30 --> Hooks Class Initialized
DEBUG - 2017-02-21 02:57:30 --> UTF-8 Support Enabled
INFO - 2017-02-21 02:57:30 --> Utf8 Class Initialized
INFO - 2017-02-21 02:57:30 --> URI Class Initialized
DEBUG - 2017-02-21 02:57:30 --> No URI present. Default controller set.
INFO - 2017-02-21 02:57:30 --> Router Class Initialized
INFO - 2017-02-21 02:57:30 --> Output Class Initialized
INFO - 2017-02-21 02:57:30 --> Security Class Initialized
DEBUG - 2017-02-21 02:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 02:57:30 --> Input Class Initialized
INFO - 2017-02-21 02:57:30 --> Language Class Initialized
INFO - 2017-02-21 02:57:30 --> Loader Class Initialized
INFO - 2017-02-21 02:57:30 --> Database Driver Class Initialized
INFO - 2017-02-21 02:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 02:57:30 --> Controller Class Initialized
INFO - 2017-02-21 02:57:30 --> Helper loaded: url_helper
DEBUG - 2017-02-21 02:57:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-21 02:57:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-21 02:57:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-21 02:57:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-21 02:57:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-21 02:57:30 --> Final output sent to browser
DEBUG - 2017-02-21 02:57:30 --> Total execution time: 0.0138
INFO - 2017-02-21 14:37:47 --> Config Class Initialized
INFO - 2017-02-21 14:37:47 --> Hooks Class Initialized
DEBUG - 2017-02-21 14:37:48 --> UTF-8 Support Enabled
INFO - 2017-02-21 14:37:48 --> Utf8 Class Initialized
INFO - 2017-02-21 14:37:48 --> URI Class Initialized
INFO - 2017-02-21 14:37:48 --> Router Class Initialized
INFO - 2017-02-21 14:37:48 --> Output Class Initialized
INFO - 2017-02-21 14:37:48 --> Security Class Initialized
DEBUG - 2017-02-21 14:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 14:37:48 --> Input Class Initialized
INFO - 2017-02-21 14:37:48 --> Language Class Initialized
INFO - 2017-02-21 14:37:48 --> Loader Class Initialized
INFO - 2017-02-21 14:37:48 --> Database Driver Class Initialized
INFO - 2017-02-21 14:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 14:37:48 --> Controller Class Initialized
INFO - 2017-02-21 14:37:48 --> Helper loaded: url_helper
DEBUG - 2017-02-21 14:37:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-21 14:37:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-21 14:37:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-21 14:37:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-21 14:37:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-21 14:37:49 --> Final output sent to browser
DEBUG - 2017-02-21 14:37:49 --> Total execution time: 1.5316
INFO - 2017-02-21 14:38:50 --> Config Class Initialized
INFO - 2017-02-21 14:38:50 --> Hooks Class Initialized
DEBUG - 2017-02-21 14:38:50 --> UTF-8 Support Enabled
INFO - 2017-02-21 14:38:50 --> Utf8 Class Initialized
INFO - 2017-02-21 14:38:50 --> URI Class Initialized
DEBUG - 2017-02-21 14:38:50 --> No URI present. Default controller set.
INFO - 2017-02-21 14:38:50 --> Router Class Initialized
INFO - 2017-02-21 14:38:51 --> Output Class Initialized
INFO - 2017-02-21 14:38:51 --> Security Class Initialized
DEBUG - 2017-02-21 14:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 14:38:51 --> Input Class Initialized
INFO - 2017-02-21 14:38:51 --> Language Class Initialized
INFO - 2017-02-21 14:38:51 --> Loader Class Initialized
INFO - 2017-02-21 14:38:51 --> Database Driver Class Initialized
INFO - 2017-02-21 14:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 14:38:51 --> Controller Class Initialized
INFO - 2017-02-21 14:38:51 --> Helper loaded: url_helper
DEBUG - 2017-02-21 14:38:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-21 14:38:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-21 14:38:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-21 14:38:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-21 14:38:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-21 14:38:52 --> Final output sent to browser
DEBUG - 2017-02-21 14:38:52 --> Total execution time: 1.8183
INFO - 2017-02-21 15:06:01 --> Config Class Initialized
INFO - 2017-02-21 15:06:01 --> Hooks Class Initialized
DEBUG - 2017-02-21 15:06:02 --> UTF-8 Support Enabled
INFO - 2017-02-21 15:06:02 --> Utf8 Class Initialized
INFO - 2017-02-21 15:06:02 --> URI Class Initialized
DEBUG - 2017-02-21 15:06:02 --> No URI present. Default controller set.
INFO - 2017-02-21 15:06:02 --> Router Class Initialized
INFO - 2017-02-21 15:06:02 --> Output Class Initialized
INFO - 2017-02-21 15:06:02 --> Security Class Initialized
DEBUG - 2017-02-21 15:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 15:06:02 --> Input Class Initialized
INFO - 2017-02-21 15:06:02 --> Language Class Initialized
INFO - 2017-02-21 15:06:02 --> Loader Class Initialized
INFO - 2017-02-21 15:06:02 --> Database Driver Class Initialized
INFO - 2017-02-21 15:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 15:06:03 --> Controller Class Initialized
INFO - 2017-02-21 15:06:03 --> Helper loaded: url_helper
DEBUG - 2017-02-21 15:06:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-21 15:06:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-21 15:06:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-21 15:06:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-21 15:06:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-21 15:06:03 --> Final output sent to browser
DEBUG - 2017-02-21 15:06:03 --> Total execution time: 1.7542
INFO - 2017-02-21 15:41:46 --> Config Class Initialized
INFO - 2017-02-21 15:41:46 --> Hooks Class Initialized
DEBUG - 2017-02-21 15:41:47 --> UTF-8 Support Enabled
INFO - 2017-02-21 15:41:47 --> Utf8 Class Initialized
INFO - 2017-02-21 15:41:47 --> URI Class Initialized
INFO - 2017-02-21 15:41:47 --> Router Class Initialized
INFO - 2017-02-21 15:41:47 --> Output Class Initialized
INFO - 2017-02-21 15:41:47 --> Security Class Initialized
DEBUG - 2017-02-21 15:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 15:41:47 --> Input Class Initialized
INFO - 2017-02-21 15:41:47 --> Language Class Initialized
INFO - 2017-02-21 15:41:47 --> Loader Class Initialized
INFO - 2017-02-21 15:41:47 --> Database Driver Class Initialized
INFO - 2017-02-21 15:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 15:41:48 --> Controller Class Initialized
INFO - 2017-02-21 15:41:48 --> Helper loaded: date_helper
DEBUG - 2017-02-21 15:41:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-21 15:41:48 --> Helper loaded: url_helper
INFO - 2017-02-21 15:41:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-21 15:41:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-21 15:41:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-21 15:41:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-21 15:41:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-21 15:41:48 --> Final output sent to browser
DEBUG - 2017-02-21 15:41:48 --> Total execution time: 1.6308
INFO - 2017-02-21 15:41:52 --> Config Class Initialized
INFO - 2017-02-21 15:41:52 --> Hooks Class Initialized
DEBUG - 2017-02-21 15:41:52 --> UTF-8 Support Enabled
INFO - 2017-02-21 15:41:52 --> Utf8 Class Initialized
INFO - 2017-02-21 15:41:52 --> URI Class Initialized
INFO - 2017-02-21 15:41:52 --> Router Class Initialized
INFO - 2017-02-21 15:41:52 --> Output Class Initialized
INFO - 2017-02-21 15:41:52 --> Security Class Initialized
DEBUG - 2017-02-21 15:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 15:41:52 --> Input Class Initialized
INFO - 2017-02-21 15:41:52 --> Language Class Initialized
INFO - 2017-02-21 15:41:52 --> Loader Class Initialized
INFO - 2017-02-21 15:41:52 --> Database Driver Class Initialized
INFO - 2017-02-21 15:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 15:41:52 --> Controller Class Initialized
INFO - 2017-02-21 15:41:52 --> Helper loaded: url_helper
DEBUG - 2017-02-21 15:41:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-21 15:41:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-21 15:41:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-21 15:41:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-21 15:41:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-21 15:41:52 --> Final output sent to browser
DEBUG - 2017-02-21 15:41:52 --> Total execution time: 0.2505
INFO - 2017-02-21 15:42:05 --> Config Class Initialized
INFO - 2017-02-21 15:42:05 --> Hooks Class Initialized
DEBUG - 2017-02-21 15:42:05 --> UTF-8 Support Enabled
INFO - 2017-02-21 15:42:05 --> Utf8 Class Initialized
INFO - 2017-02-21 15:42:05 --> URI Class Initialized
DEBUG - 2017-02-21 15:42:05 --> No URI present. Default controller set.
INFO - 2017-02-21 15:42:05 --> Router Class Initialized
INFO - 2017-02-21 15:42:05 --> Output Class Initialized
INFO - 2017-02-21 15:42:05 --> Security Class Initialized
DEBUG - 2017-02-21 15:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 15:42:05 --> Input Class Initialized
INFO - 2017-02-21 15:42:05 --> Language Class Initialized
INFO - 2017-02-21 15:42:05 --> Loader Class Initialized
INFO - 2017-02-21 15:42:05 --> Database Driver Class Initialized
INFO - 2017-02-21 15:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 15:42:05 --> Controller Class Initialized
INFO - 2017-02-21 15:42:05 --> Helper loaded: url_helper
DEBUG - 2017-02-21 15:42:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-21 15:42:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-21 15:42:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-21 15:42:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-21 15:42:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-21 15:42:05 --> Final output sent to browser
DEBUG - 2017-02-21 15:42:05 --> Total execution time: 0.0375
INFO - 2017-02-21 15:42:17 --> Config Class Initialized
INFO - 2017-02-21 15:42:17 --> Hooks Class Initialized
DEBUG - 2017-02-21 15:42:17 --> UTF-8 Support Enabled
INFO - 2017-02-21 15:42:17 --> Utf8 Class Initialized
INFO - 2017-02-21 15:42:17 --> URI Class Initialized
INFO - 2017-02-21 15:42:17 --> Router Class Initialized
INFO - 2017-02-21 15:42:17 --> Output Class Initialized
INFO - 2017-02-21 15:42:17 --> Security Class Initialized
DEBUG - 2017-02-21 15:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 15:42:17 --> Input Class Initialized
INFO - 2017-02-21 15:42:17 --> Language Class Initialized
INFO - 2017-02-21 15:42:17 --> Loader Class Initialized
INFO - 2017-02-21 15:42:17 --> Database Driver Class Initialized
INFO - 2017-02-21 15:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 15:42:17 --> Controller Class Initialized
INFO - 2017-02-21 15:42:17 --> Helper loaded: url_helper
DEBUG - 2017-02-21 15:42:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-21 15:42:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-21 15:42:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-21 15:42:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-21 15:42:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-21 15:42:17 --> Final output sent to browser
DEBUG - 2017-02-21 15:42:17 --> Total execution time: 0.0145
INFO - 2017-02-21 15:42:39 --> Config Class Initialized
INFO - 2017-02-21 15:42:39 --> Hooks Class Initialized
DEBUG - 2017-02-21 15:42:39 --> UTF-8 Support Enabled
INFO - 2017-02-21 15:42:39 --> Utf8 Class Initialized
INFO - 2017-02-21 15:42:39 --> URI Class Initialized
INFO - 2017-02-21 15:42:39 --> Router Class Initialized
INFO - 2017-02-21 15:42:39 --> Output Class Initialized
INFO - 2017-02-21 15:42:39 --> Security Class Initialized
DEBUG - 2017-02-21 15:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 15:42:39 --> Input Class Initialized
INFO - 2017-02-21 15:42:39 --> Language Class Initialized
INFO - 2017-02-21 15:42:39 --> Loader Class Initialized
INFO - 2017-02-21 15:42:39 --> Database Driver Class Initialized
INFO - 2017-02-21 15:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 15:42:39 --> Controller Class Initialized
INFO - 2017-02-21 15:42:39 --> Helper loaded: url_helper
DEBUG - 2017-02-21 15:42:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-21 15:42:40 --> Config Class Initialized
INFO - 2017-02-21 15:42:40 --> Hooks Class Initialized
DEBUG - 2017-02-21 15:42:40 --> UTF-8 Support Enabled
INFO - 2017-02-21 15:42:40 --> Utf8 Class Initialized
INFO - 2017-02-21 15:42:40 --> URI Class Initialized
INFO - 2017-02-21 15:42:40 --> Router Class Initialized
INFO - 2017-02-21 15:42:40 --> Output Class Initialized
INFO - 2017-02-21 15:42:40 --> Security Class Initialized
DEBUG - 2017-02-21 15:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 15:42:40 --> Input Class Initialized
INFO - 2017-02-21 15:42:40 --> Language Class Initialized
INFO - 2017-02-21 15:42:40 --> Loader Class Initialized
INFO - 2017-02-21 15:42:40 --> Database Driver Class Initialized
INFO - 2017-02-21 15:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 15:42:40 --> Controller Class Initialized
INFO - 2017-02-21 15:42:40 --> Helper loaded: date_helper
DEBUG - 2017-02-21 15:42:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-21 15:42:40 --> Helper loaded: url_helper
INFO - 2017-02-21 15:42:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-21 15:42:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-21 15:42:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-21 15:42:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-21 15:42:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-21 15:42:41 --> Final output sent to browser
DEBUG - 2017-02-21 15:42:41 --> Total execution time: 0.2413
INFO - 2017-02-21 15:42:48 --> Config Class Initialized
INFO - 2017-02-21 15:42:48 --> Hooks Class Initialized
DEBUG - 2017-02-21 15:42:48 --> UTF-8 Support Enabled
INFO - 2017-02-21 15:42:48 --> Utf8 Class Initialized
INFO - 2017-02-21 15:42:48 --> URI Class Initialized
INFO - 2017-02-21 15:42:48 --> Router Class Initialized
INFO - 2017-02-21 15:42:48 --> Output Class Initialized
INFO - 2017-02-21 15:42:48 --> Security Class Initialized
DEBUG - 2017-02-21 15:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 15:42:48 --> Input Class Initialized
INFO - 2017-02-21 15:42:48 --> Language Class Initialized
INFO - 2017-02-21 15:42:48 --> Loader Class Initialized
INFO - 2017-02-21 15:42:48 --> Database Driver Class Initialized
INFO - 2017-02-21 15:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 15:42:48 --> Controller Class Initialized
INFO - 2017-02-21 15:42:48 --> Helper loaded: url_helper
DEBUG - 2017-02-21 15:42:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-21 15:42:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-21 15:42:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-21 15:42:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-21 15:42:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-21 15:42:48 --> Final output sent to browser
DEBUG - 2017-02-21 15:42:48 --> Total execution time: 0.0142
INFO - 2017-02-21 15:47:49 --> Config Class Initialized
INFO - 2017-02-21 15:47:49 --> Hooks Class Initialized
DEBUG - 2017-02-21 15:47:49 --> UTF-8 Support Enabled
INFO - 2017-02-21 15:47:49 --> Utf8 Class Initialized
INFO - 2017-02-21 15:47:49 --> URI Class Initialized
DEBUG - 2017-02-21 15:47:50 --> No URI present. Default controller set.
INFO - 2017-02-21 15:47:50 --> Router Class Initialized
INFO - 2017-02-21 15:47:50 --> Output Class Initialized
INFO - 2017-02-21 15:47:50 --> Security Class Initialized
DEBUG - 2017-02-21 15:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 15:47:50 --> Input Class Initialized
INFO - 2017-02-21 15:47:50 --> Language Class Initialized
INFO - 2017-02-21 15:47:50 --> Loader Class Initialized
INFO - 2017-02-21 15:47:50 --> Database Driver Class Initialized
INFO - 2017-02-21 15:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 15:47:50 --> Controller Class Initialized
INFO - 2017-02-21 15:47:50 --> Helper loaded: url_helper
DEBUG - 2017-02-21 15:47:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-21 15:47:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-21 15:47:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-21 15:47:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-21 15:47:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-21 15:47:51 --> Final output sent to browser
DEBUG - 2017-02-21 15:47:51 --> Total execution time: 1.5227
INFO - 2017-02-21 16:48:01 --> Config Class Initialized
INFO - 2017-02-21 16:48:01 --> Hooks Class Initialized
DEBUG - 2017-02-21 16:48:01 --> UTF-8 Support Enabled
INFO - 2017-02-21 16:48:01 --> Utf8 Class Initialized
INFO - 2017-02-21 16:48:01 --> URI Class Initialized
INFO - 2017-02-21 16:48:01 --> Router Class Initialized
INFO - 2017-02-21 16:48:01 --> Output Class Initialized
INFO - 2017-02-21 16:48:01 --> Security Class Initialized
DEBUG - 2017-02-21 16:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 16:48:01 --> Input Class Initialized
INFO - 2017-02-21 16:48:01 --> Language Class Initialized
INFO - 2017-02-21 16:48:01 --> Loader Class Initialized
INFO - 2017-02-21 16:48:02 --> Database Driver Class Initialized
INFO - 2017-02-21 16:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 16:48:02 --> Controller Class Initialized
INFO - 2017-02-21 16:48:02 --> Helper loaded: url_helper
DEBUG - 2017-02-21 16:48:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-21 16:48:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-21 16:48:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-21 16:48:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-21 16:48:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-21 16:48:02 --> Final output sent to browser
DEBUG - 2017-02-21 16:48:02 --> Total execution time: 1.7911
INFO - 2017-02-21 16:48:41 --> Config Class Initialized
INFO - 2017-02-21 16:48:41 --> Hooks Class Initialized
DEBUG - 2017-02-21 16:48:41 --> UTF-8 Support Enabled
INFO - 2017-02-21 16:48:41 --> Utf8 Class Initialized
INFO - 2017-02-21 16:48:41 --> URI Class Initialized
DEBUG - 2017-02-21 16:48:41 --> No URI present. Default controller set.
INFO - 2017-02-21 16:48:41 --> Router Class Initialized
INFO - 2017-02-21 16:48:41 --> Output Class Initialized
INFO - 2017-02-21 16:48:41 --> Security Class Initialized
DEBUG - 2017-02-21 16:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 16:48:41 --> Input Class Initialized
INFO - 2017-02-21 16:48:41 --> Language Class Initialized
INFO - 2017-02-21 16:48:41 --> Loader Class Initialized
INFO - 2017-02-21 16:48:41 --> Database Driver Class Initialized
INFO - 2017-02-21 16:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 16:48:41 --> Controller Class Initialized
INFO - 2017-02-21 16:48:41 --> Helper loaded: url_helper
DEBUG - 2017-02-21 16:48:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-21 16:48:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-21 16:48:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-21 16:48:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-21 16:48:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-21 16:48:41 --> Final output sent to browser
DEBUG - 2017-02-21 16:48:41 --> Total execution time: 0.0986
INFO - 2017-02-21 16:51:56 --> Config Class Initialized
INFO - 2017-02-21 16:51:56 --> Hooks Class Initialized
DEBUG - 2017-02-21 16:51:56 --> UTF-8 Support Enabled
INFO - 2017-02-21 16:51:56 --> Utf8 Class Initialized
INFO - 2017-02-21 16:51:56 --> URI Class Initialized
INFO - 2017-02-21 16:51:56 --> Router Class Initialized
INFO - 2017-02-21 16:51:56 --> Output Class Initialized
INFO - 2017-02-21 16:51:56 --> Security Class Initialized
DEBUG - 2017-02-21 16:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 16:51:56 --> Input Class Initialized
INFO - 2017-02-21 16:51:56 --> Language Class Initialized
INFO - 2017-02-21 16:51:56 --> Loader Class Initialized
INFO - 2017-02-21 16:51:57 --> Database Driver Class Initialized
INFO - 2017-02-21 16:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 16:51:57 --> Controller Class Initialized
INFO - 2017-02-21 16:51:57 --> Helper loaded: date_helper
DEBUG - 2017-02-21 16:51:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-21 16:51:57 --> Helper loaded: url_helper
INFO - 2017-02-21 16:51:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-21 16:51:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-21 16:51:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-21 16:51:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-21 16:51:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-21 16:51:57 --> Final output sent to browser
DEBUG - 2017-02-21 16:51:57 --> Total execution time: 1.6343
INFO - 2017-02-21 17:53:08 --> Config Class Initialized
INFO - 2017-02-21 17:53:08 --> Hooks Class Initialized
DEBUG - 2017-02-21 17:53:09 --> UTF-8 Support Enabled
INFO - 2017-02-21 17:53:09 --> Utf8 Class Initialized
INFO - 2017-02-21 17:53:09 --> URI Class Initialized
DEBUG - 2017-02-21 17:53:09 --> No URI present. Default controller set.
INFO - 2017-02-21 17:53:09 --> Router Class Initialized
INFO - 2017-02-21 17:53:09 --> Output Class Initialized
INFO - 2017-02-21 17:53:09 --> Security Class Initialized
DEBUG - 2017-02-21 17:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 17:53:09 --> Input Class Initialized
INFO - 2017-02-21 17:53:09 --> Language Class Initialized
INFO - 2017-02-21 17:53:09 --> Loader Class Initialized
INFO - 2017-02-21 17:53:09 --> Database Driver Class Initialized
INFO - 2017-02-21 17:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 17:53:10 --> Controller Class Initialized
INFO - 2017-02-21 17:53:10 --> Helper loaded: url_helper
DEBUG - 2017-02-21 17:53:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-21 17:53:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-21 17:53:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-21 17:53:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-21 17:53:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-21 17:53:11 --> Final output sent to browser
DEBUG - 2017-02-21 17:53:11 --> Total execution time: 2.6526
INFO - 2017-02-21 20:10:36 --> Config Class Initialized
INFO - 2017-02-21 20:10:36 --> Hooks Class Initialized
DEBUG - 2017-02-21 20:10:36 --> UTF-8 Support Enabled
INFO - 2017-02-21 20:10:36 --> Utf8 Class Initialized
INFO - 2017-02-21 20:10:36 --> URI Class Initialized
INFO - 2017-02-21 20:10:36 --> Router Class Initialized
INFO - 2017-02-21 20:10:36 --> Output Class Initialized
INFO - 2017-02-21 20:10:36 --> Security Class Initialized
DEBUG - 2017-02-21 20:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 20:10:36 --> Input Class Initialized
INFO - 2017-02-21 20:10:36 --> Language Class Initialized
INFO - 2017-02-21 20:10:36 --> Loader Class Initialized
INFO - 2017-02-21 20:10:36 --> Database Driver Class Initialized
INFO - 2017-02-21 20:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 20:10:37 --> Controller Class Initialized
INFO - 2017-02-21 20:10:37 --> Helper loaded: url_helper
DEBUG - 2017-02-21 20:10:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-21 20:10:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-21 20:10:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-21 20:10:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-21 20:10:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-21 20:10:37 --> Final output sent to browser
DEBUG - 2017-02-21 20:10:37 --> Total execution time: 1.5099
INFO - 2017-02-21 20:10:46 --> Config Class Initialized
INFO - 2017-02-21 20:10:46 --> Hooks Class Initialized
DEBUG - 2017-02-21 20:10:46 --> UTF-8 Support Enabled
INFO - 2017-02-21 20:10:46 --> Utf8 Class Initialized
INFO - 2017-02-21 20:10:46 --> URI Class Initialized
DEBUG - 2017-02-21 20:10:46 --> No URI present. Default controller set.
INFO - 2017-02-21 20:10:46 --> Router Class Initialized
INFO - 2017-02-21 20:10:46 --> Output Class Initialized
INFO - 2017-02-21 20:10:46 --> Security Class Initialized
DEBUG - 2017-02-21 20:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 20:10:46 --> Input Class Initialized
INFO - 2017-02-21 20:10:46 --> Language Class Initialized
INFO - 2017-02-21 20:10:46 --> Loader Class Initialized
INFO - 2017-02-21 20:10:46 --> Database Driver Class Initialized
INFO - 2017-02-21 20:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 20:10:46 --> Controller Class Initialized
INFO - 2017-02-21 20:10:46 --> Helper loaded: url_helper
DEBUG - 2017-02-21 20:10:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-21 20:10:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-21 20:10:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-21 20:10:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-21 20:10:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-21 20:10:46 --> Final output sent to browser
DEBUG - 2017-02-21 20:10:46 --> Total execution time: 0.0418
INFO - 2017-02-21 20:19:29 --> Config Class Initialized
INFO - 2017-02-21 20:19:29 --> Hooks Class Initialized
DEBUG - 2017-02-21 20:19:29 --> UTF-8 Support Enabled
INFO - 2017-02-21 20:19:29 --> Utf8 Class Initialized
INFO - 2017-02-21 20:19:29 --> URI Class Initialized
INFO - 2017-02-21 20:19:29 --> Router Class Initialized
INFO - 2017-02-21 20:19:29 --> Output Class Initialized
INFO - 2017-02-21 20:19:29 --> Security Class Initialized
DEBUG - 2017-02-21 20:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 20:19:29 --> Input Class Initialized
INFO - 2017-02-21 20:19:29 --> Language Class Initialized
INFO - 2017-02-21 20:19:29 --> Loader Class Initialized
INFO - 2017-02-21 20:19:30 --> Database Driver Class Initialized
INFO - 2017-02-21 20:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 20:19:30 --> Controller Class Initialized
INFO - 2017-02-21 20:19:30 --> Helper loaded: url_helper
DEBUG - 2017-02-21 20:19:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-21 20:19:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-21 20:19:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-21 20:19:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-21 20:19:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-21 20:19:30 --> Final output sent to browser
DEBUG - 2017-02-21 20:19:30 --> Total execution time: 1.7366
INFO - 2017-02-21 20:21:38 --> Config Class Initialized
INFO - 2017-02-21 20:21:38 --> Hooks Class Initialized
DEBUG - 2017-02-21 20:21:38 --> UTF-8 Support Enabled
INFO - 2017-02-21 20:21:38 --> Utf8 Class Initialized
INFO - 2017-02-21 20:21:38 --> URI Class Initialized
DEBUG - 2017-02-21 20:21:38 --> No URI present. Default controller set.
INFO - 2017-02-21 20:21:38 --> Router Class Initialized
INFO - 2017-02-21 20:21:38 --> Output Class Initialized
INFO - 2017-02-21 20:21:38 --> Security Class Initialized
DEBUG - 2017-02-21 20:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 20:21:38 --> Input Class Initialized
INFO - 2017-02-21 20:21:38 --> Language Class Initialized
INFO - 2017-02-21 20:21:38 --> Loader Class Initialized
INFO - 2017-02-21 20:21:38 --> Database Driver Class Initialized
INFO - 2017-02-21 20:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 20:21:39 --> Controller Class Initialized
INFO - 2017-02-21 20:21:39 --> Helper loaded: url_helper
DEBUG - 2017-02-21 20:21:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-21 20:21:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-21 20:21:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-21 20:21:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-21 20:21:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-21 20:21:39 --> Final output sent to browser
DEBUG - 2017-02-21 20:21:39 --> Total execution time: 1.3780
INFO - 2017-02-21 21:10:45 --> Config Class Initialized
INFO - 2017-02-21 21:10:45 --> Hooks Class Initialized
DEBUG - 2017-02-21 21:10:46 --> UTF-8 Support Enabled
INFO - 2017-02-21 21:10:46 --> Utf8 Class Initialized
INFO - 2017-02-21 21:10:46 --> URI Class Initialized
DEBUG - 2017-02-21 21:10:46 --> No URI present. Default controller set.
INFO - 2017-02-21 21:10:46 --> Router Class Initialized
INFO - 2017-02-21 21:10:46 --> Output Class Initialized
INFO - 2017-02-21 21:10:46 --> Security Class Initialized
DEBUG - 2017-02-21 21:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 21:10:46 --> Input Class Initialized
INFO - 2017-02-21 21:10:46 --> Language Class Initialized
INFO - 2017-02-21 21:10:46 --> Loader Class Initialized
INFO - 2017-02-21 21:10:46 --> Database Driver Class Initialized
INFO - 2017-02-21 21:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 21:10:47 --> Controller Class Initialized
INFO - 2017-02-21 21:10:47 --> Helper loaded: url_helper
DEBUG - 2017-02-21 21:10:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-21 21:10:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-21 21:10:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-21 21:10:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-21 21:10:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-21 21:10:48 --> Final output sent to browser
DEBUG - 2017-02-21 21:10:48 --> Total execution time: 2.2711
INFO - 2017-02-21 21:10:57 --> Config Class Initialized
INFO - 2017-02-21 21:10:57 --> Hooks Class Initialized
DEBUG - 2017-02-21 21:10:58 --> UTF-8 Support Enabled
INFO - 2017-02-21 21:10:58 --> Utf8 Class Initialized
INFO - 2017-02-21 21:10:58 --> URI Class Initialized
INFO - 2017-02-21 21:10:58 --> Router Class Initialized
INFO - 2017-02-21 21:10:58 --> Output Class Initialized
INFO - 2017-02-21 21:10:58 --> Security Class Initialized
DEBUG - 2017-02-21 21:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 21:10:58 --> Input Class Initialized
INFO - 2017-02-21 21:10:58 --> Language Class Initialized
INFO - 2017-02-21 21:10:58 --> Loader Class Initialized
INFO - 2017-02-21 21:10:58 --> Database Driver Class Initialized
INFO - 2017-02-21 21:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 21:10:58 --> Controller Class Initialized
INFO - 2017-02-21 21:10:58 --> Helper loaded: url_helper
DEBUG - 2017-02-21 21:10:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-21 21:10:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-21 21:10:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-21 21:10:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-21 21:10:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-21 21:10:59 --> Final output sent to browser
DEBUG - 2017-02-21 21:10:59 --> Total execution time: 1.6108
INFO - 2017-02-21 21:12:48 --> Config Class Initialized
INFO - 2017-02-21 21:12:48 --> Hooks Class Initialized
DEBUG - 2017-02-21 21:12:48 --> UTF-8 Support Enabled
INFO - 2017-02-21 21:12:48 --> Utf8 Class Initialized
INFO - 2017-02-21 21:12:48 --> URI Class Initialized
INFO - 2017-02-21 21:12:48 --> Router Class Initialized
INFO - 2017-02-21 21:12:48 --> Output Class Initialized
INFO - 2017-02-21 21:12:48 --> Security Class Initialized
DEBUG - 2017-02-21 21:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 21:12:48 --> Input Class Initialized
INFO - 2017-02-21 21:12:48 --> Language Class Initialized
INFO - 2017-02-21 21:12:48 --> Loader Class Initialized
INFO - 2017-02-21 21:12:49 --> Database Driver Class Initialized
INFO - 2017-02-21 21:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 21:12:49 --> Controller Class Initialized
INFO - 2017-02-21 21:12:50 --> Helper loaded: url_helper
DEBUG - 2017-02-21 21:12:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-21 21:12:50 --> Final output sent to browser
DEBUG - 2017-02-21 21:12:50 --> Total execution time: 1.9662
INFO - 2017-02-21 22:37:46 --> Config Class Initialized
INFO - 2017-02-21 22:37:46 --> Hooks Class Initialized
DEBUG - 2017-02-21 22:37:46 --> UTF-8 Support Enabled
INFO - 2017-02-21 22:37:46 --> Utf8 Class Initialized
INFO - 2017-02-21 22:37:46 --> URI Class Initialized
DEBUG - 2017-02-21 22:37:46 --> No URI present. Default controller set.
INFO - 2017-02-21 22:37:46 --> Router Class Initialized
INFO - 2017-02-21 22:37:46 --> Output Class Initialized
INFO - 2017-02-21 22:37:46 --> Security Class Initialized
DEBUG - 2017-02-21 22:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 22:37:46 --> Input Class Initialized
INFO - 2017-02-21 22:37:46 --> Language Class Initialized
INFO - 2017-02-21 22:37:46 --> Loader Class Initialized
INFO - 2017-02-21 22:37:47 --> Database Driver Class Initialized
INFO - 2017-02-21 22:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 22:37:47 --> Controller Class Initialized
INFO - 2017-02-21 22:37:47 --> Helper loaded: url_helper
DEBUG - 2017-02-21 22:37:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-21 22:37:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-21 22:37:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-21 22:37:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-21 22:37:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-21 22:37:48 --> Final output sent to browser
DEBUG - 2017-02-21 22:37:48 --> Total execution time: 1.8925
INFO - 2017-02-21 22:37:53 --> Config Class Initialized
INFO - 2017-02-21 22:37:53 --> Hooks Class Initialized
DEBUG - 2017-02-21 22:37:53 --> UTF-8 Support Enabled
INFO - 2017-02-21 22:37:53 --> Utf8 Class Initialized
INFO - 2017-02-21 22:37:53 --> URI Class Initialized
INFO - 2017-02-21 22:37:53 --> Router Class Initialized
INFO - 2017-02-21 22:37:53 --> Output Class Initialized
INFO - 2017-02-21 22:37:53 --> Security Class Initialized
DEBUG - 2017-02-21 22:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 22:37:53 --> Input Class Initialized
INFO - 2017-02-21 22:37:53 --> Language Class Initialized
INFO - 2017-02-21 22:37:53 --> Loader Class Initialized
INFO - 2017-02-21 22:37:53 --> Database Driver Class Initialized
INFO - 2017-02-21 22:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 22:37:53 --> Controller Class Initialized
INFO - 2017-02-21 22:37:53 --> Helper loaded: url_helper
DEBUG - 2017-02-21 22:37:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-21 22:37:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-21 22:37:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-21 22:37:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-21 22:37:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-21 22:37:53 --> Final output sent to browser
DEBUG - 2017-02-21 22:37:53 --> Total execution time: 0.0146
